package com.myclient.module;

import java.util.ArrayList;
import java.util.List;

public abstract class Setting {
    public final String name;

    protected Setting(String name) { this.name = name; }

    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max, step;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.value = value;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public double fraction() { return (value - min) / (max - min); }

        public void setFraction(double f) {
            f = Math.max(0.0, Math.min(1.0, f));
            double v = min + f * (max - min);
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, Math.round(v * 100.0) / 100.0));
        }

        public String display() {
            return value == Math.floor(value) ? String.valueOf((int) value) : String.valueOf(value);
        }
    }

    /** O nhap chu (vd: cau chat cua TotemPops). */
    public static class Text extends Setting {
        public String value;
        public final int max;

        public Text(String name, String value, int max) {
            super(name);
            this.value = value;
            this.max = max;
        }
    }

    /** Nhom setting (bam chuot phai de mo/dong). Tuy chon co cong tac bat/tat rieng (trai). */
    public static class Group extends Setting {
        public boolean enabled;
        public final boolean hasToggle;
        public boolean open;
        public final List<Setting> children = new ArrayList<>();

        public Group(String name, boolean hasToggle, boolean enabled) {
            super(name);
            this.hasToggle = hasToggle;
            this.enabled = enabled;
        }

        public <T extends Setting> T add(T s) {
            children.add(s);
            return s;
        }
    }

    /** Phim gan rieng cho 1 tinh nang (khong lien quan den phim bat/tat module). */
    public static class KeyBind extends Setting {
        public int key;

        public KeyBind(String name, int key) {
            super(name);
            this.key = key;
        }
    }

    /** Danh sach ten (vd: friends cua AntiRekit): moi ten 1 o, co nut + them va nut - xoa. */
    public static class NameList extends Setting {
        public final List<String> names = new ArrayList<>();
        public final int maxNames;

        public NameList(String name, int maxNames) {
            super(name);
            this.maxNames = maxNames;
        }
    }
}
