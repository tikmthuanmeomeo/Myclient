package com.myclient.module;

public abstract class Setting {
    public final String name;

    protected Setting(String name) { this.name = name; }

    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max, step;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.value = value;
            this.min = min;
            this.max = max;
            this.step = step;
        }

        public double fraction() { return (value - min) / (max - min); }

        public void setFraction(double f) {
            f = Math.max(0.0, Math.min(1.0, f));
            double v = min + f * (max - min);
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, Math.round(v * 100.0) / 100.0));
        }

        public String display() {
            return value == Math.floor(value) ? String.valueOf((int) value) : String.valueOf(value);
        }
    }

    /** O nhap chu (vd: cau chat cua TotemPops). */
    public static class Text extends Setting {
        public String value;
        public final int max;

        public Text(String name, String value, int max) {
            super(name);
            this.value = value;
            this.max = max;
        }
    }
}
