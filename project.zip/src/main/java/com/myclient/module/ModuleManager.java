package com.myclient.module;

import com.myclient.config.Config;
import com.myclient.module.impl.AntiRekit;
import com.myclient.module.impl.AutoRegear;
import com.myclient.module.impl.AutoSprint;
import com.myclient.module.impl.AutoTool;
import com.myclient.module.impl.ClickGui;
import com.myclient.module.impl.BedAura;
import com.myclient.module.impl.FireworkSwap;
import com.myclient.module.impl.FakePlayer;
import com.myclient.module.impl.FullBright;
import com.myclient.module.impl.HotbarSaver;
import com.myclient.module.impl.HudModule;
import com.myclient.module.impl.Nametags;
import com.myclient.module.impl.NoPush;
import com.myclient.module.impl.NoRender;
import com.myclient.module.impl.Particles;
import com.myclient.module.impl.TotemPops;
import com.myclient.module.impl.Sky;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.add(new AntiRekit());
        MODULES.add(new TotemPops());
        MODULES.add(new AutoRegear());
        MODULES.add(new BedAura());
        MODULES.add(new FireworkSwap());
        MODULES.add(new NoPush());
        MODULES.add(new Nametags());
        MODULES.add(new NoRender());
        MODULES.add(new HudModule());
        MODULES.add(new FullBright());
        MODULES.add(new AutoSprint());
        MODULES.add(new Sky());
        MODULES.add(new Particles());
        MODULES.add(new FakePlayer());
        MODULES.add(new HotbarSaver());
        MODULES.add(new AutoTool());
        MODULES.add(new ClickGui());
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> cls) {
        for (Module m : MODULES) if (cls.isInstance(m)) return (T) m;
        return null;
    }

    public static void tick() {
        for (Module m : MODULES) {
            m.onAlwaysTick();
            if (m.isEnabled()) m.onTick();
        }
    }

    /** Phim tat tung module: bam 1 lan = bat/tat. */
    public static void tickKeys(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.key < 0) {
                m.keyDown = false;
                continue;
            }
            boolean down = mc.player != null
                    && InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.key);
            // Chi bat/tat khi khong mo man hinh nao; giu phim luc dong GUI khong tinh la bam moi.
            if (down && !m.keyDown && mc.currentScreen == null) {
                m.toggle();
                Config.save();
            }
            m.keyDown = down;
        }
    }
}
