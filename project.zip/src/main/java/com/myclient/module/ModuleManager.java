package com.myclient.module;

import com.myclient.module.impl.AntiRekit;
import com.myclient.module.impl.FullBright;
import com.myclient.module.impl.HudModule;
import com.myclient.module.impl.Nametags;
import com.myclient.module.impl.NoPush;
import com.myclient.module.impl.NoRender;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.add(new AntiRekit());
        MODULES.add(new NoPush());
        MODULES.add(new Nametags());
        MODULES.add(new NoRender());
        MODULES.add(new HudModule());
        MODULES.add(new FullBright());
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> cls) {
        for (Module m : MODULES) if (cls.isInstance(m)) return (T) m;
        return null;
    }

    public static void tick() {
        for (Module m : MODULES) {
            m.onAlwaysTick();
            if (m.isEnabled()) m.onTick();
        }
    }
}
