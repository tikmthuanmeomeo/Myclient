package com.myclient.module;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private boolean enabled;
    /** Phim bat/tat (ma GLFW), -1 = chua gan. */
    public int key = -1;
    public boolean keyDown;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() { }

    public void onDisable() { }

    /** Chay moi tick khi module dang bat. */
    public void onTick() { }

    /** Chay moi tick bat ke module bat hay tat. */
    public void onAlwaysTick() { }
}
