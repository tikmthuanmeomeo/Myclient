package com.myclient.module;

import com.myclient.gui.ChatNotify;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class Module {
    public final String name;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private boolean enabled;
    /** Phim bat/tat (ma GLFW), -1 = chua gan. */
    public int key = -1;
    public boolean keyDown;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    /** Tat ca setting (ke ca setting con trong Group), key = "Group.Ten" cho setting con. */
    public Map<String, Setting> flat() {
        Map<String, Setting> out = new LinkedHashMap<>();
        for (Setting s : settings) collect(out, "", s);
        return out;
    }

    private static void collect(Map<String, Setting> out, String prefix, Setting s) {
        out.put(prefix + s.name, s);
        if (s instanceof Setting.Group g) {
            for (Setting c : g.children) collect(out, prefix + g.name + ".", c);
        }
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        ChatNotify.toggle(name, value);
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() { }

    public void onDisable() { }

    /** Chay moi tick khi module dang bat. */
    public void onTick() { }

    /** Chay moi tick bat ke module bat hay tat. */
    public void onAlwaysTick() { }

    /** Chay moi khung hinh khi module dang bat (nhanh hon onTick, dung cho thu can toc do cao). */
    public void onFrame() { }
}
