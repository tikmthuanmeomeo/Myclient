package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import com.myclient.util.BreakTracker;
import com.myclient.util.Util;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Phan chung cua SelfTrap / Surround (port logic tu AlienClient): dat obsidian quanh nguoi. */
public abstract class PlaceBase extends Module {
    public final Setting.Num placeDelay = add(new Setting.Num("PlaceDelay", 50, 0, 500, 10));
    public final Setting.Num blocksPer = add(new Setting.Num("BlocksPer", 1, 1, 8, 1));
    public final Setting.Bool extend = add(new Setting.Bool("Extend", true));
    public final Setting.Bool packetPlace = add(new Setting.Bool("PacketPlace", true));
    public final Setting.Bool breakCrystal = add(new Setting.Bool("Break", true));
    public final Setting.Bool eatPause = add(new Setting.Bool("EatingPause", true));
    public final Setting.Bool center = add(new Setting.Bool("Center", true));
    public final Setting.Bool inventory = add(new Setting.Bool("InventorySwap", true));
    public final Setting.Bool enderChest = add(new Setting.Bool("EnderChest", true));
    public final Setting.Bool airPlace = add(new Setting.Bool("AirPlace", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    public final Setting.Bool inAir = add(new Setting.Bool("InAir", true));
    public final Setting.Bool detectMining = add(new Setting.Bool("DetectMining", false));
    public final Setting.Bool usingPause = add(new Setting.Bool("UsingPause", true));
    public final Setting.Bool moveDisable = add(new Setting.Bool("MoveDisable", true));
    public final Setting.Bool jumpDisable = add(new Setting.Bool("JumpDisable", true));

    protected long lastPlace;
    protected int progress;
    protected double startX, startY, startZ;
    protected boolean shouldCenter = true;

    protected PlaceBase(String name, Category category) {
        super(name, category);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) {
            if (moveDisable.value || jumpDisable.value) toggle();
            return;
        }
        startX = mc.player.getX();
        startY = mc.player.getY();
        startZ = mc.player.getZ();
        shouldCenter = true;
    }

    /** Cac kiem tra chung dau tick. Tra ve false neu khong nen dat block luc nay. */
    protected boolean preTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return false;
        if (inventory.value && !Util.inInventory()) return false;
        if (System.currentTimeMillis() - lastPlace < placeDelay.value) return false;
        progress = 0;
        if (!Util.isMoving() && !mc.options.jumpKey.isPressed()) {
            startX = mc.player.getX();
            startY = mc.player.getY();
            startZ = mc.player.getZ();
        }
        double dist = Math.sqrt(mc.player.squaredDistanceTo(startX, startY, startZ));
        if (getBlock() == -1) {
            onNoBlock();
            return false;
        }
        if ((moveDisable.value && dist > 1.0) || (jumpDisable.value && mc.player.input.jumping)) {
            toggle();
            return false;
        }
        if (usingPause.value && mc.player.isUsingItem()) return false;
        if (!inAir.value && !mc.player.isOnGround()) return false;
        doCenter();
        return true;
    }

    protected void onNoBlock() {
        toggle();
    }

    /** Keo nguoi choi ve giua o (thay cho MoveEvent cua Alien). */
    private void doCenter() {
        if (!center.value || mc.player.isFallFlying()) return;
        BlockPos bp = Util.playerPos(true);
        double dx = mc.player.getX() - bp.getX() - 0.5;
        double dz = mc.player.getZ() - bp.getZ() - 0.5;
        Vec3d v = mc.player.getVelocity();
        if (Math.abs(dx) <= 0.2 && Math.abs(dz) <= 0.2) {
            if (shouldCenter && (mc.player.isOnGround() || Util.isMoving())) {
                mc.player.setVelocity(0, v.y, 0);
                shouldCenter = false;
            }
        } else if (shouldCenter) {
            Vec3d c = bp.toCenterPos();
            double ddx = c.x - mc.player.getX();
            double ddz = c.z - mc.player.getZ();
            double dist = Math.hypot(ddx, ddz);
            if (dist > 1.0E-4) {
                double capped = Math.min(0.2873, dist);
                mc.player.setVelocity(ddx / dist * capped, v.y, ddz / dist * capped);
            }
        }
    }

    // ------------------------------------------------------------ dat block
    protected boolean hasSide(BlockPos pos) {
        return Util.supportSide(pos, 6) != null || (airPlace.value && Util.canReach(pos, 6));
    }

    protected void tryPlace(BlockPos pos) {
        if (pos == null) return;
        if (detectMining.value && BreakTracker.isMining(pos)) return;
        if (progress >= blocksPer.value) return;
        int slot = getBlock();
        if (slot == -1) return;
        Direction side = Util.supportSide(pos, 6);
        if (side == null && !(airPlace.value && Util.canReach(pos, 6))) return;
        if (!Util.canPlace(pos, 6, true, airPlace.value)) return;
        if (breakCrystal.value) {
            Util.attackCrystal(pos, rotate.value, eatPause.value);
        } else if (Util.hasEntity(new Box(pos), false)) {
            return;
        }
        int old = mc.player.getInventory().selectedSlot;
        doSwap(slot);
        Util.place(pos, side, packetPlace.value, rotate.value);
        lastPlace = System.currentTimeMillis();
        if (inventory.value) {
            doSwap(slot);
        } else {
            Util.switchToSlot(old);
        }
        progress++;
    }

    protected void doSwap(int slot) {
        if (inventory.value) Util.inventorySwap(slot);
        else Util.switchToSlot(slot);
    }

    protected int getBlock() {
        if (inventory.value) {
            int s = Util.findBlockInv(Blocks.OBSIDIAN);
            if (s != -1 || !enderChest.value) return s;
            return Util.findBlockInv(Blocks.ENDER_CHEST);
        }
        int s = Util.findBlockHotbar(Blocks.OBSIDIAN);
        if (s != -1 || !enderChest.value) return s;
        return Util.findBlockHotbar(Blocks.ENDER_CHEST);
    }

    /** O de dat truoc (lam diem tua) khi o can dat chua co block ben canh. */
    protected BlockPos getHelperPos(BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (detectMining.value && BreakTracker.isMining(n)) continue;
            if (Util.canPlace(n, 6, false, airPlace.value)) return n;
        }
        return null;
    }

    /** Nguoi (hoac ke dich, tuy module) dang chiem o nay -> can mo rong vong bao ve. */
    protected abstract boolean shouldExtend(BlockPos pos);

    /** Dat vong block quanh pos (4 huong ngang + phia duoi), mo rong neu nguoi chiem nhieu o. */
    protected void doSurround(BlockPos pos) {
        for (Direction i : Direction.values()) {
            if (i == Direction.UP) continue;
            BlockPos off = pos.offset(i);
            if (hasSide(off)) {
                tryPlace(off);
            } else if (Util.canReplace(off)) {
                tryPlace(getHelperPos(off));
            }
            if (shouldExtend(off) && extend.value) {
                for (Direction i2 : Direction.values()) {
                    if (i2 == Direction.UP) continue;
                    BlockPos off2 = off.offset(i2);
                    if (shouldExtend(off2)) {
                        for (Direction i3 : Direction.values()) {
                            if (i3 == Direction.UP) continue;
                            tryPlace(off2);
                            BlockPos off3 = off2.offset(i3);
                            tryPlace(hasSide(off3) || !Util.canReplace(off3) ? off3 : getHelperPos(off3));
                        }
                    }
                    tryPlace(hasSide(off2) || !Util.canReplace(off2) ? off2 : getHelperPos(off2));
                }
            }
        }
    }
}
