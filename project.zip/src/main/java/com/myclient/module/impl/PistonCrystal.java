package com.myclient.module.impl;

import com.myclient.gui.ChatNotify;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import com.myclient.util.CrystalUtil;
import com.myclient.util.Util;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** PistonCrystal port tu AlienClient: dung piston + redstone block + crystal day crystal vao ke dich. */
public class PistonCrystal extends Module {
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", false));
    public final Setting.Bool pistonPacket = add(new Setting.Bool("PistonPacket", false));
    public final Setting.Bool noEating = add(new Setting.Bool("NoEating", true));
    public final Setting.Bool eatingBreak = add(new Setting.Bool("EatingBreak", false));
    public final Setting.Num placeRange = add(new Setting.Num("PlaceRange", 5, 1, 8, 0.5));
    public final Setting.Num range = add(new Setting.Num("Range", 4, 1, 8, 0.5));
    public final Setting.Bool fire = add(new Setting.Bool("Fire", true));
    public final Setting.Bool switchPos = add(new Setting.Bool("Switch", false));
    public final Setting.Bool onlyGround = add(new Setting.Bool("SelfGround", true));
    public final Setting.Bool onlyStatic = add(new Setting.Bool("MovingPause", true));
    public final Setting.Num updateDelay = add(new Setting.Num("PlaceDelay", 100, 0, 500, 10));
    public final Setting.Num posUpdateDelay = add(new Setting.Num("PosUpdateDelay", 500, 0, 1000, 10));
    public final Setting.Num stageSetting = add(new Setting.Num("Stage", 4, 1, 10, 1));
    public final Setting.Num pistonStage = add(new Setting.Num("PistonStage", 1, 1, 10, 1));
    public final Setting.Num pistonMaxStage = add(new Setting.Num("PistonMaxStage", 1, 1, 10, 1));
    public final Setting.Num powerStage = add(new Setting.Num("PowerStage", 3, 1, 10, 1));
    public final Setting.Num powerMaxStage = add(new Setting.Num("PowerMaxStage", 3, 1, 10, 1));
    public final Setting.Num crystalStage = add(new Setting.Num("CrystalStage", 4, 1, 10, 1));
    public final Setting.Num crystalMaxStage = add(new Setting.Num("CrystalMaxStage", 4, 1, 10, 1));
    public final Setting.Num fireStage = add(new Setting.Num("FireStage", 2, 1, 10, 1));
    public final Setting.Num fireMaxStage = add(new Setting.Num("FireMaxStage", 2, 1, 10, 1));
    public final Setting.Bool inventory = add(new Setting.Bool("InventorySwap", true));
    public final Setting.Bool lowVersion = add(new Setting.Bool("LowVersion", false));
    public final Setting.Bool debug = add(new Setting.Bool("Debug", false));
    public final Setting.Group render = add(new Setting.Group("Render", true, true));
    public final Setting.Color pistonFill = render.add(new Setting.Color("PistonFill", 0x404D6BFF));
    public final Setting.Color pistonOutline = render.add(new Setting.Color("PistonOutline", 0xFF4D6BFF));
    public final Setting.Color crystalFill = render.add(new Setting.Color("CrystalFill", 0x40FF4D6B));
    public final Setting.Color crystalOutline = render.add(new Setting.Color("CrystalOutline", 0xFFFF4D6B));
    public final Setting.Num lineWidth = render.add(new Setting.Num("LineWidth", 1.0, 0.5, 5, 0.5));

    private long timer, crystalTimer;
    public BlockPos bestPos, bestOPos;
    public Direction bestFacing;
    public double distance = 100;
    public boolean getPos;
    public int stage = 1;
    private PlayerEntity target;
    private boolean isPiston;

    public PistonCrystal() {
        super("PistonCrystal", Category.COMBAT);
    }

    private static long now() { return System.currentTimeMillis(); }

    @Override
    public void onDisable() {
        bestPos = null;
        bestOPos = null;
        bestFacing = null;
        getPos = false;
    }

    /** Ve o piston va o crystal dang nham (goi tu WorldRenderEvents). */
    public void renderWorld(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext ctx) {
        if (!isEnabled() || !render.enabled || !getPos || bestPos == null || bestOPos == null || bestFacing == null) return;
        com.myclient.util.BoxRender.draw(ctx, new Box(bestPos), pistonFill.argb(), pistonOutline.argb(), (float) lineWidth.value, 1f);
        com.myclient.util.BoxRender.draw(ctx, new Box(bestOPos.offset(bestFacing)), crystalFill.argb(), crystalOutline.argb(), (float) lineWidth.value, 1f);
    }

    @Override
    public void onEnable() {
        bestPos = null;
        bestOPos = null;
        bestFacing = null;
        isPiston = false;
    }

    private void clampStages() {
        double max = stageSetting.value;
        for (Setting.Num n : new Setting.Num[]{pistonStage, fireStage, powerStage, crystalStage,
                pistonMaxStage, fireMaxStage, powerMaxStage, crystalMaxStage}) {
            if (n.value > max) n.value = max;
        }
        if (crystalMaxStage.value < crystalStage.value) crystalStage.value = crystalMaxStage.value;
        if (powerMaxStage.value < powerStage.value) powerStage.value = powerMaxStage.value;
        if (pistonMaxStage.value < pistonStage.value) pistonStage.value = pistonMaxStage.value;
        if (fireMaxStage.value < fireStage.value) fireStage.value = fireMaxStage.value;
    }

    // ------------------------------------------------------------ tick
    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        clampStages();
        target = CrystalUtil.closestEnemy(range.value);
        if (target == null) return;
        if (noEating.value && mc.player.isUsingItem()) return;
        if (check(onlyStatic.value, !mc.player.isOnGround(), onlyGround.value)) return;

        BlockPos pos = BlockPos.ofFloored(target.getX(), target.getY() + 0.3, target.getZ());
        if (!mc.player.isUsingItem() || eatingBreak.value) {
            for (int i = 0; i <= 2; i++) {
                if (checkCrystal(pos.up(i))) Util.attackCrystal(pos.up(i), rotate.value, true);
            }
        }
        if (bestPos != null && mc.world.getBlockState(bestPos).getBlock() instanceof PistonBlock) {
            isPiston = true;
        } else if (isPiston) {
            isPiston = false;
            crystalTimer = now();
            bestPos = null;
        }
        if (now() - crystalTimer >= posUpdateDelay.value) {
            stage = 0;
            distance = 100;
            getPos = false;
            getBestPos(pos.up(2));
            getBestPos(pos.up());
        }
        if (now() - timer < updateDelay.value) return;
        if (getPos && bestPos != null) {
            timer = now();
            if (debug.value && mc.player != null) {
                mc.player.sendMessage(Text.literal("[PistonCrystal] piston=" + bestPos.toShortString()
                        + " facing=" + bestFacing + " crystal=" + bestOPos.offset(bestFacing).toShortString()), false);
            }
            doPistonAura(bestPos, bestFacing, bestOPos);
        }
    }

    /** true = khong du dieu kien chay. */
    private boolean check(boolean onlyStatic, boolean offGround, boolean onlyGround) {
        if (Util.isMoving() && onlyStatic) return true;
        if (offGround && onlyGround) return true;
        if (findBlock(Blocks.REDSTONE_BLOCK) == -1) return true;
        if (findPiston() == -1) return true;
        return findItem(Items.END_CRYSTAL) == -1;
    }

    private boolean checkCrystal(BlockPos pos) {
        for (Entity e : CrystalUtil.entitiesIn(new Box(pos))) {
            if (e instanceof EndCrystalEntity) {
                if (CrystalUtil.damage(e.getPos(), target) > 7) return true;
            }
        }
        return false;
    }

    private boolean checkCrystal2(BlockPos pos) {
        for (Entity e : CrystalUtil.entitiesIn(new Box(pos))) {
            if (e instanceof EndCrystalEntity && BlockPos.ofFloored(e.getPos()).equals(pos)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------ tim vi tri
    private void getBestPos(BlockPos pos) {
        for (Direction i : Direction.values()) {
            if (i == Direction.DOWN || i == Direction.UP) continue;
            getPos(pos, i);
        }
    }

    private void getPos(BlockPos pos, Direction i) {
        if (!CrystalUtil.canPlaceCrystal(pos.offset(i), false) && !checkCrystal2(pos.offset(i))) return;
        getPos(pos.offset(i, 3), i, pos);
        getPos(pos.offset(i, 3).up(), i, pos);
        int offsetX = pos.offset(i).getX() - pos.getX();
        int offsetZ = pos.offset(i).getZ() - pos.getZ();
        getPos(pos.offset(i, 3).add(offsetZ, 0, offsetX), i, pos);
        getPos(pos.offset(i, 3).add(-offsetZ, 0, -offsetX), i, pos);
        getPos(pos.offset(i, 3).add(offsetZ, 1, offsetX), i, pos);
        getPos(pos.offset(i, 3).add(-offsetZ, 1, -offsetX), i, pos);

        getPos(pos.offset(i, 2), i, pos);
        getPos(pos.offset(i, 2).up(), i, pos);
        getPos(pos.offset(i, 2).add(offsetZ, 0, offsetX), i, pos);
        getPos(pos.offset(i, 2).add(-offsetZ, 0, -offsetX), i, pos);
        getPos(pos.offset(i, 2).add(offsetZ, 1, offsetX), i, pos);
        getPos(pos.offset(i, 2).add(-offsetZ, 1, -offsetX), i, pos);
    }

    private void getPos(BlockPos pos, Direction facing, BlockPos oPos) {
        if (switchPos.value && bestPos != null && bestPos.equals(pos) && mc.world.isAir(bestPos)) return;
        if (!canPlaceBlock(pos, placeRange.value) && !(getBlock(pos) instanceof PistonBlock)) return;
        if (findPiston() == -1) return;
        if (lowVersion.value && !(getBlock(pos) instanceof PistonBlock)
                && (mc.player.getY() - pos.getY() <= -2.0 || mc.player.getY() - pos.getY() >= 3.0)
                && Math.hypot(pos.getX() + 0.5 - mc.player.getX(), pos.getZ() + 0.5 - mc.player.getZ()) < 2.6) {
            return;
        }
        if (!mc.world.isAir(pos.offset(facing, -1)) || getBlock(pos.offset(facing, -1)) == Blocks.FIRE
                || getBlock(pos.offset(facing.getOpposite())) == Blocks.MOVING_PISTON && !checkCrystal2(pos.offset(facing.getOpposite()))) {
            return;
        }
        if (!canPlaceBlock(pos, placeRange.value) && !isPistonReady(pos, facing)) return;
        double d = MathHelper.sqrt((float) mc.player.getEyePos().squaredDistanceTo(pos.toCenterPos()));
        if (!(d < distance || bestPos == null)) return;
        bestPos = pos;
        bestOPos = oPos;
        bestFacing = facing;
        distance = d;
        getPos = true;
        crystalTimer = now();
    }

    private boolean isPistonReady(BlockPos pos, Direction facing) {
        if (!(mc.world.getBlockState(pos).getBlock() instanceof PistonBlock)) return false;
        if (mc.world.getBlockState(pos).get(FacingBlock.FACING).getOpposite() != facing) return false;
        return mc.world.isAir(pos.offset(facing, -1)) || getBlock(pos.offset(facing, -1)) == Blocks.FIRE
                || getBlock(pos.offset(facing.getOpposite())) == Blocks.MOVING_PISTON;
    }

    // ------------------------------------------------------------ thuc thi
    private void doPistonAura(BlockPos pos, Direction facing, BlockPos oPos) {
        if (stage >= stageSetting.value) stage = 0;
        stage++;
        if (mc.world.isAir(pos)) {
            if (canPlaceBlock(pos, 1000)) {
                if (stage >= pistonStage.value && stage <= pistonMaxStage.value) {
                    Direction side = Util.supportSide(pos, 1000);
                    if (side == null) return;
                    int old = mc.player.getInventory().selectedSlot;
                    pistonFacing(facing);
                    int piston = findPiston();
                    if (piston == -1) return;
                    doSwap(piston);
                    Util.place(pos, side, pistonPacket.value, false);
                    if (inventory.value) doSwap(piston);
                    else doSwap(old);
                    Util.snapBack();
                    if (rotate.value) {
                        BlockPos neighbour = pos.offset(side);
                        Direction opposite = side.getOpposite();
                        Util.lookAt(neighbour.toCenterPos().add(opposite.getOffsetX() * 0.5, opposite.getOffsetY() * 0.5, opposite.getOffsetZ() * 0.5));
                    }
                }
            } else {
                return;
            }
        }
        if (stage >= powerStage.value && stage <= powerMaxStage.value) doRedStone(pos, facing, oPos.offset(facing));
        if (stage >= crystalStage.value && stage <= crystalMaxStage.value) placeCrystal(oPos, facing);
        if (stage >= fireStage.value && stage <= fireMaxStage.value) doFire(oPos, facing);
    }

    /** Dat huong piston bang cach gui goc xoay (piston quay mat ve phia nguoi dat). */
    private void pistonFacing(Direction d) {
        float yaw;
        switch (d) {
            case EAST -> yaw = -90.0f;
            case WEST -> yaw = 90.0f;
            case NORTH -> yaw = 180.0f;
            case SOUTH -> yaw = 0.0f;
            default -> {
                return;
            }
        }
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, 5.0f, mc.player.isOnGround()));
    }

    private void placeCrystal(BlockPos pos, Direction facing) {
        if (!CrystalUtil.canPlaceCrystal(pos.offset(facing), false)) return;
        int crystal = findItem(Items.END_CRYSTAL);
        if (crystal == -1) return;
        int old = mc.player.getInventory().selectedSlot;
        doSwap(crystal);
        CrystalUtil.placeCrystal(pos.offset(facing), true);
        if (inventory.value) doSwap(crystal);
        else doSwap(old);
    }

    private boolean canFire(BlockPos pos) {
        if (Util.canReplace(pos.down())) return false;
        if (!mc.world.isAir(pos)) return false;
        return Util.canClick(pos.down());
    }

    private void doFire(BlockPos pos, Direction facing) {
        if (!fire.value) return;
        int flint = findItem(Items.FLINT_AND_STEEL);
        if (flint == -1) return;
        int old = mc.player.getInventory().selectedSlot;

        int[] xOffset = {0, facing.getOffsetZ(), -facing.getOffsetZ()};
        int[] yOffset = {0, 1};
        int[] zOffset = {0, facing.getOffsetX(), -facing.getOffsetX()};
        for (int x : xOffset) for (int y : yOffset) for (int z : zOffset) {
            if (getBlock(pos.add(x, y, z)) == Blocks.FIRE) return;
        }
        for (int x : xOffset) for (int y : yOffset) for (int z : zOffset) {
            BlockPos p = pos.add(x, y, z);
            if (canFire(p)) {
                doSwap(flint);
                placeFire(p);
                if (inventory.value) doSwap(flint);
                else doSwap(old);
                return;
            }
        }
    }

    private void placeFire(BlockPos pos) {
        BlockPos neighbour = pos.down();
        Vec3d vec = neighbour.toCenterPos().add(0, 0.5, 0);
        if (rotate.value) Util.lookAt(vec);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(vec, Direction.UP, neighbour, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        if (rotate.value) Util.snapBack();
    }

    private void doRedStone(BlockPos pos, Direction facing, BlockPos crystalPos) {
        if (!mc.world.isAir(pos.offset(facing, -1)) && getBlock(pos.offset(facing, -1)) != Blocks.FIRE
                && getBlock(pos.offset(facing.getOpposite())) != Blocks.MOVING_PISTON) return;
        for (Direction i : Direction.values()) {
            if (getBlock(pos.offset(i)) == Blocks.REDSTONE_BLOCK) return;
        }
        int power = findBlock(Blocks.REDSTONE_BLOCK);
        if (power == -1) return;
        int old = mc.player.getInventory().selectedSlot;

        Direction best = bestNeighboring(pos, facing);
        if (best != null && best != facing.getOpposite() && canPlaceBlock(pos.offset(best), placeRange.value)
                && !pos.offset(best).equals(crystalPos)) {
            placeRedstone(pos.offset(best), power, old);
            return;
        }
        for (Direction i : Direction.values()) {
            if (!canPlaceBlock(pos.offset(i), placeRange.value) || pos.offset(i).equals(crystalPos) || i == facing.getOpposite()) continue;
            placeRedstone(pos.offset(i), power, old);
            return;
        }
    }

    private void placeRedstone(BlockPos at, int slot, int old) {
        Direction side = Util.supportSide(at, 1000);
        if (side == null) return;
        doSwap(slot);
        Util.place(at, side, false, rotate.value);
        if (inventory.value) doSwap(slot);
        else doSwap(old);
    }

    private Direction bestNeighboring(BlockPos pos, Direction facing) {
        Direction best = null;
        double dist = 0;
        for (Direction i : Direction.values()) {
            if (facing != null && pos.offset(i).equals(pos.offset(facing, -1)) || i == Direction.DOWN) continue;
            if (Util.supportSide(pos, 1000) != null) {
                double d = mc.player.getEyePos().squaredDistanceTo(pos.offset(i).toCenterPos());
                if (best == null || d < dist) {
                    best = i;
                    dist = d;
                }
            }
        }
        return best;
    }

    // ------------------------------------------------------------ tien ich
    private boolean canPlaceBlock(BlockPos pos, double reach) {
        return Util.canPlace(pos, reach, false, false);
    }

    private Block getBlock(BlockPos pos) {
        return mc.world.getBlockState(pos).getBlock();
    }

    private void doSwap(int slot) {
        if (inventory.value) Util.inventorySwap(slot);
        else Util.switchToSlot(slot);
    }

    private int findItem(Item item) {
        return inventory.value ? Util.findInvSlot(item) : Util.findHotbar(item);
    }

    private int findBlock(Block block) {
        return inventory.value ? Util.findBlockInv(block) : Util.findBlockHotbar(block);
    }

    /** Slot chua piston (thuong hoac dinh). */
    private int findPiston() {
        for (int i = 35; i >= 0; i--) {
            if (!inventory.value && i >= 9) continue;
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.getItem() instanceof BlockItem bi && bi.getBlock() instanceof PistonBlock) {
                return inventory.value ? (i < 9 ? i + 36 : i) : i;
            }
        }
        return -1;
    }
}
