package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Friends;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Tu dong dap shulker KHONG phai do minh dat. */
public class AntiRekit extends Module {
    /** Ban kinh quet hinh tron quanh minh (10 = 20x20 block). */
    public final Setting.Num scanRadius = add(new Setting.Num("Scan radius", 10, 4, 16, 1));
    /** Khoang cach toi da de dap (server vanilla thuong chi cho ~4.5-6). */
    public final Setting.Num range = add(new Setting.Num("Break range", 10, 1.0, 10.0, 0.5));
    public final Setting.Bool autoTool = add(new Setting.Bool("Auto tool", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", false));
    /** Nguoi dat shulker tinh trong khoang nay quanh shulker luc no xuat hien. */
    public final Setting.Num placerRadius = add(new Setting.Num("Placer radius", 7.0, 3.0, 12.0, 1.0));

    private static class Entry {
        int age;
        boolean seen;
    }

    private enum Owner { SELF, FRIEND, HOSTILE }

    /** Chu cua tung shulker, xac dinh luc shulker xuat hien trong vung quet. */
    private final Map<BlockPos, Owner> owners = new HashMap<>();

    /** Vi tri shulker do chinh minh dat. */
    private final Map<BlockPos, Entry> mine = new HashMap<>();
    private int prevSlot = -1;

    public AntiRekit() {
        super("AntiRekit", Category.COMBAT);
    }

    /** Duoc goi tu mixin moi khi minh bam dat block. */
    public void onPlaceAttempt(ClientPlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack stack = player.getStackInHand(hand);
        if (!(stack.getItem() instanceof BlockItem bi)) return;
        if (!(bi.getBlock() instanceof ShulkerBoxBlock)) return;
        BlockPos pos = new ItemPlacementContext(player, hand, stack, hit).getBlockPos();
        mine.put(pos.toImmutable(), new Entry());
    }

    @Override
    public void onAlwaysTick() {
        if (mc.world == null) {
            mine.clear();
            return;
        }
        Iterator<Map.Entry<BlockPos, Entry>> it = mine.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Entry> e = it.next();
            Entry en = e.getValue();
            en.age++;
            boolean box = mc.world.getBlockState(e.getKey()).getBlock() instanceof ShulkerBoxBlock;
            if (box) en.seen = true;
            else if (en.seen || en.age > 40) it.remove();
        }
    }

    @Override
    public void onDisable() {
        owners.clear();
        restoreSlot();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        BlockPos target = findTarget();
        if (target == null) {
            restoreSlot();
            return;
        }

        BlockState state = mc.world.getBlockState(target);
        Vec3d center = Vec3d.ofCenter(target);
        Vec3d eye = mc.player.getEyePos();

        if (autoTool.value) selectTool(state);
        if (rotate.value) face(center, eye);

        Direction dir = Direction.getFacing(eye.x - center.x, eye.y - center.y, eye.z - center.z);
        if (mc.interactionManager.updateBlockBreakingProgress(target, dir)) {
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    /** Quet hinh tron ban kinh scanRadius quanh minh: ai dat shulker (tru minh va friend) thi dap. */
    private BlockPos findTarget() {
        double sr = scanRadius.value;
        int ri = (int) Math.ceil(sr);
        BlockPos base = mc.player.getBlockPos();
        Vec3d eye = mc.player.getEyePos();

        // don cac shulker da bien mat
        owners.keySet().removeIf(p -> !(mc.world.getBlockState(p).getBlock() instanceof ShulkerBoxBlock));

        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.iterate(base.add(-ri, -ri, -ri), base.add(ri, ri, ri))) {
            int dx = p.getX() - base.getX();
            int dz = p.getZ() - base.getZ();
            if (dx * dx + dz * dz > sr * sr) continue; // hinh tron tren mat phang ngang
            if (!(mc.world.getBlockState(p).getBlock() instanceof ShulkerBoxBlock)) continue;

            BlockPos key = p.toImmutable();
            Owner o = owners.get(key);
            if (o == null) {
                o = classify(key);
                owners.put(key, o);
            }
            if (o != Owner.HOSTILE) continue;

            double d = eye.squaredDistanceTo(Vec3d.ofCenter(p));
            if (d > range.value * range.value || d >= bestDist) continue;
            bestDist = d;
            best = key;
        }
        return best;
    }

    /** Xac dinh ai dat: minh, friend (nguoi gan nhat luc shulker xuat hien la friend) hoac nguoi khac. */
    private Owner classify(BlockPos p) {
        if (mine.containsKey(p)) return Owner.SELF;
        Vec3d c = Vec3d.ofCenter(p);
        double r2 = placerRadius.value * placerRadius.value;
        PlayerEntity nearest = null;
        double nd = Double.MAX_VALUE;
        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player) continue;
            double d = pl.squaredDistanceTo(c);
            if (d <= r2 && d < nd) {
                nd = d;
                nearest = pl;
            }
        }
        if (nearest != null && Friends.isFriend(nearest.getName().getString())) return Owner.FRIEND;
        return Owner.HOSTILE;
    }

    private void selectTool(BlockState state) {
        PlayerInventory inv = mc.player.getInventory();
        int best = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            float s = inv.getStack(i).getMiningSpeedMultiplier(state);
            if (s > bestSpeed) {
                bestSpeed = s;
                best = i;
            }
        }
        if (best != -1 && best != inv.selectedSlot) {
            if (prevSlot == -1) prevSlot = inv.selectedSlot;
            inv.selectedSlot = best;
        }
    }

    private void restoreSlot() {
        if (prevSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }

    private void face(Vec3d center, Vec3d eye) {
        Vec3d d = center.subtract(eye);
        double flat = Math.sqrt(d.x * d.x + d.z * d.z);
        mc.player.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        mc.player.setPitch((float) -Math.toDegrees(Math.atan2(d.y, flat)));
    }
}
