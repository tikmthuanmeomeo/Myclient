package com.myclient.module.impl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;

import java.util.Random;

/**
 * Skybox: troi dem toi mau xanh navy, sao nhap nhay dang net gach, cuc quang xanh la bay quanh 360 do.
 * Chi ap dung o Overworld (client-side). Ve cuc quang + sao nam trong WorldRendererMixin (renderSky).
 */
public class Skybox extends Module {
    public final Setting.Bool aurora = add(new Setting.Bool("Aurora", true));
    public final Setting.Num bands = add(new Setting.Num("Aurora bands", 7, 2, 10, 1));
    public final Setting.Num brightness = add(new Setting.Num("Aurora brightness", 1.0, 0.2, 2.0, 0.1));
    public final Setting.Num speed = add(new Setting.Num("Aurora speed", 1.0, 0.0, 3.0, 0.1));
    public final Setting.Num hue = add(new Setting.Num("Aurora hue", 150, 0, 360, 5));
    public final Setting.Bool stars = add(new Setting.Bool("Stars", true));
    public final Setting.Num starCount = add(new Setting.Num("Star count", 700, 0, 1500, 50));
    public final Setting.Bool horizonGlow = add(new Setting.Bool("Horizon glow", true));
    public final Setting.Bool clouds = add(new Setting.Bool("Dark clouds", true));
    public final Setting.Bool alwaysNight = add(new Setting.Bool("Always night", false));

    private static final int MAX_BANDS = 10;
    private static final int MAX_STARS = 1500;
    private static final int SEG = 44;   // so doan doc theo dai cuc quang
    private static final int ROWS = 6;   // so hang ngang qua be rong dai
    private static final float RADIUS = 90f;

    // tham so tung dai cuc quang (co dinh theo seed)
    private final float[] bJitter = new float[MAX_BANDS];
    private final float[] bSpan = new float[MAX_BANDS];
    private final float[] bEl = new float[MAX_BANDS];
    private final float[] bAmp = new float[MAX_BANDS];
    private final float[] bFreq = new float[MAX_BANDS];
    private final float[] bSlope = new float[MAX_BANDS];
    private final float[] bWidth = new float[MAX_BANDS];
    private final float[] bPhase = new float[MAX_BANDS];
    private final float[] bSpeed = new float[MAX_BANDS];

    // sao: moi sao 10 so: d(3) u(3) v(3) phase
    private final float[] star = new float[MAX_STARS * 10];

    private final float[] px = new float[(SEG + 1) * (ROWS + 1)];
    private final float[] py = new float[(SEG + 1) * (ROWS + 1)];
    private final float[] pz = new float[(SEG + 1) * (ROWS + 1)];
    private final float[] pa = new float[(SEG + 1) * (ROWS + 1)];
    private final float[] pc = new float[(SEG + 1) * (ROWS + 1)];

    public Skybox() {
        super("Skybox", Category.RENDER);
        Random r = new Random(1337);
        for (int b = 0; b < MAX_BANDS; b++) {
            bJitter[b] = (r.nextFloat() - 0.5f) * 0.9f;
            bSpan[b] = 1.6f + r.nextFloat() * 1.6f;
            bEl[b] = (float) Math.toRadians(30 + r.nextFloat() * 40);
            bAmp[b] = (float) Math.toRadians(6 + r.nextFloat() * 14);
            bFreq[b] = 0.8f + r.nextFloat() * 1.6f;
            bSlope[b] = (r.nextFloat() - 0.5f) * 1.2f;
            bWidth[b] = (float) Math.toRadians(9 + r.nextFloat() * 12);
            bPhase[b] = r.nextFloat() * 6.2831f;
            bSpeed[b] = (0.25f + r.nextFloat() * 0.5f) * (r.nextBoolean() ? 1f : -1f);
        }
        Random sr = new Random(42);
        for (int i = 0; i < MAX_STARS; i++) {
            float y = 0.03f + sr.nextFloat() * 0.97f;
            float a = sr.nextFloat() * 6.2831f;
            float rr = (float) Math.sqrt(1f - y * y);
            float dx = rr * (float) Math.cos(a), dy = y, dz = rr * (float) Math.sin(a);
            // tangent a
            float ax, ay, az;
            if (Math.abs(dy) > 0.99f) {
                ax = 1f; ay = 0f; az = 0f;
            } else {
                ax = dz; ay = 0f; az = -dx; // cross(up, d)
                float l = (float) Math.sqrt(ax * ax + az * az);
                ax /= l; az /= l;
            }
            // b = cross(d, a)
            float bx = dy * az - dz * ay, by = dz * ax - dx * az, bz = dx * ay - dy * ax;
            float ang = sr.nextFloat() * 6.2831f;
            float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
            float ux = ax * ca + bx * sa, uy = ay * ca + by * sa, uz = az * ca + bz * sa;
            // v = cross(d, u)
            float vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux;
            float size = 0.6f + sr.nextFloat() * 1.0f;
            float len = 0.011f * size * RADIUS;
            float wid = len * 0.28f;
            int o = i * 10;
            star[o] = dx; star[o + 1] = dy; star[o + 2] = dz;
            star[o + 3] = ux * len; star[o + 4] = uy * len; star[o + 5] = uz * len;
            star[o + 6] = vx * wid; star[o + 7] = vy * wid; star[o + 8] = vz * wid;
            star[o + 9] = sr.nextFloat() * 6.2831f;
        }
    }

    /** Chi ap dung o Overworld. */
    public boolean isActive() {
        return isEnabled() && mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD;
    }

    private static Vec3d rgb(int c) {
        return new Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
    }

    /** Mau troi: navy gan nhu den. */
    public Vec3d skyColor() {
        return rgb(MathHelper.hsvToRgb(230f / 360f, 0.85f, 0.045f));
    }

    /** Mau chan troi / suong: xanh nhat. */
    public Vec3d horizonColor() {
        return rgb(MathHelper.hsvToRgb(225f / 360f, 0.30f, 0.96f));
    }

    public Vec3d cloudColor() {
        return rgb(MathHelper.hsvToRgb(225f / 360f, 0.5f, 0.22f));
    }

    // ------------------------------------------------------------------ render
    /** Goi cuoi WorldRenderer.renderSky voi ma tran xoay camera (diem tinh theo huong, khong tinh vi tri camera). */
    public void render(Matrix4f mat, Camera cam) {
        if (!isActive()) return;
        if (cam.getSubmersionType() != CameraSubmersionType.NONE) return;

        double t = System.nanoTime() / 1.0e9;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (stars.value) drawStars(mat, t);
        if (aurora.value) drawAurora(mat, t);

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private void drawStars(Matrix4f mat, double t) {
        int n = (int) starCount.value;
        if (n <= 0) return;
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < n; i++) {
            int o = i * 10;
            float tw = 0.55f + 0.45f * (float) Math.sin(t * 1.6 + star[o + 9]);
            float a = 0.9f * tw;
            float cx = star[o] * RADIUS, cy = star[o + 1] * RADIUS, cz = star[o + 2] * RADIUS;
            float ux = star[o + 3], uy = star[o + 4], uz = star[o + 5];
            float vx = star[o + 6], vy = star[o + 7], vz = star[o + 8];
            buf.vertex(mat, cx - ux - vx, cy - uy - vy, cz - uz - vz).color(1f, 1f, 1f, a);
            buf.vertex(mat, cx + ux - vx, cy + uy - vy, cz + uz - vz).color(1f, 1f, 1f, a);
            buf.vertex(mat, cx + ux + vx, cy + uy + vy, cz + uz + vz).color(1f, 1f, 1f, a);
            buf.vertex(mat, cx - ux + vx, cy - uy + vy, cz - uz + vz).color(1f, 1f, 1f, a);
        }
        BufferRenderer.drawWithGlobalProgram(buf.end());
    }

    private static float noise(double x, double t, float seed) {
        double v = Math.sin(x * 1.7 + t + seed) * 0.5
                + Math.sin(x * 3.1 - t * 1.3 + seed * 2.0) * 0.3
                + Math.sin(x * 5.3 + t * 0.7 - seed) * 0.2;
        return (float) (0.5 + 0.5 * v);
    }

    private void drawAurora(Matrix4f mat, double t) {
        int nb = (int) bands.value;
        float inten = (float) brightness.value;
        double ts = t * speed.value;

        int darkC = MathHelper.hsvToRgb((float) hue.value / 360f, 0.85f, 0.55f);
        int brightC = MathHelper.hsvToRgb(((float) hue.value + 28f) % 360f / 360f, 0.55f, 1.0f);
        float dr = ((darkC >> 16) & 255) / 255f, dg = ((darkC >> 8) & 255) / 255f, db = (darkC & 255) / 255f;
        float br = ((brightC >> 16) & 255) / 255f, bg = ((brightC >> 8) & 255) / 255f, bb = (brightC & 255) / 255f;

        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        for (int b = 0; b < nb; b++) {
            float az0 = (float) (b * (Math.PI * 2.0 / nb)) + bJitter[b] + (float) (ts * 0.02 * bSpeed[b]);
            float span = bSpan[b];
            float seed = b * 1.9f;

            for (int i = 0; i <= SEG; i++) {
                float u = i / (float) SEG;
                float az = az0 + (u - 0.5f) * span;
                float elc = bEl[b]
                        + bAmp[b] * (float) Math.sin(u * 6.2831f * bFreq[b] + bPhase[b] + ts * bSpeed[b])
                        + bSlope[b] * (u - 0.5f) * span * 0.5f;
                float env = (float) Math.pow(Math.sin(Math.PI * u), 0.8);
                float lum = env * (0.25f + 0.9f * noise(u * 4.0 + b * 3.0, ts * 0.45, seed));
                lum = Math.min(1f, lum);

                for (int k = 0; k <= ROWS; k++) {
                    float f = k / (float) ROWS;
                    float el = Math.max(0.05f, elc + (f - 0.5f) * bWidth[b]);
                    float ce = (float) Math.cos(el);
                    int idx = i * (ROWS + 1) + k;
                    px[idx] = (float) Math.sin(az) * ce * RADIUS;
                    py[idx] = (float) Math.sin(el) * RADIUS;
                    pz[idx] = (float) Math.cos(az) * ce * RADIUS;
                    float prof = (float) Math.pow(Math.sin(Math.PI * f), 1.3);
                    pa[idx] = Math.min(1f, 0.85f * inten * lum * prof);
                    pc[idx] = Math.min(1f, lum * prof * 1.5f);
                }
            }

            for (int i = 0; i < SEG; i++) {
                for (int k = 0; k < ROWS; k++) {
                    int a = i * (ROWS + 1) + k;
                    int bI = (i + 1) * (ROWS + 1) + k;
                    int c = bI + 1;
                    int d = a + 1;
                    vert(buf, mat, a, dr, dg, db, br, bg, bb);
                    vert(buf, mat, bI, dr, dg, db, br, bg, bb);
                    vert(buf, mat, c, dr, dg, db, br, bg, bb);
                    vert(buf, mat, d, dr, dg, db, br, bg, bb);
                }
            }
        }
        BufferRenderer.drawWithGlobalProgram(buf.end());
    }

    private void vert(BufferBuilder buf, Matrix4f mat, int i,
                      float dr, float dg, float db, float br, float bg, float bb) {
        float m = pc[i];
        buf.vertex(mat, px[i], py[i], pz[i]).color(
                dr + (br - dr) * m, dg + (bg - dg) * m, db + (bb - db) * m, pa[i]);
    }
}
