package com.myclient.module.impl;

import com.myclient.config.Config;
import com.myclient.gui.Notifications;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Identifier;

import java.util.Locale;

/**
 * Luu bo cuc hotbar (o 1-9) va tu sap xep lai: client xem inventory, tim dung mon da luu roi doi vao dung o.
 * - "Save current hotbar": luu hotbar hien tai vao Slot 1..9 (tat lai ngay).
 * - Slot 1..9: ten item (vd end_crystal hoac minecraft:totem_of_undying). Sua tay duoc; de trong = khong dong o do.
 * - Bat module = sap xep 1 lan roi tu tat (tru khi bat "Auto arrange").
 */
public class HotbarSaver extends Module {
    public final Setting.Bool save = add(new Setting.Bool("Save current hotbar", false));
    public final Setting.Bool clear = add(new Setting.Bool("Clear all slots", false));
    public final Setting.Bool autoArrange = add(new Setting.Bool("Auto arrange", false));
    public final Setting.Num speed = add(new Setting.Num("Swaps per tick", 2, 1, 9, 1));
    public final Setting.Text[] slots = new Setting.Text[9];

    private boolean pending;
    private int counter;
    private int attempts;

    public HotbarSaver() {
        super("HotbarSaver", Category.PLAYER);
        for (int i = 0; i < 9; i++) {
            slots[i] = add(new Setting.Text("Slot " + (i + 1), "", 64));
        }
    }

    @Override
    public void onAlwaysTick() {
        if (save.value) {
            save.value = false;
            saveHotbar();
        }
        if (clear.value) {
            clear.value = false;
            for (Setting.Text t : slots) t.value = "";
            Config.save();
            Notifications.push("HotbarSaver: cleared all slots", null);
        }
    }

    private void saveHotbar() {
        if (mc.player == null) return;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            var st = inv.getStack(i);
            slots[i].value = st.isEmpty() ? "" : Registries.ITEM.getId(st.getItem()).toString();
        }
        Config.save();
        Notifications.push("HotbarSaver: hotbar saved", null);
    }

    @Override
    public void onEnable() {
        pending = true;
        attempts = 0;
        counter = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return; // dang mo shulker / chest...
        if (autoArrange.value && !pending && ++counter >= 10) {
            counter = 0;
            pending = true;
            attempts = 0;
        }
        if (!pending) return;

        int done = arrange();
        attempts++;
        if (done == 0 || attempts > 40) {
            pending = false;
            if (!autoArrange.value) {
                Notifications.push("HotbarSaver: hotbar arranged", null);
                setEnabled(false);
            }
        }
    }

    /** Sap xep toi da "speed" lan doi; tra ve so lan doi da lam (0 = da dung het hoac khong tim thay mon). */
    private int arrange() {
        PlayerInventory inv = mc.player.getInventory();
        Item[] want = new Item[9];
        for (int i = 0; i < 9; i++) want[i] = parse(slots[i].value);

        int done = 0;
        int max = Math.max(1, (int) speed.value);
        for (int i = 0; i < 9 && done < max; i++) {
            if (want[i] == null) continue;
            if (inv.getStack(i).isOf(want[i])) continue;
            int src = findSource(inv, want, i);
            if (src < 0) continue;
            int slotId = src < 9 ? 36 + src : src; // 0-8 hotbar -> slot 36-44, 9-35 giu nguyen
            mc.interactionManager.clickSlot(0, slotId, i, SlotActionType.SWAP, mc.player);
            done++;
        }
        return done;
    }

    /** Tim mon can cho o i: uu tien trong inventory chinh, sau do hotbar o khac chua dung cho. */
    private int findSource(PlayerInventory inv, Item[] want, int i) {
        for (int s = 9; s < 36; s++) {
            if (inv.getStack(s).isOf(want[i])) return s;
        }
        for (int j = 0; j < 9; j++) {
            if (j == i) continue;
            if (!inv.getStack(j).isOf(want[i])) continue;
            boolean placed = want[j] != null && inv.getStack(j).isOf(want[j]);
            if (!placed) return j;
        }
        return -1;
    }

    private static Item parse(String text) {
        if (text == null) return null;
        String t = text.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        if (t.isEmpty()) return null;
        if (!t.contains(":")) t = "minecraft:" + t;
        Identifier id = Identifier.tryParse(t);
        if (id == null) return null;
        Item it = Registries.ITEM.get(id);
        return it == Items.AIR ? null : it;
    }
}
