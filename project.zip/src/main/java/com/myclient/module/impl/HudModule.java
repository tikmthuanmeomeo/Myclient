package com.myclient.module.impl;

import com.myclient.gui.HudEditorScreen;
import com.myclient.hud.CountElement;
import com.myclient.hud.HudElement;
import com.myclient.hud.KeybindsElement;
import com.myclient.hud.PotionsElement;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

public class HudModule extends Module {
    public final Setting.Bool potions = add(new Setting.Bool("Potions", true));
    public final Setting.Bool keybinds = add(new Setting.Bool("Keybinds", true));
    public final Setting.Bool totems = add(new Setting.Bool("Totems", true));
    public final Setting.Bool obsidian = add(new Setting.Bool("Obsidian", true));
    public final Setting.Bool crystals = add(new Setting.Bool("Crystals", true));
    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Bool moduleList = add(new Setting.Bool("Module list", true));

    private final List<HudElement> elements = new ArrayList<>();

    public HudModule() {
        super("HUD", Category.RENDER);
        elements.add(new CountElement("Totems", totems, Items.TOTEM_OF_UNDYING, 3, 24));
        elements.add(new CountElement("Obsidian", obsidian, Items.OBSIDIAN, 3, 44));
        elements.add(new CountElement("Crystals", crystals, Items.END_CRYSTAL, 3, 64));
        elements.add(new PotionsElement(potions, 3, 86));
        elements.add(new KeybindsElement(keybinds, 3, 160));
    }

    public List<HudElement> elements() { return elements; }

    public void renderElements(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        if (mc.currentScreen instanceof HudEditorScreen) return;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        for (HudElement e : elements) {
            if (!e.toggle.value) continue;
            int w = e.w(false);
            int h = e.h(false);
            if (w <= 0) continue;
            int x = Math.max(0, Math.min(e.x, sw - w));
            int y = Math.max(0, Math.min(e.y, sh - h));
            e.draw(ctx, x, y, false);
        }
    }
}
