package com.myclient.module.impl;

import com.myclient.gui.Notifications;
import com.myclient.mixin.ClientWorldAccessor;
import com.myclient.module.Category;
import com.myclient.module.Friends;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.BedPart;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BedItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * BedAura - code tu viet. Chi hoat dong o Nether / End (o Overworld giuong khong no).
 *
 * Place    : dat giuong o cho gay nhieu sat thuong nhat len dich (vu no tai dau giuong, power 5).
 * Break    : bam chuot phai vao giuong de no (giuong cua minh hoac cua nguoi khac).
 * Refill   : tu keo giuong tu inventory len hotbar khi hotbar het giuong.
 * Targeting: min damage len dich, max damage len ban than, ban be (#friend) khong bao gio bi no.
 *
 * Luu y: sat thuong la UOC LUONG (khong tinh Blast Protection).
 */
public class BedAura extends Module {
    // ---- Place ----
    public final Setting.Group place = add(new Setting.Group("Place", true, true));
    public final Setting.Num placeRange = place.add(new Setting.Num("Range", 5.0, 1.0, 6.0, 0.5));
    public final Setting.Num placeWallRange = place.add(new Setting.Num("Wall range", 3.5, 1.0, 6.0, 0.5));
    public final Setting.Bool air = place.add(new Setting.Bool("Air", true));
    public final Setting.Bool placeRotate = place.add(new Setting.Bool("Rotate", true));
    public final Setting.Num placeDelay = place.add(new Setting.Num("Delay (ms)", 100, 0, 1000, 10));

    // ---- Break ----
    public final Setting.Group breaker = add(new Setting.Group("Break", true, true));
    public final Setting.Num breakRange = breaker.add(new Setting.Num("Range", 5.0, 1.0, 6.0, 0.5));
    public final Setting.Num breakWallRange = breaker.add(new Setting.Num("Wall range", 3.5, 1.0, 6.0, 0.5));
    public final Setting.Bool breakRotate = breaker.add(new Setting.Bool("Rotate", true));
    public final Setting.Num breakDelay = breaker.add(new Setting.Num("Delay (ms)", 100, 0, 1000, 10));

    // ---- Refill ----
    public final Setting.Group refill = add(new Setting.Group("Refill", true, true));
    public final Setting.Num refillSlot = refill.add(new Setting.Num("Hotbar slot", 9, 1, 9, 1));

    // ---- Targeting ----
    public final Setting.Group targeting = add(new Setting.Group("Targeting", false, true));
    public final Setting.Num minDamage = targeting.add(new Setting.Num("Min damage", 6.0, 0.0, 36.0, 0.5));
    public final Setting.Num maxDamage = targeting.add(new Setting.Num("Max damage", 12.0, 0.0, 36.0, 0.5));
    public final Setting.Num targetRange = targeting.add(new Setting.Num("Target range", 12.0, 3.0, 20.0, 1.0));

    private record Use(Hand hand, int slot) { }
    private record Cand(BlockPos head, BlockPos foot, Direction dir, float est) { }
    private record Pick(BlockPos head, BlockPos foot, Direction dir, float dmg, float score) { }

    private long nextPlace, nextBreak, nextRefill, lastWarn, lastClean;
    private final Map<BlockPos, Long> brokenAt = new HashMap<>();

    public BedAura() {
        super("BedAura", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        brokenAt.clear();
    }

    @Override
    public void onFrame() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) return;
        if (mc.currentScreen != null) return;
        long now = System.currentTimeMillis();

        if (mc.world.getDimension().bedWorks()) { // Overworld: giuong chi de ngu, khong no
            if (now - lastWarn > 8000) {
                lastWarn = now;
                Notifications.push("BedAura: beds only explode in Nether / End", null);
            }
            return;
        }

        if (now - lastClean > 2000) {
            lastClean = now;
            brokenAt.values().removeIf(t -> now - t > 2000);
        }

        if (refill.enabled && now >= nextRefill) refill(now);

        List<PlayerEntity> targets = findTargets();
        if (targets.isEmpty()) return;

        if (breaker.enabled && now >= nextBreak) doBreak(targets, now);
        if (place.enabled && now >= nextPlace) doPlace(targets, now);
    }

    // =====================================================================
    //  MUC TIEU
    // =====================================================================
    private List<PlayerEntity> findTargets() {
        double tr = targetRange.value;
        List<PlayerEntity> out = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isDead() || p.isSpectator() || p.getHealth() <= 0f) continue;
            if (Friends.isFriend(p.getName().getString())) continue;
            if (mc.player.squaredDistanceTo(p) > tr * tr) continue;
            out.add(p);
        }
        out.sort(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(p)));
        return out.size() > 3 ? new ArrayList<>(out.subList(0, 3)) : out;
    }

    private float health(LivingEntity e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    private long latencyMs() {
        long ms = 40;
        if (mc.getNetworkHandler() != null) {
            var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ms = e.getLatency();
        }
        return Math.max(1, Math.min(300, ms));
    }

    // =====================================================================
    //  TAM VOI / TUONG
    // =====================================================================
    /** Trong tam voi: nhin thang thay thi dung "range", bi tuong che thi dung "wall range". */
    private boolean inReach(Vec3d eye, BlockPos pos, double range, double wallRange) {
        Vec3d c = Vec3d.ofCenter(pos);
        double d = eye.distanceTo(c);
        if (d > Math.max(range, wallRange)) return false;
        if (d <= Math.min(range, wallRange)) return true;
        BlockHitResult r = mc.world.raycast(new RaycastContext(eye, c,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        boolean visible = r.getType() == net.minecraft.util.hit.HitResult.Type.MISS || r.getBlockPos().equals(pos);
        return visible ? d <= range : d <= wallRange;
    }

    // =====================================================================
    //  ROTATE (gui goi tin xoay dau, khong doi camera)
    // =====================================================================
    private void sendLook(float yaw, float pitch) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround()));
    }

    private float[] lookAt(Vec3d t) {
        Vec3d eye = mc.player.getEyePos();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));
        return new float[]{yaw, pitch};
    }

    private void sequencedBlockPacket(Hand hand, BlockHitResult hit) {
        try (PendingUpdateManager pum = ((ClientWorldAccessor) mc.world).myclient$getPendingUpdateManager().incrementSequence()) {
            int seq = pum.getSequence();
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(hand, hit, seq));
        }
    }

    // =====================================================================
    //  BREAK
    // =====================================================================
    private void doBreak(List<PlayerEntity> targets, long now) {
        Vec3d eye = mc.player.getEyePos();
        int r = (int) Math.ceil(Math.max(breakRange.value, breakWallRange.value));
        long gap = Math.max(80L, latencyMs() * 2 + 40);
        BlockPos pp = mc.player.getBlockPos();

        BlockPos bestPos = null;
        float bestDmg = -1f;
        for (BlockPos p : BlockPos.iterate(pp.add(-r, -r, -r), pp.add(r, r, r))) {
            BlockState s = mc.world.getBlockState(p);
            if (!(s.getBlock() instanceof BedBlock) || s.get(BedBlock.PART) != BedPart.HEAD) continue;
            BlockPos head = p.toImmutable();
            Long last = brokenAt.get(head);
            if (last != null && now - last < gap) continue;
            if (!inReach(eye, head, breakRange.value, breakWallRange.value)) continue;

            Vec3d c = Vec3d.ofCenter(head);
            if (!selfSafe(bedDamage(mc.player, c)) || !friendsSafe(c)) continue;
            float best = 0f;
            boolean ok = false;
            for (PlayerEntity t : targets) {
                float d = bedDamage(t, c);
                if (d >= minDamage.value || d >= health(t)) {
                    ok = true;
                    best = Math.max(best, d);
                }
            }
            if (ok && best > bestDmg) {
                bestDmg = best;
                bestPos = head;
            }
        }
        if (bestPos == null) return;

        Vec3d c = Vec3d.ofCenter(bestPos);
        float realYaw = mc.player.getYaw();
        float realPitch = mc.player.getPitch();
        if (breakRotate.value) {
            float[] yp = lookAt(c);
            sendLook(yp[0], yp[1]);
        }
        sequencedBlockPacket(Hand.MAIN_HAND, new BlockHitResult(c, Direction.UP, bestPos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        if (breakRotate.value) sendLook(realYaw, realPitch);

        brokenAt.put(bestPos, now);
        nextBreak = now + (long) breakDelay.value;

        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.noteBlast(c);
    }

    // =====================================================================
    //  PLACE
    // =====================================================================
    private Use resolveBed() {
        if (mc.player.getOffHandStack().getItem() instanceof BedItem) return new Use(Hand.OFF_HAND, -1);
        if (mc.player.getMainHandStack().getItem() instanceof BedItem) return new Use(Hand.MAIN_HAND, -1);
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() instanceof BedItem) return new Use(Hand.MAIN_HAND, i);
        }
        return null;
    }

    private void doPlace(List<PlayerEntity> targets, long now) {
        Use use = resolveBed();
        if (use == null) return;
        Pick best = findBestPlacement(targets);
        if (best == null) return;

        BlockHitResult hit = supportHit(best.foot());
        if (hit == null) return;

        PlayerInventory inv = mc.player.getInventory();
        float realYaw = mc.player.getYaw();
        float realPitch = mc.player.getPitch();
        int original = inv.selectedSlot;
        boolean switched = use.slot() >= 0 && use.slot() != original;

        if (placeRotate.value) sendLook(best.dir().asRotation(), realPitch); // huong giuong = huong nguoi choi
        if (switched) mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(use.slot()));
        sequencedBlockPacket(use.hand(), hit);
        mc.player.swingHand(use.hand());
        if (switched) mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(original));
        if (placeRotate.value) sendLook(realYaw, realPitch);

        nextPlace = now + (long) placeDelay.value;

        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.noteBlast(Vec3d.ofCenter(best.head()));
    }

    private Pick findBestPlacement(List<PlayerEntity> targets) {
        Vec3d eye = mc.player.getEyePos();
        Direction[] dirs = placeRotate.value
                ? new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}
                : new Direction[]{mc.player.getHorizontalFacing()};

        List<Cand> cands = new ArrayList<>();
        for (PlayerEntity t : targets) {
            BlockPos feet = t.getBlockPos();
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        BlockPos head = new BlockPos(feet.getX() + dx, feet.getY() + dy, feet.getZ() + dz);
                        if (!replaceable(head)) continue;
                        Vec3d src = Vec3d.ofCenter(head);
                        float est = estimateUpper(t, src);
                        if (est < minDamage.value && est < health(t)) continue;
                        for (Direction dir : dirs) {
                            BlockPos foot = head.offset(dir.getOpposite());
                            if (!replaceable(foot)) continue;
                            if (!inReach(eye, foot, placeRange.value, placeWallRange.value)) continue;
                            if (!entityFree(foot) || !entityFree(head)) continue;
                            if (supportHit(foot) == null) continue;
                            cands.add(new Cand(head.toImmutable(), foot.toImmutable(), dir, est));
                        }
                    }
                }
            }
        }
        if (cands.isEmpty()) return null;
        cands.sort((a, b) -> Float.compare(b.est(), a.est()));

        Pick bestP = null;
        int checked = 0;
        for (Cand c : cands) {
            if (checked++ >= 30) break;
            Vec3d src = Vec3d.ofCenter(c.head());
            float self = selfDamage(src);
            if (!selfSafe(self) || !friendsSafe(src)) continue;

            float bestTarget = 0f;
            boolean kill = false;
            boolean ok = false;
            for (PlayerEntity t : targets) {
                float d = bedDamage(t, src);
                boolean k = d >= health(t);
                if (d >= minDamage.value || k) {
                    ok = true;
                    bestTarget = Math.max(bestTarget, d);
                    if (k) kill = true;
                }
            }
            if (!ok) continue;
            float score = bestTarget + (kill ? 1000f : 0f) - self * 0.01f;
            if (bestP == null || score > bestP.score()) bestP = new Pick(c.head(), c.foot(), c.dir(), bestTarget, score);
        }
        return bestP;
    }

    private boolean replaceable(BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isReplaceable() && s.getFluidState().isEmpty();
    }

    private boolean entityFree(BlockPos p) {
        return mc.world.getOtherEntities(null, new Box(p),
                e -> !e.isSpectator() && !(e instanceof ItemEntity)).isEmpty();
    }

    /**
     * Mat de click khi dat giuong tai o "foot": dua vao block ke ben (uu tien phia duoi).
     * Khong co thi neu bat "Air" se click thang vao o trong (dat tren khong), con khong tra ve null.
     */
    private BlockHitResult supportHit(BlockPos foot) {
        Direction[] dirs = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : dirs) {
            BlockPos n = foot.offset(d);
            BlockState ns = mc.world.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty()) continue;
            Direction face = d.getOpposite();
            Vec3d hv = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            return new BlockHitResult(hv, face, n, false);
        }
        if (!air.value) return null;
        return new BlockHitResult(Vec3d.ofCenter(foot), Direction.UP, foot, false);
    }

    // =====================================================================
    //  REFILL
    // =====================================================================
    private void refill(long now) {
        nextRefill = now + 250;
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return;
        PlayerInventory inv = mc.player.getInventory();
        if (mc.player.getOffHandStack().getItem() instanceof BedItem) return;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() instanceof BedItem) return; // hotbar con giuong
        }
        int hot = (int) refillSlot.value - 1;
        for (int i = 9; i < 36; i++) {
            ItemStack st = inv.getStack(i);
            if (st.getItem() instanceof BedItem) {
                mc.interactionManager.clickSlot(0, i, hot, SlotActionType.SWAP, mc.player);
                return;
            }
        }
    }

    // =====================================================================
    //  SAT THUONG (uoc luong, power 5 => q = 10)
    // =====================================================================
    private float selfDamage(Vec3d src) {
        if (maxDamage.value >= 36.0) return 0f;
        return bedDamage(mc.player, src);
    }

    private boolean selfSafe(float self) {
        return self <= maxDamage.value;
    }

    private boolean friendsSafe(Vec3d src) {
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !Friends.isFriend(p.getName().getString())) continue;
            if (p.squaredDistanceTo(src) > 12 * 12) continue;
            if (bedDamage(p, src) > 0.5f) return false;
        }
        return true;
    }

    private float estimateUpper(LivingEntity e, Vec3d src) {
        double dist = Math.sqrt(e.squaredDistanceTo(src)) / 10.0;
        if (dist > 1.0) return 0f;
        double impact = 1.0 - dist;
        float raw = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * 10.0 + 1.0));
        return scaleDifficulty(raw);
    }

    private float bedDamage(LivingEntity e, Vec3d src) {
        double dist = Math.sqrt(e.squaredDistanceTo(src)) / 10.0;
        if (dist > 1.0) return 0f;
        double exposure = Explosion.getExposure(src, e);
        double impact = (1.0 - dist) * exposure;
        float dmg = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * 10.0 + 1.0));
        dmg = scaleDifficulty(dmg);

        float armor = (float) e.getArmor();
        float tough = (float) e.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        float f = 2.0f + tough / 4.0f;
        float g = MathHelper.clamp(armor - dmg / f, armor * 0.2f, 20.0f);
        dmg *= 1.0f - g / 25.0f;

        if (e.hasStatusEffect(StatusEffects.RESISTANCE)) {
            StatusEffectInstance inst = e.getStatusEffect(StatusEffects.RESISTANCE);
            if (inst != null) {
                int amp = inst.getAmplifier();
                dmg = Math.max(dmg * (25 - 5 * (amp + 1)) / 25f, 0f);
            }
        }
        return Math.max(dmg, 0f);
    }

    private float scaleDifficulty(float d) {
        Difficulty diff = mc.world.getDifficulty();
        return switch (diff) {
            case PEACEFUL -> 0f;
            case EASY -> Math.min(d / 2f + 1f, d);
            case NORMAL -> d;
            case HARD -> d * 3f / 2f;
        };
    }
}
