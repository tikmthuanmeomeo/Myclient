package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * FireworkSwap: khi dang bay bang elytra, bam phim "Bind" (khong lien quan phim bat/tat module)
 * se tu dong lay phao hoa (firework rocket) trong hotbar ra de bay nhanh, roi tra lai slot cu.
 * Vi du bind = Space: nhay 2 lan de vao che do bay, bam Space them 1 lan nua de dung phao hoa.
 */
public class FireworkSwap extends Module {
    public final Setting.KeyBind bind = add(new Setting.KeyBind("Bind", GLFW.GLFW_KEY_SPACE));
    public final Setting.Num cooldown = add(new Setting.Num("Cooldown (ticks)", 5, 0, 40, 1));

    private boolean wasDown;
    private boolean wasFlying;
    private int cd;

    public FireworkSwap() {
        super("FireworkSwap", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        wasDown = false;
        wasFlying = false;
        cd = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null || mc.getNetworkHandler() == null) return;
        boolean flying = mc.player.isFallFlying();
        boolean down = mc.currentScreen == null && bind.key >= 0
                && InputUtil.isKeyPressed(mc.getWindow().getHandle(), bind.key);
        boolean pressed = down && !wasDown;
        boolean flewBefore = wasFlying;
        wasDown = down;
        wasFlying = flying;
        if (cd > 0) cd--;

        // Phai da bay tu tick truoc (de lan bam Space thu 2 -> vao bay khong bi tinh la phao hoa)
        if (!pressed || !flying || !flewBefore || cd > 0) return;
        if (fire()) cd = (int) cooldown.value;
    }

    private boolean fire() {
        PlayerInventory inv = mc.player.getInventory();
        Hand hand = Hand.MAIN_HAND;
        int hotSlot = -1;   // phao hoa o hotbar (khac slot dang cam)
        int invSlot = -1;   // phao hoa o inventory chinh (slot 9-35)

        if (mc.player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            hand = Hand.OFF_HAND;
        } else if (mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) {
            hand = Hand.MAIN_HAND;
        } else {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                    hotSlot = i;
                    break;
                }
            }
            if (hotSlot < 0) {
                for (int i = 9; i < 36; i++) {
                    if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) {
                        invSlot = i;
                        break;
                    }
                }
            }
            if (hotSlot < 0 && invSlot < 0) return false;
        }

        int original = inv.selectedSlot;
        if (hotSlot >= 0) {
            // uu tien hotbar: chuyen slot, dung, tra lai
            inv.selectedSlot = hotSlot;
        } else if (invSlot >= 0) {
            // phao hoa trong inventory: doi vao slot dang cam, dung, doi lai
            mc.interactionManager.clickSlot(0, invSlot, original, SlotActionType.SWAP, mc.player);
        }

        ActionResult r = mc.interactionManager.interactItem(mc.player, hand);
        if (r.isAccepted()) mc.player.swingHand(hand);

        if (hotSlot >= 0) {
            inv.selectedSlot = original;
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(original));
        } else if (invSlot >= 0) {
            mc.interactionManager.clickSlot(0, invSlot, original, SlotActionType.SWAP, mc.player);
        }
        return true;
    }
}
