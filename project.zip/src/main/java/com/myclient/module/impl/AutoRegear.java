package com.myclient.module.impl;

import com.myclient.gui.ClickGuiScreen;
import com.myclient.gui.Notifications;
import com.myclient.gui.RegearAnim;
import com.myclient.module.Category;
import com.myclient.module.Friends;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Tu dat shulker (lay tu inventory) trong tam, mo ra, lay totem / crystal / obsidian
 * theo so luong da chinh, dong lai. Xong 1 shulker thi tu tat (neu bat Auto disable).
 */
public class AutoRegear extends Module {
    public final Setting.Bool obsidian = add(new Setting.Bool("Obsidian", true));
    public final Setting.Num obsidianStacks = add(new Setting.Num("Obsidian stacks", 2, 1, 9, 1));
    public final Setting.Bool crystals = add(new Setting.Bool("Crystals", true));
    public final Setting.Num crystalStacks = add(new Setting.Num("Crystal stacks", 2, 1, 9, 1));
    public final Setting.Bool totems = add(new Setting.Bool("Totems", true));
    public final Setting.Num totemCount = add(new Setting.Num("Totems amount", 3, 1, 9, 1));
    public final Setting.Num range = add(new Setting.Num("Place range", 4.5, 1.0, 4.5, 0.5));
    public final Setting.Bool avoidEnemies = add(new Setting.Bool("Far from enemies", true));
    public final Setting.Bool animation = add(new Setting.Bool("Animation", true));
    public final Setting.Bool autoDisable = add(new Setting.Bool("Auto disable", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 10, 1));

    private enum State { FIND, PLACE, WAIT_PLACED, OPEN, WAIT_OPEN, TAKE, CLOSE }

    private State state = State.FIND;
    private BlockPos shulkerPos;
    private int timeout, wait, cooldown, placeTries, openTries;
    private int needObs, needCry, needTot;
    private int hotbarSlot = -1, prevSlot = -1;
    private int takeOrder;
    private float scrX = Float.NaN, scrY = Float.NaN;

    public AutoRegear() {
        super("AutoRegear", Category.COMBAT);
    }

    private void go(State s) {
        state = s;
        timeout = 0;
    }

    @Override
    public void onEnable() {
        if (mc.currentScreen instanceof ClickGuiScreen) mc.setScreen(null);
        prevSlot = mc.player != null ? mc.player.getInventory().selectedSlot : -1;
        placeTries = 0;
        openTries = 0;
        hotbarSlot = -1;
        shulkerPos = null;
        wait = 0;
        cooldown = 0;
        scrX = scrY = Float.NaN;
        go(State.FIND);
    }

    /** Goi luc render the gioi: chieu vi tri shulker len man hinh (cho animation). */
    public void collect(WorldRenderContext ctx) {
        if (!isEnabled() || shulkerPos == null || mc.world == null) return;
        Camera cam = ctx.camera();
        Vec3d camPos = cam.getPos();
        Quaternionf inv = new Quaternionf(cam.getRotation()).conjugate();
        Matrix4f proj = new Matrix4f(RenderSystem.getProjectionMatrix());
        Vec3d pos = Vec3d.ofCenter(shulkerPos);
        Vector3f v = new Vector3f((float) (pos.x - camPos.x), (float) (pos.y - camPos.y), (float) (pos.z - camPos.z));
        inv.transform(v);
        Vector4f c = new Vector4f(v.x, v.y, v.z, 1.0f);
        proj.transform(c);
        if (c.w <= 0.01f) {
            scrX = scrY = Float.NaN;
            return;
        }
        scrX = (c.x / c.w * 0.5f + 0.5f) * mc.getWindow().getScaledWidth();
        scrY = (1.0f - (c.y / c.w * 0.5f + 0.5f)) * mc.getWindow().getScaledHeight();
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            if (mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler) mc.player.closeHandledScreen();
            if (prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }

    private void fail(String msg) {
        Notifications.push("AutoRegear: " + msg, null);
        setEnabled(false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (++timeout > 100) {
            fail("timed out");
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }
        switch (state) {
            case FIND -> find();
            case PLACE -> place();
            case WAIT_PLACED -> waitPlaced();
            case OPEN -> open();
            case WAIT_OPEN -> waitOpen();
            case TAKE -> take();
            case CLOSE -> close();
        }
    }

    private static boolean isShulker(ItemStack s) {
        return s.getItem() instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock;
    }

    // ---- tim shulker trong inventory ----
    private void find() {
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return; // dang mo man hinh khac
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (isShulker(inv.getStack(i))) {
                hotbarSlot = i;
                inv.selectedSlot = i;
                wait = 1;
                go(State.PLACE);
                return;
            }
        }
        for (int i = 9; i < 36; i++) {
            if (isShulker(inv.getStack(i))) {
                int target = inv.selectedSlot;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, i, target,
                        SlotActionType.SWAP, mc.player);
                hotbarSlot = target;
                wait = 3;
                go(State.PLACE);
                return;
            }
        }
        fail("no shulker in inventory");
    }

    // ---- dat shulker ----
    /** Nguoi choi khac (khong phai ban be) trong 48 block: moi de doa shulker cua minh. */
    private List<Vec3d> threats() {
        List<Vec3d> out = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator() || !p.isAlive()) continue;
            if (Friends.isFriend(p.getName().getString())) continue;
            if (p.squaredDistanceTo(mc.player) > 48 * 48) continue;
            out.add(p.getPos().add(0, 0.9, 0));
        }
        return out;
    }

    /**
     * Chon cho dat: trong tam voi cua minh, uu tien cho XA ke dich nhat (de ho kho dap),
     * dong thoi van gan minh (tru nhe theo khoang cach tu minh).
     */
    private BlockPos findPlacement() {
        double r = range.value;
        int ri = (int) Math.ceil(r);
        BlockPos base = mc.player.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        List<Vec3d> threats = avoidEnemies.value ? threats() : List.of();
        BlockPos best = null;
        double bestScore = -Double.MAX_VALUE;
        for (BlockPos p : BlockPos.iterate(base.add(-ri, -2, -ri), base.add(ri, 2, ri))) {
            BlockState s = mc.world.getBlockState(p);
            if (!s.isReplaceable() || !s.getFluidState().isEmpty()) continue;
            BlockPos down = p.down();
            BlockState ds = mc.world.getBlockState(down);
            if (ds.hasBlockEntity() || !ds.isSideSolidFullSquare(mc.world, down, Direction.UP)) continue;
            BlockPos up = p.up();
            if (!mc.world.getBlockState(up).getCollisionShape(mc.world, up).isEmpty()) continue; // lid can khoang trong
            if (mc.player.getBoundingBox().intersects(new Box(p))) continue;
            Vec3d c = Vec3d.ofCenter(p);
            double d2 = eye.squaredDistanceTo(c);
            if (d2 > r * r) continue;
            double score;
            if (threats.isEmpty()) {
                score = -d2; // khong co dich: lay cho gan nhat nhu cu
            } else {
                double nearest = Double.MAX_VALUE;
                for (Vec3d t : threats) nearest = Math.min(nearest, c.distanceTo(t));
                score = Math.min(nearest, 40.0) - 0.3 * Math.sqrt(d2);
            }
            if (score > bestScore) {
                bestScore = score;
                best = p.toImmutable();
            }
        }
        return best;
    }

    private void place() {
        PlayerInventory inv = mc.player.getInventory();
        if (hotbarSlot < 0 || !isShulker(inv.getStack(hotbarSlot))) {
            go(State.FIND);
            return;
        }
        if (inv.selectedSlot != hotbarSlot) {
            inv.selectedSlot = hotbarSlot;
            wait = 1;
            return;
        }
        BlockPos p = findPlacement();
        if (p == null) {
            fail("no space to place");
            return;
        }
        Vec3d click = new Vec3d(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
        if (rotate.value) face(click);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(click, Direction.UP, p.down(), false));
        mc.player.swingHand(Hand.MAIN_HAND);
        shulkerPos = p;
        go(State.WAIT_PLACED);
    }

    private void waitPlaced() {
        if (mc.world.getBlockState(shulkerPos).getBlock() instanceof ShulkerBoxBlock) {
            wait = 1;
            go(State.OPEN);
            return;
        }
        if (timeout > 20) {
            if (++placeTries >= 3) {
                fail("could not place");
                return;
            }
            go(State.PLACE);
        }
    }

    // ---- mo shulker ----
    private void open() {
        Vec3d top = new Vec3d(shulkerPos.getX() + 0.5, shulkerPos.getY() + 1.0, shulkerPos.getZ() + 0.5);
        if (rotate.value) face(Vec3d.ofCenter(shulkerPos));
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(top, Direction.UP, shulkerPos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        go(State.WAIT_OPEN);
    }

    private void waitOpen() {
        if (mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler) {
            needObs = obsidian.value ? (int) obsidianStacks.value : 0;
            needCry = crystals.value ? (int) crystalStacks.value : 0;
            needTot = totems.value ? (int) totemCount.value : 0;
            cooldown = 0;
            takeOrder = 0;
            wait = 1;
            go(State.TAKE);
            return;
        }
        if (timeout > 20) {
            if (++openTries >= 3) {
                fail("could not open");
                return;
            }
            go(State.OPEN);
        }
    }

    // ---- lay do ----
    private void take() {
        if (!(mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler h)) {
            fail("shulker closed");
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (takeNext(h)) {
            cooldown = (int) delay.value;
            timeout = 0;
            return;
        }
        wait = 2;
        go(State.CLOSE);
    }

    private boolean takeNext(ShulkerBoxScreenHandler h) {
        if (needTot > 0 && click(h, Items.TOTEM_OF_UNDYING)) {
            needTot--;
            return true;
        }
        if (needCry > 0 && click(h, Items.END_CRYSTAL)) {
            needCry--;
            return true;
        }
        if (needObs > 0 && click(h, Items.OBSIDIAN)) {
            needObs--;
            return true;
        }
        return false;
    }

    private boolean click(ShulkerBoxScreenHandler h, Item item) {
        for (int i = 0; i < 27; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isOf(item)) {
                int dest = predictDest(h, st);
                ItemStack shown = st.copy();
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                if (animation.value) {
                    float sx = Float.isNaN(scrX) ? mc.getWindow().getScaledWidth() / 2f : scrX;
                    float sy = Float.isNaN(scrY) ? mc.getWindow().getScaledHeight() / 2f : scrY;
                    int hb = dest >= 54 ? dest - 54 : -1;
                    RegearAnim.spawn(shown, sx, sy, hb, takeOrder++);
                }
                return true;
            }
        }
        return false;
    }

    /** Doan o dich cua shift-click: gop vao stack co san truoc, roi o trong, duyet tu cuoi (hotbar 9 -> 1). */
    private int predictDest(ShulkerBoxScreenHandler h, ItemStack moving) {
        int total = h.slots.size();
        for (int i = total - 1; i >= 27; i--) {
            ItemStack cur = h.getSlot(i).getStack();
            if (!cur.isEmpty() && ItemStack.areItemsAndComponentsEqual(cur, moving) && cur.getCount() < cur.getMaxCount()) return i;
        }
        for (int i = total - 1; i >= 27; i--) {
            if (h.getSlot(i).getStack().isEmpty()) return i;
        }
        return -1;
    }

    // ---- dong, xong ----
    private void close() {
        mc.player.closeHandledScreen();
        if (prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        if (autoDisable.value) {
            setEnabled(false);
        } else {
            placeTries = 0;
            openTries = 0;
            hotbarSlot = -1;
            shulkerPos = null;
            wait = 5;
            go(State.FIND);
        }
    }

    private void face(Vec3d target) {
        Vec3d d = target.subtract(mc.player.getEyePos());
        double flat = Math.sqrt(d.x * d.x + d.z * d.z);
        mc.player.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        mc.player.setPitch((float) -Math.toDegrees(Math.atan2(d.y, flat)));
    }
}
