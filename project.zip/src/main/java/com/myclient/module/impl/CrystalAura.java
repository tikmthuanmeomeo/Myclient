package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Friends;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CrystalAura (AutoCrystal) - code tu viet.
 *
 * Place: quet muc tieu (PlayerEntity) trong "Target range", tim block Obsidian/Bedrock quanh chan muc tieu,
 *        chon cho dat cho sat thuong len muc tieu cao nhat ma sat thuong len minh khong vuot "Max self damage".
 *        Dat bang PlayerInteractBlockC2SPacket (co silent switch qua UpdateSelectedSlotC2SPacket).
 * Break: gui PlayerInteractEntityC2SPacket.attack len EndCrystalEntity trong tam voi neu no du sat thuong.
 *
 * Luu y: cong thuc sat thuong la UOC LUONG (khong tinh enchant Blast Protection) nen co the lech chut it.
 */
public class CrystalAura extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 5.0, 1.0, 6.0, 0.5));
    public final Setting.Num targetRange = add(new Setting.Num("Target range", 10.0, 3.0, 20.0, 1.0));
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Bool breakCrystals = add(new Setting.Bool("Break", true));
    public final Setting.Bool autoSwitch = add(new Setting.Bool("AutoSwitch", true));
    public final Setting.Bool silent = add(new Setting.Bool("Silent switch", true));
    public final Setting.Num minDamage = add(new Setting.Num("Min damage", 4.0, 0.0, 20.0, 0.5));
    public final Setting.Num maxSelfDamage = add(new Setting.Num("Max self damage", 6.0, 0.0, 20.0, 0.5));
    public final Setting.Bool antiSuicide = add(new Setting.Bool("Anti suicide", true));
    public final Setting.Num placeDelay = add(new Setting.Num("Place delay (ticks)", 0, 0, 10, 1));
    public final Setting.Num breakDelay = add(new Setting.Num("Break delay (ticks)", 0, 0, 10, 1));
    public final Setting.Num maxBreaks = add(new Setting.Num("Breaks per tick", 1, 1, 4, 1));
    public final Setting.Bool swing = add(new Setting.Bool("Swing", true));

    private int placeCd, breakCd;
    private long tick;
    private final Map<Integer, Long> brokenAt = new HashMap<>();
    private final Map<BlockPos, Long> placedAt = new HashMap<>();

    public CrystalAura() {
        super("CrystalAura", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        brokenAt.clear();
        placedAt.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) return;
        if (mc.currentScreen != null) return;
        tick++;
        if (tick % 40 == 0) {
            brokenAt.values().removeIf(t -> tick - t > 40);
            placedAt.values().removeIf(t -> tick - t > 40);
        }
        if (placeCd > 0) placeCd--;
        if (breakCd > 0) breakCd--;

        List<PlayerEntity> targets = findTargets();
        if (targets.isEmpty()) return;

        if (breakCrystals.value && breakCd == 0) doBreak(targets);
        if (place.value && placeCd == 0) doPlace(targets);
    }

    // =====================================================================
    //  MUC TIEU
    // =====================================================================
    private List<PlayerEntity> findTargets() {
        double tr = targetRange.value;
        List<PlayerEntity> out = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isDead() || p.isSpectator() || p.getHealth() <= 0f) continue;
            if (Friends.isFriend(p.getName().getString())) continue;
            if (mc.player.squaredDistanceTo(p) > tr * tr) continue;
            out.add(p);
        }
        out.sort(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(p)));
        return out.size() > 3 ? new ArrayList<>(out.subList(0, 3)) : out;
    }

    private float health(LivingEntity e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    // =====================================================================
    //  BREAK
    // =====================================================================
    private void doBreak(List<PlayerEntity> targets) {
        double r2 = range.value * range.value;
        Vec3d eye = mc.player.getEyePos();
        List<EndCrystalEntity> crystals = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || c.isRemoved()) continue;
            if (eye.squaredDistanceTo(c.getPos()) > r2) continue;
            Long last = brokenAt.get(c.getId());
            if (last != null && tick - last < 3) continue; // vua danh roi, cho server xoa
            crystals.add(c);
        }
        if (crystals.isEmpty()) return;

        // chon crystal tot nhat: sat thuong muc tieu cao nhat
        record Pick(EndCrystalEntity c, float dmg) { }
        List<Pick> picks = new ArrayList<>();
        for (EndCrystalEntity c : crystals) {
            Vec3d src = c.getPos();
            float self = explosionDamage(mc.player, src);
            if (!selfSafe(self)) continue;
            float best = 0f;
            boolean kill = false;
            for (PlayerEntity t : targets) {
                float d = explosionDamage(t, src);
                best = Math.max(best, d);
                if (d >= health(t)) kill = true;
            }
            if (best >= minDamage.value || kill) picks.add(new Pick(c, best));
        }
        if (picks.isEmpty()) return;
        picks.sort((a, b) -> Float.compare(b.dmg(), a.dmg()));

        int n = Math.min((int) maxBreaks.value, picks.size());
        for (int i = 0; i < n; i++) {
            EndCrystalEntity c = picks.get(i).c();
            mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(c, mc.player.isSneaking()));
            if (swing.value) mc.player.swingHand(Hand.MAIN_HAND);
            brokenAt.put(c.getId(), tick);
        }
        breakCd = (int) breakDelay.value;
    }

    // =====================================================================
    //  PLACE
    // =====================================================================
    private void doPlace(List<PlayerEntity> targets) {
        // Co crystal de dat khong?
        Hand hand = null;
        int slot = -1;
        PlayerInventory inv = mc.player.getInventory();
        if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.MAIN_HAND;
        } else if (autoSwitch.value) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(Items.END_CRYSTAL)) {
                    slot = i;
                    break;
                }
            }
            if (slot < 0) return;
            hand = Hand.MAIN_HAND;
        } else {
            return;
        }

        BlockPos best = findBestPlacement(targets);
        if (best == null) return;

        // doi slot neu can
        int original = inv.selectedSlot;
        boolean switched = false;
        if (slot >= 0 && slot != original) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            if (!silent.value) inv.selectedSlot = slot;
            switched = true;
        }

        BlockHitResult hit = new BlockHitResult(
                new Vec3d(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5), Direction.UP, best, false);
        try (PendingUpdateManager pum = mc.world.getPendingUpdateManager().incrementSequence()) {
            int seq = pum.getSequence();
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(hand, hit, seq));
        }
        if (swing.value) mc.player.swingHand(hand);

        // silent: tra slot ve nhu cu (server thay doi slot trong 1 tick)
        if (switched && silent.value) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(original));
        }

        placedAt.put(best.toImmutable(), tick);
        placeCd = (int) placeDelay.value;

        // bao cho TotemPops biet vu no sap toi la do minh (ke ca khi silent switch)
        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.noteBlast(new Vec3d(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5));
    }

    private BlockPos findBestPlacement(List<PlayerEntity> targets) {
        double r = range.value;
        double r2 = r * r;
        Vec3d eye = mc.player.getEyePos();

        record Cand(BlockPos pos, float estimate) { }
        List<Cand> cands = new ArrayList<>();

        for (PlayerEntity t : targets) {
            BlockPos feet = t.getBlockPos();
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    // block nen: ngay duoi chan muc tieu (dy = -1) hoac thap hon 1 block (dy = -2)
                    for (int dy = -2; dy <= -1; dy++) {
                        BlockPos base = new BlockPos(feet.getX() + dx, feet.getY() + dy, feet.getZ() + dz);
                        if (!isBase(base)) continue;
                        Vec3d src = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
                        if (eye.squaredDistanceTo(src) > r2) continue;
                        Long recent = placedAt.get(base);
                        if (recent != null && tick - recent < 3) continue;
                        // can tren dau phai trong
                        if (!mc.world.getBlockState(base.up()).isAir()) continue;
                        // uoc luong toi da (exposure = 1) de loai nhanh
                        float est = estimateUpper(t, src);
                        if (est < minDamage.value && est < health(t)) continue;
                        cands.add(new Cand(base.toImmutable(), est));
                    }
                }
            }
        }
        if (cands.isEmpty()) return null;
        cands.sort((a, b) -> Float.compare(b.estimate(), a.estimate()));

        BlockPos bestPos = null;
        float bestScore = -1000f;
        int checked = 0;
        for (Cand c : cands) {
            if (checked++ >= 12) break;
            BlockPos base = c.pos();
            if (!spaceFree(base)) continue;
            Vec3d src = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            float self = explosionDamage(mc.player, src);
            if (!selfSafe(self)) continue;

            float bestTarget = 0f;
            boolean kill = false;
            for (PlayerEntity t : targets) {
                float d = explosionDamage(t, src);
                bestTarget = Math.max(bestTarget, d);
                if (d >= health(t)) kill = true;
            }
            if (bestTarget < minDamage.value && !kill) continue;

            float score = bestTarget - self * 0.5f + (kill ? 100f : 0f);
            if (score > bestScore) {
                bestScore = score;
                bestPos = base;
            }
        }
        return bestPos;
    }

    private boolean isBase(BlockPos p) {
        var s = mc.world.getBlockState(p);
        return s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.BEDROCK);
    }

    /** Khong co entity nao chiem cho dat crystal (hop 1x2 phia tren block). */
    private boolean spaceFree(BlockPos base) {
        Box box = new Box(base.getX(), base.getY() + 1.0, base.getZ(), base.getX() + 1.0, base.getY() + 3.0, base.getZ() + 1.0);
        return mc.world.getOtherEntities(null, box, e -> !e.isSpectator()).isEmpty();
    }

    // =====================================================================
    //  SAT THUONG (uoc luong)
    // =====================================================================
    private boolean selfSafe(float self) {
        if (self > maxSelfDamage.value) return false;
        if (antiSuicide.value && self >= health(mc.player) - 0.5f) return false;
        return true;
    }

    /** Can tren khi khong tinh che chan (exposure = 1) va khong tinh giap. */
    private float estimateUpper(LivingEntity e, Vec3d src) {
        double dist = Math.sqrt(e.squaredDistanceTo(src)) / 12.0;
        if (dist > 1.0) return 0f;
        double impact = (1.0 - dist);
        float raw = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0));
        return scaleDifficulty(raw);
    }

    private float explosionDamage(LivingEntity e, Vec3d src) {
        double dist = Math.sqrt(e.squaredDistanceTo(src)) / 12.0;
        if (dist > 1.0) return 0f;
        double exposure = Explosion.getExposure(src, e);
        double impact = (1.0 - dist) * exposure;
        float dmg = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0));
        dmg = scaleDifficulty(dmg);

        // giap
        float armor = (float) e.getArmor();
        float tough = (float) e.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        float f = 2.0f + tough / 4.0f;
        float g = MathHelper.clamp(armor - dmg / f, armor * 0.2f, 20.0f);
        dmg *= 1.0f - g / 25.0f;

        // Resistance
        if (e.hasStatusEffect(StatusEffects.RESISTANCE)) {
            StatusEffectInstance inst = e.getStatusEffect(StatusEffects.RESISTANCE);
            if (inst != null) {
                int amp = inst.getAmplifier();
                dmg = Math.max(dmg * (25 - 5 * (amp + 1)) / 25f, 0f);
            }
        }
        return Math.max(dmg, 0f);
    }

    private float scaleDifficulty(float d) {
        Difficulty diff = mc.world.getDifficulty();
        return switch (diff) {
            case PEACEFUL -> 0f;
            case EASY -> Math.min(d / 2f + 1f, d);
            case NORMAL -> d;
            case HARD -> d * 3f / 2f;
        };
    }
}
