package com.myclient.module.impl;

import com.myclient.mixin.ClientWorldAccessor;
import com.myclient.module.Category;
import com.myclient.module.Friends;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CrystalAura (AutoCrystal) - code tu viet, chay moi khung hinh (onFrame) de nhanh.
 *
 * Break : dap EndCrystalEntity trong tam voi neu gay du sat thuong len dich.
 * Place : dat crystal len Obsidian/Bedrock quanh chan dich, chon cho sat thuong cao nhat.
 * BasePlace : neu dat them 1 khoi Obsidian se cho sat thuong cao hon hang co san thi dat obsidian truoc.
 * FacePlace : khi dich yeu giap hoac it mau thi ha min damage va them cac vi tri ngang than (dat mat).
 * Ban be (#friend add) khong bao gio bi no crystal.
 *
 * Luu y: cong thuc sat thuong la UOC LUONG (khong tinh Blast Protection).
 */
public class CrystalAura extends Module {
    public final Setting.Num range = add(new Setting.Num("Range", 5.0, 1.0, 6.0, 0.5));
    public final Setting.Num targetRange = add(new Setting.Num("Target range", 10.0, 3.0, 20.0, 1.0));
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Bool breakCrystals = add(new Setting.Bool("Break", true));
    public final Setting.Num placeDelay = add(new Setting.Num("Place delay (ms)", 50, 0, 1000, 5));
    public final Setting.Num breakDelay = add(new Setting.Num("Break delay (ms)", 50, 0, 1000, 5));
    public final Setting.Num maxBreaks = add(new Setting.Num("Breaks per cycle", 2, 1, 4, 1));
    public final Setting.Bool autoSwitch = add(new Setting.Bool("AutoSwitch", true));
    public final Setting.Bool silent = add(new Setting.Bool("Silent switch", true));
    public final Setting.Num minDamage = add(new Setting.Num("Min damage", 4.0, 0.0, 20.0, 0.5));
    public final Setting.Num maxSelfDamage = add(new Setting.Num("Max self damage", 36.0, 0.0, 36.0, 0.5));
    public final Setting.Bool antiSuicide = add(new Setting.Bool("Anti suicide", false));
    public final Setting.Bool basePlace = add(new Setting.Bool("Base place", true));
    public final Setting.Num baseDelay = add(new Setting.Num("Base place delay (ms)", 150, 0, 1000, 10));
    public final Setting.Bool facePlace = add(new Setting.Bool("Face place", true));
    public final Setting.Num facePlaceArmor = add(new Setting.Num("Face place armor %", 30, 0, 100, 5));
    public final Setting.Num facePlaceHealth = add(new Setting.Num("Face place health", 10, 1, 36, 1));
    public final Setting.Bool swing = add(new Setting.Bool("Swing", true));

    private record Use(Hand hand, int slot) { }
    private record Placement(BlockPos pos, float dmg, boolean kill, float score) { }
    private record BasePick(BlockPos pos, float dmg) { }
    private record Cand(BlockPos pos, float estimate) { }

    private long nextPlace, nextBreak, nextBase, lastBreakMs, lastClean;
    private final Map<Integer, Long> brokenAt = new HashMap<>();
    private final Map<BlockPos, Long> placedAt = new HashMap<>();

    public CrystalAura() {
        super("CrystalAura", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        brokenAt.clear();
        placedAt.clear();
    }

    @Override
    public void onFrame() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) return;
        if (mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        if (now - lastClean > 2000) {
            lastClean = now;
            brokenAt.values().removeIf(t -> now - t > 2000);
            placedAt.values().removeIf(t -> now - t > 2000);
        }

        List<PlayerEntity> targets = findTargets();
        if (targets.isEmpty()) return;

        if (breakCrystals.value && now >= nextBreak) doBreak(targets, now);
        if (place.value && now >= nextPlace) doPlace(targets, now);
    }

    // =====================================================================
    //  MUC TIEU
    // =====================================================================
    private List<PlayerEntity> findTargets() {
        double tr = targetRange.value;
        List<PlayerEntity> out = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isDead() || p.isSpectator() || p.getHealth() <= 0f) continue;
            if (Friends.isFriend(p.getName().getString())) continue;
            if (mc.player.squaredDistanceTo(p) > tr * tr) continue;
            out.add(p);
        }
        out.sort(Comparator.comparingDouble(p -> mc.player.squaredDistanceTo(p)));
        return out.size() > 3 ? new ArrayList<>(out.subList(0, 3)) : out;
    }

    private float health(LivingEntity e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    private long latencyMs() {
        long ms = 40;
        if (mc.getNetworkHandler() != null) {
            var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ms = e.getLatency();
        }
        return Math.max(1, Math.min(300, ms));
    }

    // ---- face place ----
    /** Phan tram do ben giap thap nhat (thieu mon giap = 0%). */
    private float armorPercent(PlayerEntity p) {
        float min = 100f;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = p.getEquippedStack(slot);
            if (st.isEmpty()) return 0f;
            if (!st.isDamageable()) continue;
            float pct = 100f * (st.getMaxDamage() - st.getDamage()) / (float) st.getMaxDamage();
            min = Math.min(min, pct);
        }
        return min;
    }

    private boolean faceActive(PlayerEntity t) {
        if (!facePlace.value) return false;
        return health(t) <= facePlaceHealth.value || armorPercent(t) <= facePlaceArmor.value;
    }

    private boolean anyFace(List<PlayerEntity> targets) {
        for (PlayerEntity t : targets) if (faceActive(t)) return true;
        return false;
    }

    /** Sat thuong toi thieu can co: face place thi chi can >= 1. */
    private float minFor(PlayerEntity t) {
        return faceActive(t) ? Math.min(1.0f, (float) minDamage.value) : (float) minDamage.value;
    }

    // =====================================================================
    //  BREAK
    // =====================================================================
    private void doBreak(List<PlayerEntity> targets, long now) {
        double r2 = range.value * range.value;
        Vec3d eye = mc.player.getEyePos();
        long gap = Math.max(80L, latencyMs() * 2 + 40);

        record Pick(EndCrystalEntity c, float dmg) { }
        List<Pick> picks = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || c.isRemoved()) continue;
            if (eye.squaredDistanceTo(c.getPos()) > r2) continue;
            Long last = brokenAt.get(c.getId());
            if (last != null && now - last < gap) continue;

            Vec3d src = c.getPos();
            if (!selfSafe(selfDamage(src)) || !friendsSafe(src)) continue;
            float best = 0f;
            boolean ok = false;
            for (PlayerEntity t : targets) {
                float d = explosionDamage(t, src);
                if (d >= minFor(t) || d >= health(t)) {
                    ok = true;
                    best = Math.max(best, d);
                }
            }
            if (ok) picks.add(new Pick(c, best));
        }
        if (picks.isEmpty()) return;
        picks.sort((a, b) -> Float.compare(b.dmg(), a.dmg()));

        int n = Math.min((int) maxBreaks.value, picks.size());
        for (int i = 0; i < n; i++) {
            EndCrystalEntity c = picks.get(i).c();
            mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(c, mc.player.isSneaking()));
            if (swing.value) mc.player.swingHand(Hand.MAIN_HAND);
            brokenAt.put(c.getId(), now);
            lastBreakMs = now;
        }
        nextBreak = now + (long) breakDelay.value;
    }

    // =====================================================================
    //  PLACE (crystal + base obsidian)
    // =====================================================================
    private Use resolve(Item item) {
        if (mc.player.getOffHandStack().isOf(item)) return new Use(Hand.OFF_HAND, -1);
        if (mc.player.getMainHandStack().isOf(item)) return new Use(Hand.MAIN_HAND, -1);
        if (!autoSwitch.value) return null;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) return new Use(Hand.MAIN_HAND, i);
        }
        return null;
    }

    /** Gui goi tin dat block (co silent switch neu can). */
    private void useBlock(Use use, BlockHitResult hit) {
        PlayerInventory inv = mc.player.getInventory();
        int original = inv.selectedSlot;
        boolean switched = use.slot() >= 0 && use.slot() != original;
        if (switched) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(use.slot()));
            if (!silent.value) inv.selectedSlot = use.slot();
        }
        try (PendingUpdateManager pum = ((ClientWorldAccessor) mc.world).myclient$getPendingUpdateManager().incrementSequence()) {
            int seq = pum.getSequence();
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(use.hand(), hit, seq));
        }
        if (swing.value) mc.player.swingHand(use.hand());
        if (switched && silent.value) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(original));
        }
    }

    private void doPlace(List<PlayerEntity> targets, long now) {
        Use crystalUse = resolve(Items.END_CRYSTAL);
        Placement best = crystalUse != null ? findBestPlacement(targets, now) : null;

        // ---- base place: dat obsidian neu no cho sat thuong cao hon han ----
        if (basePlace.value && now >= nextBase) {
            Use obs = resolve(Items.OBSIDIAN);
            if (obs != null) {
                float cur = best == null ? 0f : best.dmg();
                BasePick bp = findBestBase(targets, cur, best == null);
                if (bp != null) {
                    useBlock(obs, supportHit(bp.pos()));
                    nextBase = now + (long) baseDelay.value;
                }
            }
        }

        if (best == null || crystalUse == null) return;
        BlockPos pos = best.pos();
        BlockHitResult hit = new BlockHitResult(
                new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5), Direction.UP, pos, false);
        useBlock(crystalUse, hit);
        placedAt.put(pos.toImmutable(), now);
        nextPlace = now + (long) placeDelay.value;

        // bao cho TotemPops biet vu no sap toi la do minh (ke ca khi silent switch)
        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.noteBlast(new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5));
    }

    private Placement findBestPlacement(List<PlayerEntity> targets, long now) {
        double r2 = range.value * range.value;
        Vec3d eye = mc.player.getEyePos();
        int dyMax = anyFace(targets) ? 0 : -1; // face place: them block nen ngang chan (crystal ngang than)
        long repeatGap = Math.max(60L, latencyMs() * 2 + 30);

        List<Cand> cands = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        for (PlayerEntity t : targets) {
            BlockPos feet = t.getBlockPos();
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    for (int dy = -2; dy <= dyMax; dy++) {
                        BlockPos base = new BlockPos(feet.getX() + dx, feet.getY() + dy, feet.getZ() + dz);
                        if (seen.contains(base) || !isBase(base)) continue;
                        Vec3d src = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
                        if (eye.squaredDistanceTo(src) > r2) continue;
                        Long recent = placedAt.get(base);
                        if (recent != null && now - recent < repeatGap && lastBreakMs < recent) continue;
                        if (!mc.world.getBlockState(base.up()).isAir()) continue;
                        float est = estimateUpper(t, src);
                        if (est < minFor(t) && est < health(t)) continue;
                        BlockPos im = base.toImmutable();
                        seen.add(im);
                        cands.add(new Cand(im, est));
                    }
                }
            }
        }
        if (cands.isEmpty()) return null;
        cands.sort((a, b) -> Float.compare(b.estimate(), a.estimate()));

        Placement bestP = null;
        int checked = 0;
        for (Cand c : cands) {
            if (checked++ >= 30) break;
            BlockPos base = c.pos();
            if (!spaceFree(base, now)) continue;
            Vec3d src = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            float self = selfDamage(src);
            if (!selfSafe(self) || !friendsSafe(src)) continue;

            float bestTarget = 0f;
            boolean kill = false;
            boolean ok = false;
            for (PlayerEntity t : targets) {
                float d = explosionDamage(t, src);
                boolean k = d >= health(t);
                if (d >= minFor(t) || k) {
                    ok = true;
                    bestTarget = Math.max(bestTarget, d);
                    if (k) kill = true;
                }
            }
            if (!ok) continue;
            float score = bestTarget + (kill ? 1000f : 0f) - self * 0.01f;
            if (bestP == null || score > bestP.score()) bestP = new Placement(base, bestTarget, kill, score);
        }
        return bestP;
    }

    /** Tim cho dat obsidian (roi crystal len tren) cho sat thuong cao hon dang co (cur). */
    private BasePick findBestBase(List<PlayerEntity> targets, float cur, boolean noCurrent) {
        double r2 = range.value * range.value;
        Vec3d eye = mc.player.getEyePos();
        int dyMax = anyFace(targets) ? 0 : -1;

        List<Cand> cands = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        for (PlayerEntity t : targets) {
            BlockPos feet = t.getBlockPos();
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    for (int dy = -2; dy <= dyMax; dy++) {
                        BlockPos q = new BlockPos(feet.getX() + dx, feet.getY() + dy, feet.getZ() + dz);
                        if (seen.contains(q)) continue;
                        BlockState s = mc.world.getBlockState(q);
                        if (!s.isReplaceable() || !s.getFluidState().isEmpty()) continue;
                        if (!mc.world.getBlockState(q.up()).isAir()) continue;
                        Vec3d src = new Vec3d(q.getX() + 0.5, q.getY() + 1.0, q.getZ() + 0.5);
                        if (eye.squaredDistanceTo(Vec3d.ofCenter(q)) > r2) continue;
                        float est = estimateUpper(t, src);
                        if (est < minFor(t) && est < health(t)) continue;
                        BlockPos im = q.toImmutable();
                        seen.add(im);
                        cands.add(new Cand(im, est));
                    }
                }
            }
        }
        if (cands.isEmpty()) return null;
        cands.sort((a, b) -> Float.compare(b.estimate(), a.estimate()));

        BasePick bestB = null;
        int checked = 0;
        for (Cand c : cands) {
            if (checked++ >= 20) break;
            BlockPos q = c.pos();
            // khong dat obsidian len cho dang co entity, va phai con cho de crystal ben tren
            if (!mc.world.getOtherEntities(null, new Box(q), e -> !e.isSpectator()).isEmpty()) continue;
            if (!spaceFree(q, System.currentTimeMillis())) continue;
            Vec3d src = new Vec3d(q.getX() + 0.5, q.getY() + 1.0, q.getZ() + 0.5);
            if (!selfSafe(selfDamage(src)) || !friendsSafe(src)) continue;

            float bestTarget = 0f;
            boolean ok = false;
            for (PlayerEntity t : targets) {
                float d = explosionDamage(t, src);
                if (d >= minFor(t) || d >= health(t)) {
                    ok = true;
                    bestTarget = Math.max(bestTarget, d);
                }
            }
            if (!ok) continue;
            // chi dat obsidian khi tot hon han cho hien co (hoac chua co cho nao)
            if (!noCurrent && bestTarget < cur + 2.0f) continue;
            if (bestB == null || bestTarget > bestB.dmg()) bestB = new BasePick(q, bestTarget);
        }
        return bestB;
    }

    /** Chon mat de click khi dat obsidian: dua vao block ke ben, khong co thi dat tren khong (air place). */
    private BlockHitResult supportHit(BlockPos q) {
        Direction[] dirs = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : dirs) {
            BlockPos n = q.offset(d);
            BlockState ns = mc.world.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty()) continue;
            Direction face = d.getOpposite();
            Vec3d hv = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            return new BlockHitResult(hv, face, n, false);
        }
        return new BlockHitResult(Vec3d.ofCenter(q), Direction.UP, q, false);
    }

    private boolean isBase(BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.BEDROCK);
    }

    /** Khong co entity nao chiem cho dat crystal (hop 1x2 phia tren block). */
    private boolean spaceFree(BlockPos base, long now) {
        Box box = new Box(base.getX(), base.getY() + 1.0, base.getZ(), base.getX() + 1.0, base.getY() + 3.0, base.getZ() + 1.0);
        // crystal vua bi minh danh se bien mat ngay -> coi nhu trong, de dat lai lien
        return mc.world.getOtherEntities(null, box, e -> {
            if (e.isSpectator()) return false;
            if (e instanceof EndCrystalEntity c) {
                Long t = brokenAt.get(c.getId());
                if (t != null && now - t < 200) return false;
            }
            return true;
        }).isEmpty();
    }

    // =====================================================================
    //  SAT THUONG (uoc luong)
    // =====================================================================
    /** Bo qua tinh sat thuong len minh khi khong quan tam (tiet kiem CPU). */
    private float selfDamage(Vec3d src) {
        if (maxSelfDamage.value >= 36.0 && !antiSuicide.value) return 0f;
        return explosionDamage(mc.player, src);
    }

    private boolean selfSafe(float self) {
        if (self > maxSelfDamage.value) return false;
        if (antiSuicide.value && self >= health(mc.player) - 0.5f) return false;
        return true;
    }

    /** Ban be khong bao gio bi no crystal. */
    private boolean friendsSafe(Vec3d src) {
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !Friends.isFriend(p.getName().getString())) continue;
            if (p.squaredDistanceTo(src) > 13 * 13) continue;
            if (explosionDamage(p, src) > 0.5f) return false;
        }
        return true;
    }

    /** Can tren khi khong tinh che chan (exposure = 1) va khong tinh giap. */
    private float estimateUpper(LivingEntity e, Vec3d src) {
        double dist = Math.sqrt(e.squaredDistanceTo(src)) / 12.0;
        if (dist > 1.0) return 0f;
        double impact = (1.0 - dist);
        float raw = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0));
        return scaleDifficulty(raw);
    }

    private float explosionDamage(LivingEntity e, Vec3d src) {
        double dist = Math.sqrt(e.squaredDistanceTo(src)) / 12.0;
        if (dist > 1.0) return 0f;
        double exposure = Explosion.getExposure(src, e);
        double impact = (1.0 - dist) * exposure;
        float dmg = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0));
        dmg = scaleDifficulty(dmg);

        // giap
        float armor = (float) e.getArmor();
        float tough = (float) e.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        float f = 2.0f + tough / 4.0f;
        float g = MathHelper.clamp(armor - dmg / f, armor * 0.2f, 20.0f);
        dmg *= 1.0f - g / 25.0f;

        // Resistance
        if (e.hasStatusEffect(StatusEffects.RESISTANCE)) {
            StatusEffectInstance inst = e.getStatusEffect(StatusEffects.RESISTANCE);
            if (inst != null) {
                int amp = inst.getAmplifier();
                dmg = Math.max(dmg * (25 - 5 * (amp + 1)) / 25f, 0f);
            }
        }
        return Math.max(dmg, 0f);
    }

    private float scaleDifficulty(float d) {
        Difficulty diff = mc.world.getDifficulty();
        return switch (diff) {
            case PEACEFUL -> 0f;
            case EASY -> Math.min(d / 2f + 1f, d);
            case NORMAL -> d;
            case HARD -> d * 3f / 2f;
        };
    }
}
