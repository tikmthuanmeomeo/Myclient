package com.myclient.module.impl;

import com.myclient.mixin.PlayerInteractEntityC2SPacketAccessor;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import io.netty.buffer.Unpooled;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * Criticals bang packet: truoc moi packet danh entity, gui them vai packet vi tri "nhay nhe" (onGround = false)
 * de server tinh la don danh khi dang roi => sat thuong crit.
 * Logic offset tham khao tu Criticals cua AlienClient (open source).
 */
public class Criticals extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "OldNCP",
            "OldNCP", "NCP", "UpdatedNCP", "Strict", "Packet", "Hypixel2K22", "BBTT"));
    public final Setting.Bool onlyGround = add(new Setting.Bool("Only ground", true));
    public final Setting.Bool crystals = add(new Setting.Bool("Crystals", false));

    private boolean sending;

    public Criticals() {
        super("Criticals", Category.COMBAT);
    }

    /** Goi tu ClientPlayNetworkHandlerMixin truoc khi gui moi packet. */
    public void onPacketSent(Packet<?> packet) {
        if (!isEnabled() || sending) return;
        if (!(packet instanceof PlayerInteractEntityC2SPacket pk)) return;
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;

        // Doc packet: entityId, loai tuong tac (1 = ATTACK)
        int id;
        int type;
        try {
            PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
            ((PlayerInteractEntityC2SPacketAccessor) (Object) pk).myclient$write(buf);
            id = buf.readVarInt();
            type = buf.readVarInt();
            buf.release();
        } catch (Throwable t) {
            return;
        }
        if (type != 1) return;

        Entity e = mc.world.getEntityById(id);
        if (e == null) return;
        if (e instanceof EndCrystalEntity && !crystals.value) return;
        if (onlyGround.value && !mc.player.isOnGround() && !mc.player.getAbilities().flying) return;
        if (mc.player.isInLava() || mc.player.isTouchingWater()) return;

        sending = true;
        try {
            doCrit(e);
        } finally {
            sending = false;
        }
    }

    private void pos(double dy, boolean ground) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                mc.player.getX(), mc.player.getY() + dy, mc.player.getZ(), ground));
    }

    private void doCrit(Entity target) {
        switch (mode.get()) {
            case "BBTT" -> {
                // chi hoat dong khi dung yen
                if (mc.player.getVelocity().lengthSquared() > 1.0E-4 && !mc.player.isOnGround()) return;
                if (mc.player.input != null && mc.player.input.movementForward != 0f) return;
                pos(0.0, true);
                pos(0.0625, false);
                pos(0.045, false);
            }
            case "Strict" -> {
                mc.player.addCritParticles(target);
                pos(0.062600301692775, false);
                pos(0.07260029960661, false);
                pos(0.0, false);
                pos(0.0, false);
            }
            case "NCP" -> {
                mc.player.addCritParticles(target);
                pos(0.0625, false);
                pos(0.0, false);
            }
            case "UpdatedNCP" -> {
                mc.player.addCritParticles(target);
                pos(0.000000271875, false);
                pos(0.0, false);
            }
            case "Hypixel2K22" -> {
                mc.player.addCritParticles(target);
                pos(0.0045, true);
                pos(0.000152121, false);
                pos(0.3, false);
                pos(0.025, false);
            }
            case "Packet" -> {
                mc.player.addCritParticles(target);
                pos(0.0005, false);
                pos(0.0001, false);
            }
            default -> { // OldNCP
                mc.player.addCritParticles(target);
                pos(0.00001058293536, false);
                pos(0.00000916580235, false);
                pos(0.00000010371854, false);
            }
        }
    }
}
