package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;

/** Doi gio trong game (chi phia client): 18000 = nua dem co sao, 6000 = giua trua. */
public class TimeChanger extends Module {
    public final Setting.Num time = add(new Setting.Num("Time", 18000, 0, 24000, 500));

    public TimeChanger() {
        super("TimeChanger", Category.MISC);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        mc.world.setTimeOfDay((long) time.value);
    }
}
