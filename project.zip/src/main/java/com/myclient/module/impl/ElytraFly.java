package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import com.myclient.util.Util;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** ElytraFly port tu AlienClient (Control / Boost / Bounce / None). */
public class ElytraFly extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Control", "Control", "Boost", "Bounce", "Freeze", "Rotation", "Pitch", "None"));
    public final Setting.Bool infiniteDura = add(new Setting.Bool("InfiniteDura", false));
    public final Setting.Bool setFlag = add(new Setting.Bool("SetFlag", false));
    public final Setting.Bool firework = add(new Setting.Bool("Firework", false));
    public final Setting.KeyBind fireworkBind = add(new Setting.KeyBind("FireworkBind", -1));
    public final Setting.Bool packetInteract = add(new Setting.Bool("PacketInteract", true));
    public final Setting.Bool inventory = add(new Setting.Bool("InventorySwap", true));
    public final Setting.Bool onlyOne = add(new Setting.Bool("OnlyOne", true));
    public final Setting.Bool usingPause = add(new Setting.Bool("UsingPause", true));
    public final Setting.Bool autoJump = add(new Setting.Bool("AutoJump", true));
    public final Setting.Num upPitch = add(new Setting.Num("UpPitch", 0, 0, 90, 1));
    public final Setting.Num upFactor = add(new Setting.Num("UpFactor", 1, 0, 10, 0.1));
    public final Setting.Num fallSpeed = add(new Setting.Num("FallSpeed", 1, 0, 10, 0.1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 1, 0.1, 10, 0.1));
    public final Setting.Bool speedLimit = add(new Setting.Bool("SpeedLimit", true));
    public final Setting.Num maxSpeed = add(new Setting.Num("MaxSpeed", 2.5, 0.1, 10, 0.1));
    public final Setting.Bool noDrag = add(new Setting.Bool("NoDrag", false));
    public final Setting.Bool autoStop = add(new Setting.Bool("AutoStop", true));
    public final Setting.Bool sprint = add(new Setting.Bool("Sprint", true));
    public final Setting.Num pitch = add(new Setting.Num("Pitch", 88, -90, 90, 1));
    public final Setting.Bool autoStart = add(new Setting.Bool("AutoStart", true));
    public final Setting.Bool checkSpeed = add(new Setting.Bool("CheckSpeed", false));
    public final Setting.Num minSpeed = add(new Setting.Num("MinSpeed", 70, 0.1, 200, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay", 1000, 0, 20000, 50));
    public final Setting.Num timeout = add(new Setting.Num("Timeout", 0.1, 0.1, 1, 0.1));
    public final Setting.Num downSpeed = add(new Setting.Num("DownSpeed", 1, 0.1, 10, 0.1));
    public final Setting.Num boost = add(new Setting.Num("Boost", 1, 0.1, 4, 0.1));
    public final Setting.Bool freeze = add(new Setting.Bool("Freeze", false));
    public final Setting.Bool motionStop = add(new Setting.Bool("MotionStop", false));
    public final Setting.Num infiniteMaxSpeed = add(new Setting.Num("InfiniteMaxSpeed", 150, 50, 170, 1));
    public final Setting.Num infiniteMinSpeed = add(new Setting.Num("InfiniteMinSpeed", 25, 10, 70, 1));
    public final Setting.Num infiniteMaxHeight = add(new Setting.Num("InfiniteMaxHeight", 200, -50, 360, 1));
    public final Setting.Bool releaseSneak = add(new Setting.Bool("ReleaseSneak", false));

    private boolean hasElytra;
    private boolean flying;
    private long fireworkTime = Long.MIN_VALUE / 4;
    private long instantFlyTime;
    private boolean bindDown;
    private boolean pitchSpoofed;
    private float prePitch;
    private float preYaw;
    private float infinitePitch;
    private boolean infDown;

    public ElytraFly() {
        super("ElytraFly", Category.MOVEMENT);
    }

    public boolean isFallFlying() {
        return mc.player != null && (mc.player.isFallFlying() || flying);
    }

    private static boolean passed(long since, long ms) {
        return System.currentTimeMillis() - since >= ms;
    }

    @Override
    public void onDisable() {
        pitchSpoofed = false;
        if (mc.player != null && releaseSneak.value && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.RELEASE_SHIFT_KEY));
        }
    }

    // ------------------------------------------------------------ firework
    private void useFireworkItem() {
        if (packetInteract.value) {
            Util.sendSequenced(id -> new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, id, mc.player.getYaw(), mc.player.getPitch()));
        } else {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        }
    }

    public void shootFirework() {
        if (inventory.value && !Util.inInventory()) return;
        if (onlyOne.value) {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof FireworkRocketEntity f && f.getOwner() == mc.player) return;
            }
        }
        fireworkTime = System.currentTimeMillis();
        int slot;
        if (mc.player.getMainHandStack().getItem() == Items.FIREWORK_ROCKET) {
            useFireworkItem();
        } else if (inventory.value && (slot = Util.findInvSlot(Items.FIREWORK_ROCKET)) != -1) {
            Util.inventorySwap(slot);
            useFireworkItem();
            Util.inventorySwap(slot);
        } else if ((slot = Util.findHotbar(Items.FIREWORK_ROCKET)) != -1) {
            int old = mc.player.getInventory().selectedSlot;
            Util.switchToSlot(slot);
            useFireworkItem();
            Util.switchToSlot(old);
        }
    }

    // ------------------------------------------------------------ tick
    @Override
    public void onAlwaysTick() {
        if (mc.player == null) return;
        // Phim ban firework (hoat dong khi module bat)
        boolean down = isEnabled() && mc.currentScreen == null && Util.isKeyDown(fireworkBind.key);
        if (down && !bindDown && passed(fireworkTime, (long) delay.value)
                && (!mc.player.isUsingItem() || !usingPause.value) && isFallFlying()) {
            shootFirework();
        }
        bindDown = down;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;
        flying = false;
        hasElytra = false;
        if (mode.is("Pitch")) updateInfinitePitch();
        for (ItemStack is : mc.player.getArmorItems()) {
            if (is.getItem() instanceof ElytraItem) {
                hasElytra = true;
                break;
            }
        }
        if (infiniteDura.value && !mc.player.isOnGround() && hasElytra) {
            flying = true;
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 6, 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 6, 0, SlotActionType.PICKUP, mc.player);
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            if (setFlag.value) mc.player.startFallFlying();
        }

        if (mode.is("Bounce")) {
            if (!hasElytra) return;
            if (autoJump.value) mc.options.jumpKey.setPressed(true);
            if (!isFallFlying()) {
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            }
            if (checkConditions()) {
                if (!sprint.value) mc.player.setSprinting(isFallFlying() ? mc.player.isOnGround() : true);
                else mc.player.setSprinting(true);
            }
            return;
        }

        double dx = mc.player.getX() - mc.player.prevX;
        double dy = mc.player.getY() - mc.player.prevY;
        double dz = mc.player.getZ() - mc.player.prevZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz) / 1000.0;
        double spd = dist / (0.05 / 3600.0);

        if (mode.is("Boost") && hasElytra && isFallFlying() && mc.options.forwardKey.isPressed()) {
            float yaw = (float) Math.toRadians(mc.player.getYaw());
            mc.player.addVelocity(-MathHelper.sin(yaw) * boost.value / 10, 0, MathHelper.cos(yaw) * boost.value / 10);
        }

        if ((!checkSpeed.value || spd <= minSpeed.value) && firework.value && passed(fireworkTime, (long) delay.value)
                && Util.isMoving() && (!mc.player.isUsingItem() || !usingPause.value) && isFallFlying()) {
            shootFirework();
        }

        if (!isFallFlying() && hasElytra) {
            fireworkTime = Long.MIN_VALUE / 4;
            if (!mc.player.isOnGround() && autoStart.value && mc.player.getVelocity().y < 0.0 && !infiniteDura.value) {
                if (!passed(instantFlyTime, (long) (1000 * timeout.value))) return;
                instantFlyTime = System.currentTimeMillis();
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                if (setFlag.value) mc.player.startFallFlying();
            }
        }
    }

    private boolean checkConditions() {
        ItemStack st = mc.player.getEquippedStack(EquipmentSlot.CHEST);
        return !mc.player.getAbilities().flying && !mc.player.hasVehicle() && !mc.player.isClimbing()
                && st.isOf(Items.ELYTRA) && ElytraItem.isUsable(st);
    }

    // ------------------------------------------------------------ travel (goi tu ElytraTravelMixin)
    /** Tra ve true de huy travel cua vanilla. */
    public boolean travelPre() {
        if (mc.player == null || !hasElytra) return false;
        if (mode.is("Bounce")) {
            preYaw = mc.player.getYaw();
            prePitch = mc.player.getPitch();
            mc.player.setPitch((float) pitch.value);
            pitchSpoofed = true;
            return false;
        }
        if (!isFallFlying()) return false;

        if (autoStop.value) {
            int cx = (int) (mc.player.getX() / 16);
            int cz = (int) (mc.player.getZ() / 16);
            if (!mc.world.getChunkManager().isChunkLoaded(cx, cz)) return true;
        }
        if (mode.is("Pitch")) {
            preYaw = mc.player.getYaw();
            prePitch = mc.player.getPitch();
            mc.player.setPitch(infinitePitch);
            pitchSpoofed = true;
            return false;
        }
        if (mode.is("Freeze") || (mode.is("Rotation") && freeze.value)) {
            if (!Util.isMoving() && !mc.options.jumpKey.isPressed() && !mc.options.sneakKey.isPressed()) return true;
        }
        if (mode.is("Rotation")) {
            preYaw = mc.player.getYaw();
            prePitch = mc.player.getPitch();
            pitchSpoofed = true;
            float newPitch = prePitch;
            Vec3d vel = mc.player.getVelocity();
            if (Util.isMoving()) {
                if (mc.options.jumpKey.isPressed()) newPitch = -45;
                else if (mc.options.sneakKey.isPressed()) newPitch = 45;
                else {
                    newPitch = -1.9f;
                    if (motionStop.value) mc.player.setVelocity(vel.x, 0, vel.z);
                }
            } else {
                if (mc.options.jumpKey.isPressed()) newPitch = -89;
                else if (mc.options.sneakKey.isPressed()) newPitch = 89;
                else if (motionStop.value) mc.player.setVelocity(vel.x, 0, vel.z);
            }
            if (Util.isMoving()) {
                float f = mc.player.input.movementForward, sd = mc.player.input.movementSideways;
                mc.player.setYaw(preYaw - (float) Math.toDegrees(Math.atan2(sd, f)));
            } else if (motionStop.value) {
                Vec3d v2 = mc.player.getVelocity();
                mc.player.setVelocity(0, v2.y, 0);
            }
            mc.player.setPitch(newPitch);
            return false;
        }
        if (!mode.is("Control")) return false;

        Vec3d v = mc.player.getVelocity();
        double x = v.x, y = v.y, z = v.z;
        var in = mc.player.input;
        if (firework.value) {
            if (!(mc.options.sneakKey.isPressed() && in.jumping)) {
                if (mc.options.sneakKey.isPressed()) y = -downSpeed.value;
                else if (in.jumping) y = upFactor.value;
                else y = -0.00000000003D * fallSpeed.value;
            } else {
                y = 0;
            }
            double[] dir = directionSpeed(speed.value);
            mc.player.setVelocity(dir[0], y, dir[1]);
            return false;
        }

        Vec3d look = lookVec();
        double lookDist = Math.sqrt(look.x * look.x + look.z * look.z);
        double motionDist = Math.sqrt(x * x + z * z);
        if (in.sneaking) y = -downSpeed.value;
        else if (!in.jumping) y = -0.00000000003D * fallSpeed.value;
        if (in.jumping) {
            if (motionDist > upFactor.value / upFactor.max) {
                double up = motionDist * 0.01325D;
                y += up * 3.2D;
                if (lookDist > 0) {
                    x -= look.x * up / lookDist;
                    z -= look.z * up / lookDist;
                }
            } else {
                double[] dir = directionSpeed(speed.value);
                x = dir[0];
                z = dir[1];
            }
        }
        if (lookDist > 0.0D) {
            x += (look.x / lookDist * motionDist - x) * 0.1D;
            z += (look.z / lookDist * motionDist - z) * 0.1D;
        }
        if (!in.jumping) {
            double[] dir = directionSpeed(speed.value);
            x = dir[0];
            z = dir[1];
        }
        if (!noDrag.value) {
            y *= 0.9900000095367432D;
            x *= 0.9800000190734863D;
            z *= 0.9900000095367432D;
        }
        double fin = Math.sqrt(x * x + z * z);
        if (speedLimit.value && fin > maxSpeed.value) {
            x = x * maxSpeed.value / fin;
            z = z * maxSpeed.value / fin;
        }
        mc.player.setVelocity(x, y, z);
        mc.player.move(MovementType.SELF, mc.player.getVelocity());
        return true;
    }

    public void travelPost() {
        if (pitchSpoofed && mc.player != null) {
            mc.player.setPitch(prePitch);
            mc.player.setYaw(preYaw);
        }
        pitchSpoofed = false;
    }

    private void updateInfinitePitch() {
        double spd = Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ);
        if (mc.player.getY() < infiniteMaxHeight.value) {
            if (spd * 72f < infiniteMinSpeed.value && !infDown) infDown = true;
            if (spd * 72f > infiniteMaxSpeed.value && infDown) infDown = false;
        } else {
            infDown = true;
        }
        if (infDown) infinitePitch += 3;
        else infinitePitch -= 3;
        infinitePitch = MathHelper.clamp(infinitePitch, -40, 40);
    }

    private Vec3d lookVec() {
        float f = (float) (-upPitch.value) * 0.017453292F;
        float g = -mc.player.getYaw() * 0.017453292F;
        float h = MathHelper.cos(g);
        float i = MathHelper.sin(g);
        float j = MathHelper.cos(f);
        float k = MathHelper.sin(f);
        return new Vec3d(i * j, -k, h * j);
    }

    private double[] directionSpeed(double spd) {
        float forward = mc.player.input.movementForward;
        float side = mc.player.input.movementSideways;
        float yaw = mc.player.getYaw();
        if (forward != 0.0f || side != 0.0f) {
            if (forward != 0.0f) {
                if (side > 0.0f) yaw += forward > 0.0f ? -45 : 45;
                else if (side < 0.0f) yaw += forward > 0.0f ? 45 : -45;
                side = 0.0f;
                forward = forward > 0.0f ? 1.0f : -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        return new double[]{forward * spd * cos + side * spd * sin, forward * spd * sin - side * spd * cos};
    }
}
