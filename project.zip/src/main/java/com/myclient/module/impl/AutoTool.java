package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Dang dap block thi tu chon cuoc / xeng / riu nhanh nhat trong hotbar; danh nguoi thi cam kiem. */
public class AutoTool extends Module {
    public final Setting.Bool weapon = add(new Setting.Bool("Weapon", true));
    public final Setting.Bool switchBack = add(new Setting.Bool("Switch back", true));

    private int prevSlot = -1;

    public AutoTool() {
        super("AutoTool", Category.MISC);
    }

    @Override
    public void onDisable() {
        restore();
    }

    private void restore() {
        if (prevSlot != -1 && mc.player != null) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        boolean attacking = mc.options.attackKey.isPressed();
        HitResult hr = mc.crosshairTarget;
        PlayerInventory inv = mc.player.getInventory();

        if (attacking && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.world.getBlockState(bhr.getBlockPos());
            if (st.getHardness(mc.world, bhr.getBlockPos()) < 0) return;
            int best = inv.selectedSlot;
            float bestSpeed = inv.getStack(best).getMiningSpeedMultiplier(st);
            for (int i = 0; i < 9; i++) {
                float sp = inv.getStack(i).getMiningSpeedMultiplier(st);
                if (sp > bestSpeed + 0.01f) {
                    bestSpeed = sp;
                    best = i;
                }
            }
            select(inv, best);
            return;
        }

        if (weapon.value && attacking && hr instanceof EntityHitResult) {
            int best = inv.selectedSlot;
            int bestScore = score(inv.getStack(best));
            for (int i = 0; i < 9; i++) {
                int sc = score(inv.getStack(i));
                if (sc > bestScore) {
                    bestScore = sc;
                    best = i;
                }
            }
            select(inv, best);
            return;
        }

        if (switchBack.value && !attacking) restore();
    }

    private int score(ItemStack s) {
        if (s.getItem() instanceof SwordItem) return 2;
        if (s.getItem() instanceof AxeItem) return 1;
        return 0;
    }

    private void select(PlayerInventory inv, int slot) {
        if (slot == inv.selectedSlot) return;
        if (prevSlot == -1) prevSlot = inv.selectedSlot;
        inv.selectedSlot = slot;
    }
}
