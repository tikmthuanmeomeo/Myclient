package com.myclient.module.impl;

import com.myclient.gui.ClickGuiScreen;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import org.lwjgl.glfw.GLFW;

/**
 * Module mo Click GUI. Phim mo GUI = phim gan cho module nay (mac dinh Right Shift):
 * mo danh sach setting cua ClickGui trong GUI roi bam dong "Key" de doi phim.
 */
public class ClickGui extends Module {
    public final Setting.Num notifyScale = add(new Setting.Num("Notify scale", 1.2, 0.8, 2.0, 0.1));

    public ClickGui() {
        super("ClickGui", Category.CLIENT);
        key = GLFW.GLFW_KEY_RIGHT_SHIFT;
    }

    /** Khong co trang thai bat/tat: bam phim chi mo GUI. */
    @Override
    public void toggle() {
        if (mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGuiScreen());
    }
}
