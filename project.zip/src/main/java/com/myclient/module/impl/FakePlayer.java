package com.myclient.module.impl;

import com.mojang.authlib.GameProfile;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.UUID;

/** Tao nguoi choi gia (chi minh thay) dung tai cho de tap crystal / test module. */
public class FakePlayer extends Module {
    public final Setting.Text name = add(new Setting.Text("Name", "Eclipse", 16));
    public final Setting.Num health = add(new Setting.Num("Health", 20, 1, 36, 1));
    public final Setting.Bool copyInventory = add(new Setting.Bool("Copy inventory", true));

    private static int nextId = 0;
    private OtherClientPlayerEntity fake;

    public FakePlayer() {
        super("FakePlayer", Category.PLAYER);
    }

    @Override
    public void onEnable() {
        spawn();
    }

    @Override
    public void onDisable() {
        remove();
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;
        if (fake == null || fake.isRemoved() || fake.getWorld() != mc.world) {
            fake = null;
            spawn();
        }
    }

    private void spawn() {
        if (mc.world == null || mc.player == null) return;
        String n = name.value.trim();
        if (n.isEmpty()) n = "Eclipse";
        OtherClientPlayerEntity e = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), n));
        e.copyPositionAndRotation(mc.player);
        e.headYaw = mc.player.headYaw;
        e.bodyYaw = mc.player.bodyYaw;
        if (copyInventory.value) e.getInventory().clone(mc.player.getInventory());
        float hp = (float) health.value;
        e.setHealth(Math.min(hp, 20f));
        e.setAbsorptionAmount(Math.max(0f, hp - 20f));
        e.setId(-1000 - (nextId++ % 100000));
        mc.world.addEntity(e);
        fake = e;
    }

    private void remove() {
        if (fake != null && mc.world != null) {
            mc.world.removeEntity(fake.getId(), Entity.RemovalReason.DISCARDED);
        }
        fake = null;
    }
}
