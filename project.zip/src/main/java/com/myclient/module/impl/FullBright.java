package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Sang toan bo bang night vision phia client (khong hien icon). */
public class FullBright extends Module {
    private boolean added;

    public FullBright() {
        super("FullBright", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.player == null) {
            added = false;
            return;
        }
        if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
            mc.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, StatusEffectInstance.INFINITE, 0, false, false, false));
            added = true;
        }
    }

    @Override
    public void onDisable() {
        if (added && mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        added = false;
    }
}
