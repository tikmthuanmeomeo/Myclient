package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Tu bao ve: xay obsidian quanh chan, quanh dau va nap tren dau. */
public class SelfTrap extends Module {
    public final Setting.Bool feet = add(new Setting.Bool("Feet ring", true));
    public final Setting.Bool head = add(new Setting.Bool("Head ring", true));
    public final Setting.Bool top = add(new Setting.Bool("Top", true));
    public final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 2, 1, 4, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 5, 1));
    public final Setting.Bool disableOnMove = add(new Setting.Bool("Disable on move", true));
    public final Setting.Bool autoDisable = add(new Setting.Bool("Auto disable", false));

    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    private BlockPos startPos;
    private int prevSlot = -1;
    private int cooldown;

    public SelfTrap() {
        super("SelfTrap", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        startPos = mc.player != null ? mc.player.getBlockPos() : null;
        cooldown = 0;
    }

    @Override
    public void onDisable() {
        restoreSlot();
        startPos = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        BlockPos base = mc.player.getBlockPos();
        if (disableOnMove.value && startPos != null && !base.equals(startPos)) {
            toggle();
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        List<BlockPos> todo = new ArrayList<>();
        if (feet.value) for (Direction d : SIDES) todo.add(base.offset(d));
        if (head.value) for (Direction d : SIDES) todo.add(base.up().offset(d));
        if (top.value) todo.add(base.up(2));

        List<BlockPos> missing = new ArrayList<>();
        for (BlockPos p : todo) {
            if (mc.world.getBlockState(p).isReplaceable()) missing.add(p);
        }
        if (missing.isEmpty()) {
            restoreSlot();
            if (autoDisable.value) toggle();
            return;
        }

        int slot = findObsidian();
        if (slot == -1) {
            restoreSlot();
            return;
        }

        int placed = 0;
        for (BlockPos p : missing) {
            if (placed >= (int) perTick.value) break;
            if (tryPlace(p, slot)) placed++;
        }
        if (placed > 0) cooldown = (int) delay.value;
    }

    private boolean tryPlace(BlockPos target, int slot) {
        if (!mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), target, ShapeContext.absent())) return false;

        // Tim mat tua: block ke ben da co (uu tien phia duoi, roi 4 huong, roi phia tren)
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : order) {
            BlockPos nb = target.offset(d);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = d.getOpposite(); // mat cua block tua huong ve target
            Vec3d hitPos = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (mc.player.getEyePos().squaredDistanceTo(hitPos) > 36.0) return false;

            PlayerInventory inv = mc.player.getInventory();
            if (prevSlot == -1) prevSlot = inv.selectedSlot;
            inv.selectedSlot = slot;
            BlockHitResult hit = new BlockHitResult(hitPos, face, nb, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false; // chua co block nao de tua (vd: nap tren cho den khi xay xong vong dau)
    }

    private int findObsidian() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getStack(i);
            if (st.getItem() instanceof BlockItem bi) {
                Block b = bi.getBlock();
                if (b == Blocks.OBSIDIAN) return i;
            }
        }
        return -1;
    }

    private void restoreSlot() {
        if (prevSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }
}
