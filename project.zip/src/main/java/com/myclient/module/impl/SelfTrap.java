package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Setting;
import com.myclient.util.Util;
import net.minecraft.util.math.BlockPos;

/** SelfTrap port tu AlienClient: dat obsidian quanh chan, quanh nguoi va nap tren dau. */
public class SelfTrap extends PlaceBase {
    public final Setting.Bool head = add(new Setting.Bool("Head", true));
    public final Setting.Bool feet = add(new Setting.Bool("Feet", true));
    public final Setting.Bool chest = add(new Setting.Bool("Chest", true));
    public final Setting.Bool noBlockDisable = add(new Setting.Bool("NoBlockDisable", true));
    public final Setting.KeyBind headKey = add(new Setting.KeyBind("HeadKey", -1));

    private boolean headKeyDown;

    public SelfTrap() {
        super("SelfTrap", Category.COMBAT);
    }

    @Override
    protected void onNoBlock() {
        if (noBlockDisable.value) toggle();
    }

    @Override
    protected boolean shouldExtend(BlockPos pos) {
        return Util.selfIntersect(pos);
    }

    @Override
    public void onTick() {
        if (!preTick()) return;
        BlockPos pos = Util.playerPos(true);
        if (head.value) tryPlace(pos.up(2));
        if (feet.value) doSurround(pos);
        if (chest.value) doSurround(pos.up());
    }

    /** Phim HeadKey: dat nap tren dau 1 lan, ke ca khi module dang tat. */
    @Override
    public void onAlwaysTick() {
        if (mc.player == null || mc.world == null) return;
        boolean down = Util.isKeyDown(headKey.key) && mc.currentScreen == null;
        if (down && !headKeyDown) {
            progress = 0;
            if (getBlock() != -1 && (inAir.value || mc.player.isOnGround()) && (!inventory.value || Util.inInventory())) {
                tryPlace(Util.playerPos(true).up(2));
            }
        }
        headKeyDown = down;
    }
}
