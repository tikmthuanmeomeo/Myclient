package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Tu bao ve: xay obsidian quanh chan, quanh dau va nap tren dau. */
public class SelfTrap extends Module {
    public final Setting.Bool feet = add(new Setting.Bool("Feet ring", true));
    public final Setting.Bool head = add(new Setting.Bool("Head ring", true));
    public final Setting.Bool top = add(new Setting.Bool("Top", true));
    public final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 4, 1, 8, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 5, 1));
    /** Dat block giua khong khi (khong can block de tua). */
    public final Setting.Bool airPlace = add(new Setting.Bool("Air place", true));
    public final Setting.Bool disableOnMove = add(new Setting.Bool("Disable on move", false));
    public final Setting.Bool autoDisable = add(new Setting.Bool("Auto disable", false));

    // ---- Render (mac dinh tat): ve o khoi vua dat, mo dan theo thoi gian ----
    public final Setting.Group render = add(new Setting.Group("Render", true, false));
    public final Setting.Color fillColor = render.add(new Setting.Color("Fill", 0x554D6BFF));
    public final Setting.Color outlineColor = render.add(new Setting.Color("Outline", 0xFF4D6BFF));
    public final Setting.Num lineWidth = render.add(new Setting.Num("LineWidth", 1.0, 0.5, 5.0, 0.5));
    public final Setting.Bool fade = render.add(new Setting.Bool("Fade", true));
    public final Setting.Num fadeTime = render.add(new Setting.Num("FadeTime", 1.0, 0.2, 3.0, 0.1));

    /** Vi tri vua dat -> thoi diem (ms). */
    private final Map<BlockPos, Long> placedAt = new HashMap<>();

    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    private BlockPos startPos;
    private int prevSlot = -1;
    private int cooldown;

    public SelfTrap() {
        super("SelfTrap", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        startPos = mc.player != null ? mc.player.getBlockPos() : null;
        cooldown = 0;
    }

    @Override
    public void onDisable() {
        placedAt.clear();
        restoreSlot();
        startPos = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        BlockPos base = mc.player.getBlockPos();
        if (disableOnMove.value && startPos != null && !base.equals(startPos)) {
            toggle();
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        // O nguoi dang chiem (co the 1-4 o neu dung o ranh gioi block)
        Box bb = mc.player.getBoundingBox();
        int x0 = MathHelper.floor(bb.minX + 0.001), x1 = MathHelper.floor(bb.maxX - 0.001);
        int z0 = MathHelper.floor(bb.minZ + 0.001), z1 = MathHelper.floor(bb.maxZ - 0.001);
        int y = MathHelper.floor(bb.minY + 0.01);

        Set<BlockPos> occupied = new LinkedHashSet<>();
        for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) occupied.add(new BlockPos(x, y, z));

        Set<BlockPos> ring = new LinkedHashSet<>();
        for (BlockPos o : occupied) {
            for (Direction d : SIDES) {
                BlockPos n = o.offset(d);
                if (!occupied.contains(n)) ring.add(n);
            }
        }

        List<BlockPos> todo = new ArrayList<>();
        if (feet.value) todo.addAll(ring);
        if (head.value) for (BlockPos r : ring) todo.add(r.up());
        if (top.value) for (BlockPos o : occupied) todo.add(o.up(2));

        List<BlockPos> missing = new ArrayList<>();
        for (BlockPos p : todo) {
            if (mc.world.getBlockState(p).isReplaceable()) missing.add(p);
        }
        if (missing.isEmpty()) {
            restoreSlot();
            if (autoDisable.value) toggle();
            return;
        }

        int slot = findObsidian();
        if (slot == -1) {
            restoreSlot();
            return;
        }

        int placed = 0;
        for (BlockPos p : missing) {
            if (placed >= (int) perTick.value) break;
            if (tryPlace(p, slot)) placed++;
        }
        if (placed > 0) cooldown = (int) delay.value;
    }

    private boolean tryPlace(BlockPos target, int slot) {
        if (!mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), target, ShapeContext.absent())) return false;

        // Tim mat tua: block ke ben da co (uu tien phia duoi, roi 4 huong, roi phia tren)
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : order) {
            BlockPos nb = target.offset(d);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = d.getOpposite(); // mat cua block tua huong ve target
            Vec3d hitPos = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (mc.player.getEyePos().squaredDistanceTo(hitPos) > 36.0) return false;

            PlayerInventory inv = mc.player.getInventory();
            if (prevSlot == -1) prevSlot = inv.selectedSlot;
            inv.selectedSlot = slot;
            BlockHitResult hit = new BlockHitResult(hitPos, face, nb, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);
            placedAt.put(target.toImmutable(), System.currentTimeMillis());
            return true;
        }

        // Khong co block de tua: dat giua khong khi bang cach bam thang vao o can dat
        if (!airPlace.value) return false;
        Vec3d c = Vec3d.ofCenter(target);
        if (mc.player.getEyePos().squaredDistanceTo(c) > 36.0) return false;
        PlayerInventory inv = mc.player.getInventory();
        if (prevSlot == -1) prevSlot = inv.selectedSlot;
        inv.selectedSlot = slot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(c, Direction.UP, target, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        placedAt.put(target.toImmutable(), System.currentTimeMillis());
        return true;
    }

    private int findObsidian() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getStack(i);
            if (st.getItem() instanceof BlockItem bi) {
                Block b = bi.getBlock();
                if (b == Blocks.OBSIDIAN) return i;
            }
        }
        return -1;
    }

    /** Goi tu WorldRenderEvents.AFTER_ENTITIES. */
    public void renderWorld(WorldRenderContext ctx) {
        if (!isEnabled() || !render.enabled || placedAt.isEmpty() || mc.player == null) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        long now = System.currentTimeMillis();
        double dur = fadeTime.value * 1000.0;
        Vec3d cam = ctx.camera().getPos();
        Matrix4f m = ms.peek().getPositionMatrix();

        float fr = fillColor.r(), fg = fillColor.g(), fb = fillColor.b(), fa = fillColor.alpha;
        float orr = outlineColor.r(), og = outlineColor.g(), ob = outlineColor.b(), oa = outlineColor.alpha;
        float t = (float) (lineWidth.value * 0.012);

        BufferBuilder buf = null;
        Iterator<Map.Entry<BlockPos, Long>> it = placedAt.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Long> e = it.next();
            double age = (now - e.getValue()) / dur;
            if (age >= 1.0) {
                it.remove();
                continue;
            }
            float k = fade.value ? (float) (1.0 - age) : 1f;
            if (buf == null) buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            BlockPos p = e.getKey();
            float x0 = (float) (p.getX() - cam.x), y0 = (float) (p.getY() - cam.y), z0 = (float) (p.getZ() - cam.z);
            float x1 = x0 + 1f, y1 = y0 + 1f, z1 = z0 + 1f;

            if (fa > 0f) cuboid(buf, m, x0, y0, z0, x1, y1, z1, fr, fg, fb, fa * k);
            if (oa > 0f) {
                float a = oa * k;
                // 4 canh doc, 4 canh tren, 4 canh duoi
                cuboid(buf, m, x0 - t, y0 - t, z0 - t, x0 + t, y1 + t, z0 + t, orr, og, ob, a);
                cuboid(buf, m, x1 - t, y0 - t, z0 - t, x1 + t, y1 + t, z0 + t, orr, og, ob, a);
                cuboid(buf, m, x0 - t, y0 - t, z1 - t, x0 + t, y1 + t, z1 + t, orr, og, ob, a);
                cuboid(buf, m, x1 - t, y0 - t, z1 - t, x1 + t, y1 + t, z1 + t, orr, og, ob, a);
                for (float yy : new float[]{y0, y1}) {
                    cuboid(buf, m, x0 - t, yy - t, z0 - t, x1 + t, yy + t, z0 + t, orr, og, ob, a);
                    cuboid(buf, m, x0 - t, yy - t, z1 - t, x1 + t, yy + t, z1 + t, orr, og, ob, a);
                    cuboid(buf, m, x0 - t, yy - t, z0 - t, x0 + t, yy + t, z1 + t, orr, og, ob, a);
                    cuboid(buf, m, x1 - t, yy - t, z0 - t, x1 + t, yy + t, z1 + t, orr, og, ob, a);
                }
            }
        }
        if (buf == null) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        BufferRenderer.drawWithGlobalProgram(buf.end());
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    private static void cuboid(BufferBuilder b, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                               float r, float g, float bl, float a) {
        // duoi / tren
        quad(b, m, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, bl, a);
        quad(b, m, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, bl, a);
        // bac / nam
        quad(b, m, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, r, g, bl, a);
        quad(b, m, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, bl, a);
        // tay / dong
        quad(b, m, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, bl, a);
        quad(b, m, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, bl, a);
    }

    private static void quad(BufferBuilder b, Matrix4f m,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float r, float g, float bl, float a) {
        b.vertex(m, ax, ay, az).color(r, g, bl, a);
        b.vertex(m, bx, by, bz).color(r, g, bl, a);
        b.vertex(m, cx, cy, cz).color(r, g, bl, a);
        b.vertex(m, dx, dy, dz).color(r, g, bl, a);
    }

    private void restoreSlot() {
        if (prevSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }
}
