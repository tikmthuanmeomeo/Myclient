package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Tu bao ve: xay obsidian quanh chan, quanh dau va nap tren dau. */
public class SelfTrap extends Module {
    public final Setting.Bool feet = add(new Setting.Bool("Feet ring", true));
    public final Setting.Bool head = add(new Setting.Bool("Head ring", true));
    public final Setting.Bool top = add(new Setting.Bool("Top", true));
    public final Setting.Num perTick = add(new Setting.Num("Blocks per tick", 4, 1, 8, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 5, 1));
    /** Dat block giua khong khi (khong can block de tua). */
    public final Setting.Bool airPlace = add(new Setting.Bool("Air place", true));
    public final Setting.Bool disableOnMove = add(new Setting.Bool("Disable on move", false));
    public final Setting.Bool autoDisable = add(new Setting.Bool("Auto disable", false));

    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    private BlockPos startPos;
    private int prevSlot = -1;
    private int cooldown;

    public SelfTrap() {
        super("SelfTrap", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        startPos = mc.player != null ? mc.player.getBlockPos() : null;
        cooldown = 0;
    }

    @Override
    public void onDisable() {
        restoreSlot();
        startPos = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        BlockPos base = mc.player.getBlockPos();
        if (disableOnMove.value && startPos != null && !base.equals(startPos)) {
            toggle();
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        // O nguoi dang chiem (co the 1-4 o neu dung o ranh gioi block)
        Box bb = mc.player.getBoundingBox();
        int x0 = MathHelper.floor(bb.minX + 0.001), x1 = MathHelper.floor(bb.maxX - 0.001);
        int z0 = MathHelper.floor(bb.minZ + 0.001), z1 = MathHelper.floor(bb.maxZ - 0.001);
        int y = MathHelper.floor(bb.minY + 0.01);

        Set<BlockPos> occupied = new LinkedHashSet<>();
        for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) occupied.add(new BlockPos(x, y, z));

        Set<BlockPos> ring = new LinkedHashSet<>();
        for (BlockPos o : occupied) {
            for (Direction d : SIDES) {
                BlockPos n = o.offset(d);
                if (!occupied.contains(n)) ring.add(n);
            }
        }

        List<BlockPos> todo = new ArrayList<>();
        if (feet.value) todo.addAll(ring);
        if (head.value) for (BlockPos r : ring) todo.add(r.up());
        if (top.value) for (BlockPos o : occupied) todo.add(o.up(2));

        List<BlockPos> missing = new ArrayList<>();
        for (BlockPos p : todo) {
            if (mc.world.getBlockState(p).isReplaceable()) missing.add(p);
        }
        if (missing.isEmpty()) {
            restoreSlot();
            if (autoDisable.value) toggle();
            return;
        }

        int slot = findObsidian();
        if (slot == -1) {
            restoreSlot();
            return;
        }

        int placed = 0;
        for (BlockPos p : missing) {
            if (placed >= (int) perTick.value) break;
            if (tryPlace(p, slot)) placed++;
        }
        if (placed > 0) cooldown = (int) delay.value;
    }

    private boolean tryPlace(BlockPos target, int slot) {
        if (!mc.world.canPlace(Blocks.OBSIDIAN.getDefaultState(), target, ShapeContext.absent())) return false;

        // Tim mat tua: block ke ben da co (uu tien phia duoi, roi 4 huong, roi phia tren)
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : order) {
            BlockPos nb = target.offset(d);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = d.getOpposite(); // mat cua block tua huong ve target
            Vec3d hitPos = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (mc.player.getEyePos().squaredDistanceTo(hitPos) > 36.0) return false;

            PlayerInventory inv = mc.player.getInventory();
            if (prevSlot == -1) prevSlot = inv.selectedSlot;
            inv.selectedSlot = slot;
            BlockHitResult hit = new BlockHitResult(hitPos, face, nb, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }

        // Khong co block de tua: dat giua khong khi bang cach bam thang vao o can dat
        if (!airPlace.value) return false;
        Vec3d c = Vec3d.ofCenter(target);
        if (mc.player.getEyePos().squaredDistanceTo(c) > 36.0) return false;
        PlayerInventory inv = mc.player.getInventory();
        if (prevSlot == -1) prevSlot = inv.selectedSlot;
        inv.selectedSlot = slot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(c, Direction.UP, target, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private int findObsidian() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getStack(i);
            if (st.getItem() instanceof BlockItem bi) {
                Block b = bi.getBlock();
                if (b == Blocks.OBSIDIAN) return i;
            }
        }
        return -1;
    }

    private void restoreSlot() {
        if (prevSlot != -1 && mc.player != null) {
            mc.player.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }
}
