package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Chi chat khi nguoi choi MA MINH VUA DANH bi be totem: "<Message> <so lan>" (ez pop 1, ez pop 2, ...).
 * Nguoi bi ai khac danh be totem thi khong chat. So lan duoc dem rieng tung nguoi (chi dem lan minh danh),
 * reset khi ho chet.
 */
public class TotemPops extends Module {
    public final Setting.Text message = add(new Setting.Text("Message", "ez pop", 64));
    public final Setting.Bool addName = add(new Setting.Bool("Add name", false));
    public final Setting.Num window = add(new Setting.Num("Hit window (sec)", 3, 1, 10, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 10, 0, 100, 5));

    private final Map<UUID, Integer> pops = new HashMap<>();
    private final Map<UUID, Long> lastHit = new HashMap<>();
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private int cooldown;
    private long tickCounter;

    public TotemPops() {
        super("TotemPops", Category.COMBAT);
    }

    /** Goi tu mixin khi minh danh 1 entity. */
    public void onAttack(Entity target) {
        if (target instanceof PlayerEntity p && p != mc.player) {
            lastHit.put(p.getUuid(), tickCounter);
        }
    }

    /** Goi tu mixin: status 35 = be totem, 3 = chet. */
    public void onStatus(Entity e, int status) {
        if (!(e instanceof PlayerEntity p) || p == mc.player) return;
        if (status == 3) {
            pops.remove(p.getUuid());
            lastHit.remove(p.getUuid());
            return;
        }
        if (status != 35) return;
        if (!isEnabled()) return;

        // Chi tinh khi minh vua danh nguoi nay
        Long t = lastHit.get(p.getUuid());
        if (t == null || tickCounter - t > (long) (window.value * 20)) return;

        int n = pops.merge(p.getUuid(), 1, Integer::sum);

        String base = message.value.trim();
        if (base.isEmpty()) return;
        String msg = base + (addName.value ? " " + p.getName().getString() : "") + " " + n;
        queue.addLast(msg);
        while (queue.size() > 5) queue.pollFirst();
    }

    @Override
    public void onAlwaysTick() {
        tickCounter++;
        if (mc.world == null) {
            pops.clear();
            lastHit.clear();
            queue.clear();
        }
    }

    @Override
    public void onDisable() {
        queue.clear();
    }

    @Override
    public void onTick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.getNetworkHandler() == null) return;
        String m = queue.pollFirst();
        if (m == null) return;
        if (m.startsWith("/")) mc.getNetworkHandler().sendChatCommand(m.substring(1));
        else mc.getNetworkHandler().sendChatMessage(m);
        cooldown = (int) delay.value;
    }
}
