package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Khi nguoi khac bi bể totem, tu dong chat "<Message> <so lan>" (ez pop 1, ez pop 2, ...).
 * So lan duoc dem rieng tung nguoi va reset khi ho chet.
 */
public class TotemPops extends Module {
    public final Setting.Text message = add(new Setting.Text("Message", "ez pop", 64));
    public final Setting.Bool addName = add(new Setting.Bool("Add name", false));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 10, 0, 100, 5));

    private final Map<UUID, Integer> pops = new HashMap<>();
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private int cooldown;

    public TotemPops() {
        super("TotemPops", Category.COMBAT);
    }

    /** Goi tu mixin: status 35 = bể totem, 3 = chet. */
    public void onStatus(Entity e, int status) {
        if (!(e instanceof PlayerEntity p) || p == mc.player) return;
        if (status == 3) {
            pops.remove(p.getUuid());
            return;
        }
        if (status != 35) return;

        int n = pops.merge(p.getUuid(), 1, Integer::sum);
        if (!isEnabled()) return;

        String base = message.value.trim();
        if (base.isEmpty()) return;
        String msg = base + (addName.value ? " " + p.getName().getString() : "") + " " + n;
        queue.addLast(msg);
        while (queue.size() > 5) queue.pollFirst();
    }

    @Override
    public void onAlwaysTick() {
        if (mc.world == null) {
            pops.clear();
            queue.clear();
        }
    }

    @Override
    public void onDisable() {
        queue.clear();
    }

    @Override
    public void onTick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.getNetworkHandler() == null) return;
        String m = queue.pollFirst();
        if (m == null) return;
        if (m.startsWith("/")) mc.getNetworkHandler().sendChatCommand(m.substring(1));
        else mc.getNetworkHandler().sendChatMessage(m);
        cooldown = (int) delay.value;
    }
}
