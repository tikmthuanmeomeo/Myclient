package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.block.BedBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Chi chat khi nguoi choi MA MINH VUA DANH bi be totem: "<Message> <so lan>" (ez pop 1, ez pop 2, ...).
 * Nguoi bi ai khac danh be totem thi khong chat. So lan duoc dem rieng tung nguoi (chi dem lan minh danh),
 * reset khi ho chet.
 */
public class TotemPops extends Module {
    public final Setting.Text message = add(new Setting.Text("Message", "ez pop", 64));
    public final Setting.Bool addName = add(new Setting.Bool("Add name", false));
    public final Setting.Num window = add(new Setting.Num("Damage window (sec)", 3, 1, 10, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 10, 0, 100, 5));
    public final Setting.Bool debug = add(new Setting.Bool("Debug", false));

    private final Map<UUID, Integer> pops = new HashMap<>();
    private final Map<UUID, Long> lastHit = new HashMap<>();
    private final List<Vec3d> crystalPos = new ArrayList<>();
    private final List<Long> crystalTick = new ArrayList<>();
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private int cooldown;
    private long tickCounter;

    public TotemPops() {
        super("TotemPops", Category.COMBAT);
    }

    /** Goi tu mixin khi minh danh 1 entity. */
    public void onAttack(Entity target) {
        if (target instanceof PlayerEntity p && p != mc.player) {
            lastHit.put(p.getUuid(), tickCounter);
        } else if (target instanceof EndCrystalEntity) {
            // minh dap crystal: nguoi dung gan crystal luc no no se bi tinh la do minh
            addBlast(target.getPos());
        }
    }

    /** Goi tu mixin khi minh bam vao 1 block: anchor / giuong co the no do minh. */
    public void onUseBlock(BlockPos pos) {
        if (mc.world == null) return;
        var b = mc.world.getBlockState(pos).getBlock();
        if (b instanceof RespawnAnchorBlock || b instanceof BedBlock) {
            addBlast(Vec3d.ofCenter(pos));
        }
    }

    private void addBlast(Vec3d pos) {
        crystalPos.add(pos);
        crystalTick.add(tickCounter);
        while (crystalPos.size() > 8) {
            crystalPos.remove(0);
            crystalTick.remove(0);
        }
    }

    /** Goi tu mixin: status 35 = be totem, 3 = chet. */
    public void onStatus(Entity e, int status) {
        if (!(e instanceof PlayerEntity p) || p == mc.player) return;
        if (status == 3) {
            pops.remove(p.getUuid());
            lastHit.remove(p.getUuid());
            return;
        }
        if (status != 35) return;
        if (!isEnabled()) return;

        // Chi tinh khi minh vua danh nguoi nay
        Long t = lastHit.get(p.getUuid());
        boolean mine = t != null && tickCounter - t <= (long) (window.value * 20);
        if (debug.value && mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[TotemPops] " + p.getName().getString()
                    + " vo totem - " + (mine ? "minh danh -> chat" : "khong phai minh danh -> bo qua")));
        }
        if (!mine) return;

        int n = pops.merge(p.getUuid(), 1, Integer::sum);

        String base = message.value.trim();
        if (base.isEmpty()) return;
        String msg = base + (addName.value ? " " + p.getName().getString() : "") + " " + n;
        queue.addLast(msg);
        while (queue.size() > 5) queue.pollFirst();
    }

    private boolean hitRecently(PlayerEntity p) {
        long win = (long) (window.value * 20);
        Long t = lastHit.get(p.getUuid());
        if (t != null && tickCounter - t <= win) return true;
        Vec3d pp = p.getPos();
        for (int i = 0; i < crystalPos.size(); i++) {
            if (tickCounter - crystalTick.get(i) <= win && crystalPos.get(i).squaredDistanceTo(pp) <= 12 * 12) return true;
        }
        // ten / tnt do minh ban hoac dot ngay gan nguoi do
        if (mc.world != null) {
            for (Entity e : mc.world.getEntities()) {
                if (e.squaredDistanceTo(p) > 12 * 12) continue;
                if (e instanceof ProjectileEntity pr && pr.getOwner() == mc.player) return true;
                if (e instanceof TntEntity t && t.getOwner() == mc.player) return true;
            }
        }
        return false;
    }

    @Override
    public void onAlwaysTick() {
        tickCounter++;
        if (mc.world == null || mc.player == null) {
            pops.clear();
            lastHit.clear();
            queue.clear();
            return;
        }
        // Du phong: dang giu nut danh va tam ngam dang chi vao 1 nguoi choi
        if (mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof EntityHitResult ehr) {
            onAttack(ehr.getEntity());
        }
    }

    @Override
    public void onDisable() {
        queue.clear();
    }

    @Override
    public void onTick() {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.getNetworkHandler() == null) return;
        String m = queue.pollFirst();
        if (m == null) return;
        if (m.startsWith("/")) mc.getNetworkHandler().sendChatCommand(m.substring(1));
        else mc.getNetworkHandler().sendChatMessage(m);
        cooldown = (int) delay.value;
    }
}
