package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;

/** Khong bi day lui (knockback). Logic nam trong ClientPlayNetworkHandlerMixin. */
public class NoPush extends Module {
    public final Setting.Bool explosion = add(new Setting.Bool("Crystal/Explosion", true));
    public final Setting.Bool velocity = add(new Setting.Bool("Hit/Velocity", true));

    public NoPush() {
        super("NoPush", Category.MOVEMENT);
    }
}
