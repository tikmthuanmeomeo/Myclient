package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import com.myclient.util.BoxRender;
import com.myclient.util.CrystalUtil;
import com.myclient.util.Util;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.List;

/**
 * AutoCrystal port tu AlienClient (ban rut gon): tu dat va danh end crystal len ke dich.
 * Bo: BasePlace, du doan chuyen dong, thread tinh toan, YawStep.
 */
public class AutoCrystal extends Module {
    // --- Check
    public final Setting.KeyBind pause = add(new Setting.KeyBind("Pause", -1));
    public final Setting.Bool onlyHold = add(new Setting.Bool("OnlyHold", true));
    public final Setting.Bool eatingPause = add(new Setting.Bool("EatingPause", true));
    public final Setting.Num switchPause = add(new Setting.Num("SwitchPause", 100, 0, 1000, 10));
    public final Setting.Num targetRange = add(new Setting.Num("TargetRange", 12, 0, 20, 1));
    public final Setting.Num updateDelay = add(new Setting.Num("UpdateDelay", 50, 0, 1000, 10));
    // --- Rotate
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));
    public final Setting.Bool onPlace = add(new Setting.Bool("OnPlace", false));
    public final Setting.Bool onBreak = add(new Setting.Bool("OnBreak", false));
    // --- Damage
    public final Setting.Num minDamage = add(new Setting.Num("Min", 5, 0, 36, 0.5));
    public final Setting.Num maxSelf = add(new Setting.Num("Max", 12, 0, 36, 0.5));
    public final Setting.Num reserve = add(new Setting.Num("Reserve", 2, 0, 10, 0.5));
    public final Setting.Bool balance = add(new Setting.Bool("Balance", true));
    public final Setting.Num balanceOffset = add(new Setting.Num("BalanceOffset", 0, -20, 20, 0.5));
    // --- Place
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Num placeRange = add(new Setting.Num("PlaceRange", 5, 0, 6, 0.1));
    public final Setting.Num placeDelay = add(new Setting.Num("PlaceDelay", 300, 0, 1000, 10));
    public final Setting.Mode autoSwap = add(new Setting.Mode("AutoSwap", "None", "None", "Normal", "Silent", "Inventory"));
    public final Setting.Bool afterBreak = add(new Setting.Bool("AfterBreak", true));
    public final Setting.Bool forcePlace = add(new Setting.Bool("ForcePlace", false));
    // --- Break
    public final Setting.Bool breakCrystal = add(new Setting.Bool("Break", true));
    public final Setting.Num breakRange = add(new Setting.Num("BreakRange", 4, 0, 6, 0.1));
    public final Setting.Num breakDelay = add(new Setting.Num("BreakDelay", 300, 0, 1000, 10));
    public final Setting.Num minAge = add(new Setting.Num("MinAge", 0, 0, 20, 1));
    public final Setting.Bool resetAttack = add(new Setting.Bool("ResetAttack", true));
    public final Setting.Num wallRange = add(new Setting.Num("WallRange", 6, 0, 6, 0.1));
    // --- Misc
    public final Setting.Bool slowPlace = add(new Setting.Bool("Timeout", true));
    public final Setting.Num slowDelay = add(new Setting.Num("TimeoutDelay", 600, 0, 2000, 50));
    public final Setting.Num slowMinDamage = add(new Setting.Num("TimeoutMin", 1.5, 0, 36, 0.5));
    public final Setting.Bool lethalOverride = add(new Setting.Bool("LethalOverride", true));
    public final Setting.Num forceMaxHealth = add(new Setting.Num("LowerThan", 7, 0, 36, 0.5));
    public final Setting.Num forceMin = add(new Setting.Num("ForceMin", 1.5, 0, 36, 0.5));
    public final Setting.Bool armorBreaker = add(new Setting.Bool("ArmorBreaker", true));
    public final Setting.Num maxDurable = add(new Setting.Num("MaxDurable", 8, 0, 100, 1));
    public final Setting.Num breakerMin = add(new Setting.Num("BreakerMin", 3, 0, 36, 0.5));
    public final Setting.Num hurtTime = add(new Setting.Num("HurtTime", 10, 0, 10, 1));
    public final Setting.Num waitHurt = add(new Setting.Num("WaitHurt", 10, 0, 10, 1));
    public final Setting.Num syncTimeout = add(new Setting.Num("WaitTimeOut", 500, 0, 2000, 10));
    // --- Render
    public final Setting.Group render = add(new Setting.Group("Render", true, true));
    public final Setting.Color fill = render.add(new Setting.Color("Fill", 0x554D6BFF));
    public final Setting.Color outline = render.add(new Setting.Color("Outline", 0xFF4D6BFF));
    public final Setting.Num lineWidth = render.add(new Setting.Num("LineWidth", 1.0, 0.5, 5, 0.5));
    public final Setting.Num fadeTime = render.add(new Setting.Num("FadeTime", 0.5, 0.1, 3, 0.1));

    public BlockPos crystalPos;
    public EndCrystalEntity breakTarget;
    public PlayerEntity displayTarget;
    public float lastDamage;

    private long calcTime, placeTime, breakTime, switchTime, noPosTime, syncTime, lastBreakTime;
    private int lastSlot = -1;
    private BlockPos renderPos;
    private long renderTime;

    public AutoCrystal() {
        super("AutoCrystal", Category.COMBAT);
    }

    private static long now() { return System.currentTimeMillis(); }

    @Override
    public void onEnable() {
        crystalPos = null;
        breakTarget = null;
        displayTarget = null;
        syncTime = now();
        lastBreakTime = now();
    }

    @Override
    public void onDisable() {
        crystalPos = null;
        breakTarget = null;
    }

    // ------------------------------------------------------------ tick
    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        int sel = mc.player.getInventory().selectedSlot;
        if (sel != lastSlot) {
            lastSlot = sel;
            switchTime = now();
        }
        if (now() - calcTime >= updateDelay.value) {
            calcTime = now();
            calc();
        }
        if (shouldReturn()) return;
        if (crystalPos != null) doCrystal(crystalPos);
        if (breakTarget != null) {
            doBreak(breakTarget);
            breakTarget = null;
        }
    }

    private boolean shouldReturn() {
        if (eatingPause.value && mc.player.isUsingItem()) {
            lastBreakTime = now();
            return true;
        }
        if (pause.key > 0 && Util.isKeyDown(pause.key) && mc.currentScreen == null) {
            lastBreakTime = now();
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------ chon vi tri
    private boolean holdingCrystal() {
        return mc.player.getMainHandStack().isOf(Items.END_CRYSTAL) || mc.player.getOffHandStack().isOf(Items.END_CRYSTAL);
    }

    private int crystalSlot() {
        if (autoSwap.is("Inventory")) return Util.findInvSlot(Items.END_CRYSTAL);
        return Util.findHotbar(Items.END_CRYSTAL);
    }

    private boolean hasCrystal() {
        return !autoSwap.is("None") && crystalSlot() != -1;
    }

    private void calc() {
        crystalPos = null;
        breakTarget = null;
        if (onlyHold.value && !holdingCrystal() && !hasCrystal()) {
            lastBreakTime = now();
            return;
        }
        List<PlayerEntity> targets = new java.util.ArrayList<>();
        for (PlayerEntity p : CrystalUtil.enemies(targetRange.value)) {
            if (p.hurtTime <= hurtTime.value) targets.add(p);
        }
        if (targets.isEmpty()) {
            lastBreakTime = now();
            return;
        }
        float myHealth = mc.player.getHealth() + mc.player.getAbsorptionAmount();

        // 1) crystal dang co san -> danh
        float breakDamage = 0;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            if (c.age < minAge.value) continue;
            Vec3d atk = attackVec(c.getPos());
            if (atk == null) continue;
            if (!mc.player.canSee(c) && mc.player.getEyePos().distanceTo(atk) > wallRange.value) continue;
            float self = CrystalUtil.damage(c.getPos(), mc.player);
            for (PlayerEntity t : targets) {
                float dmg = CrystalUtil.damage(c.getPos(), t);
                if (dmg <= breakDamage) continue;
                if (self > maxSelf.value) continue;
                if (reserve.value > 0 && self > myHealth - reserve.value) continue;
                if (dmg < CrystalUtil.health(t)) {
                    if (dmg < neededDamage(t)) continue;
                    if (balance.value && !balanceOk(t, dmg, self)) continue;
                }
                breakDamage = dmg;
                breakTarget = c;
                displayTarget = t;
            }
        }

        // 2) vi tri dat moi
        float best = 0;
        BlockPos base = mc.player.getBlockPos();
        int r = (int) Math.ceil(breakRange.value + 1.5);
        double rr = (breakRange.value + 1.5) * (breakRange.value + 1.5);
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    if (x * x + y * y + z * z > rr) continue;
                    BlockPos pos = base.add(x, y, z);
                    // dieu kien re truoc: co obsidian/bedrock duoi chan va o trong
                    if (!CrystalUtil.canPlaceCrystal(pos, true)) continue;
                    Vec3d atk = attackVec(new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5));
                    if (atk == null) continue;
                    if (behindWall(pos, atk)) continue;
                    if (!canTouch(pos.down())) continue;
                    float self = CrystalUtil.damage(pos, mc.player);
                    for (PlayerEntity t : targets) {
                        float dmg = CrystalUtil.damage(pos, t);
                        if (dmg <= best) continue;
                        if (self > maxSelf.value) continue;
                        if (reserve.value > 0 && self > myHealth - reserve.value) continue;
                        if (dmg < CrystalUtil.health(t)) {
                            if (dmg < neededDamage(t)) continue;
                            if (balance.value && !balanceOk(t, dmg, self)) continue;
                        }
                        displayTarget = t;
                        crystalPos = pos;
                        best = dmg;
                    }
                }
            }
        }
        lastDamage = best;
    }

    private boolean balanceOk(PlayerEntity t, float dmg, float self) {
        if (neededDamage(t) == forceMin.value) return dmg >= self - 2.5;
        return dmg >= self + balanceOffset.value;
    }

    /** Sat thuong toi thieu can co de dat/danh (ha thap khi dich yeu, giap sap vo, hoac lau khong danh). */
    private double neededDamage(PlayerEntity t) {
        if (slowPlace.value && now() - lastBreakTime >= slowDelay.value) return slowMinDamage.value;
        if (lethalOverride.value && CrystalUtil.health(t) <= forceMaxHealth.value) return forceMin.value;
        if (armorBreaker.value) {
            for (ItemStack a : t.getArmorItems()) {
                if (a.isEmpty()) continue;
                int pct = a.getDamage() == a.getMaxDamage() ? 100
                        : (int) ((a.getMaxDamage() - a.getDamage()) / Math.max(0.1, a.getMaxDamage()) * 100.0);
                if (pct > maxDurable.value) continue;
                return breakerMin.value;
            }
        }
        return minDamage.value;
    }

    /** Diem gan nhat tren hop crystal (cao 2) trong tam danh, null neu qua xa. */
    private Vec3d attackVec(Vec3d feet) {
        Box box = new Box(feet.x - 1, feet.y, feet.z - 1, feet.x + 1, feet.y + 2, feet.z + 1);
        Vec3d eye = mc.player.getEyePos();
        Vec3d p = new Vec3d(
                Math.max(box.minX, Math.min(box.maxX, eye.x)),
                Math.max(box.minY, Math.min(box.maxY, eye.y)),
                Math.max(box.minZ, Math.min(box.maxZ, eye.z)));
        return eye.distanceTo(p) <= breakRange.value ? p : null;
    }

    private boolean behindWall(BlockPos pos, Vec3d atk) {
        Vec3d crystalEye = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.7, pos.getZ() + 0.5);
        HitResult res = mc.world.raycast(new RaycastContext(mc.player.getEyePos(), crystalEye,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        if (res == null || res.getType() == HitResult.Type.MISS) return false;
        return mc.player.getEyePos().distanceTo(atk) > wallRange.value;
    }

    private boolean canTouch(BlockPos obs) {
        Direction side = CrystalUtil.clickSide(obs);
        return obs.toCenterPos().add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5)
                .distanceTo(mc.player.getEyePos()) <= placeRange.value;
    }

    // ------------------------------------------------------------ thuc thi
    private void doCrystal(BlockPos pos) {
        if (CrystalUtil.canPlaceCrystal(pos, false)) doPlace(pos, rotate.value && onPlace.value);
        doBreakAt(pos);
    }

    private void doPlace(BlockPos pos, boolean rot) {
        noPosTime = now();
        if (!place.value) return;
        if (!holdingCrystal() && !hasCrystal()) return;
        if (!canTouch(pos.down())) return;
        if (now() - placeTime < placeDelay.value) return;

        if (holdingCrystal()) {
            placeTime = now();
            CrystalUtil.placeCrystal(pos, rot);
        } else {
            int slot = crystalSlot();
            if (slot == -1) return;
            placeTime = now();
            int old = mc.player.getInventory().selectedSlot;
            doSwap(slot);
            CrystalUtil.placeCrystal(pos, rot);
            if (autoSwap.is("Silent")) doSwap(old);
            else if (autoSwap.is("Inventory")) doSwap(slot);
        }
        renderPos = pos;
        renderTime = now();
    }

    private void doSwap(int slot) {
        if (autoSwap.is("Silent") || autoSwap.is("Normal")) Util.switchToSlot(slot);
        else if (autoSwap.is("Inventory")) Util.inventorySwap(slot);
    }

    private boolean waitingHurt() {
        return displayTarget != null && displayTarget.hurtTime > waitHurt.value && now() - syncTime < syncTimeout.value;
    }

    private void doBreak(EndCrystalEntity c) {
        noPosTime = now();
        if (!breakCrystal.value || !c.isAlive()) return;
        if (waitingHurt()) return;
        lastBreakTime = now();
        if (now() - switchTime < switchPause.value) return;
        syncTime = now();
        if (c.age < minAge.value) return;
        if (now() - breakTime < breakDelay.value) {
            if (forcePlace.value && crystalPos != null) doPlace(crystalPos, false);
            return;
        }
        attack(c);
    }

    private void doBreakAt(BlockPos pos) {
        noPosTime = now();
        if (!breakCrystal.value) return;
        if (waitingHurt()) return;
        lastBreakTime = now();
        if (now() - switchTime < switchPause.value) return;
        syncTime = now();
        Box box = new Box(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 2, pos.getZ() + 1);
        for (EndCrystalEntity c : CrystalUtil.crystalsIn(box)) {
            if (c.age < minAge.value || !c.isAlive()) continue;
            if (now() - breakTime < breakDelay.value) {
                if (forcePlace.value && crystalPos != null) doPlace(crystalPos, false);
                return;
            }
            attack(c);
            return;
        }
        if (forcePlace.value && crystalPos != null) doPlace(crystalPos, false);
    }

    private void attack(EndCrystalEntity c) {
        Vec3d atk = attackVec(c.getPos());
        if (atk == null) return;
        if (rotate.value && onBreak.value) Util.lookAt(atk);
        breakTime = now();
        mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(c, mc.player.isSneaking()));
        if (resetAttack.value) mc.player.resetLastAttackedTicks();
        mc.player.swingHand(Hand.MAIN_HAND);
        if (rotate.value && onBreak.value) Util.snapBack();

        BlockPos cp = crystalPos;
        if (cp != null && displayTarget != null && lastDamage >= neededDamage(displayTarget) && afterBreak.value) {
            doPlace(cp, false);
        }
    }

    // ------------------------------------------------------------ ve
    public void renderWorld(WorldRenderContext ctx) {
        if (!isEnabled() || !render.enabled || renderPos == null) return;
        double age = (now() - renderTime) / (fadeTime.value * 1000.0);
        if (age >= 1.0) return;
        BoxRender.draw(ctx, new Box(renderPos), fill.argb(), outline.argb(), (float) lineWidth.value, (float) (1.0 - age));
    }
}
