package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import com.myclient.util.Util;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PickFromInventoryC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

import java.util.HashMap;
import java.util.Map;

/** AutoArmor port tu AlienClient: tu mac giap tot nhat (uu tien Protection hoac Blast) va elytra. */
public class AutoArmor extends Module {
    public final Setting.Mode head = add(new Setting.Mode("Head", "Protection", "Protection", "Blast"));
    public final Setting.Mode body = add(new Setting.Mode("Body", "Protection", "Protection", "Blast"));
    public final Setting.Mode tights = add(new Setting.Mode("Tights", "Protection", "Protection", "Blast"));
    public final Setting.Mode feet = add(new Setting.Mode("Feet", "Protection", "Protection", "Blast"));
    public final Setting.Bool ignoreCurse = add(new Setting.Bool("IgnoreCurse", true));
    public final Setting.Bool noMove = add(new Setting.Bool("NoMove", false));
    public final Setting.Num delay = add(new Setting.Num("Delay", 3, 0, 10, 1));
    public final Setting.Bool autoElytra = add(new Setting.Bool("AutoElytra", true));
    public final Setting.Mode hotbarSwap = add(new Setting.Mode("HotbarSwap", "Swap", "Swap", "Switch"));
    public final Setting.Mode inventorySwap = add(new Setting.Mode("InventorySwap", "ClickSlot", "ClickSlot", "Pick"));

    private int tickDelay;

    public AutoArmor() {
        super("AutoArmor", Category.PLAYER);
    }

    private boolean elytraFlyOn() {
        ElytraFly e = ModuleManager.get(ElytraFly.class);
        return e != null && e.isEnabled();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (!Util.inInventory()) return;
        if (mc.player.playerScreenHandler != mc.player.currentScreenHandler) return;
        if (Util.isMoving() && noMove.value) return;
        if (tickDelay > 0) {
            tickDelay--;
            return;
        }
        tickDelay = (int) delay.value;

        var inv = mc.player.getInventory();
        // {slot trong inventory, bao ve hien tai, slot tot nhat tim duoc, bao ve cua slot do}
        Map<EquipmentSlot, int[]> armorMap = new HashMap<>(4);
        armorMap.put(EquipmentSlot.FEET, new int[]{36, getProtection(inv.getStack(36)), -1, -1});
        armorMap.put(EquipmentSlot.LEGS, new int[]{37, getProtection(inv.getStack(37)), -1, -1});
        armorMap.put(EquipmentSlot.CHEST, new int[]{38, getProtection(inv.getStack(38)), -1, -1});
        armorMap.put(EquipmentSlot.HEAD, new int[]{39, getProtection(inv.getStack(39)), -1, -1});

        for (int s = 0; s < 36; s++) {
            ItemStack st = inv.getStack(s);
            if (!(st.getItem() instanceof ArmorItem) && st.getItem() != Items.ELYTRA) continue;
            if (st.getItem() == Items.ELYTRA && !elytraFlyOn() && autoElytra.value) continue;
            int protection = getProtection(st);
            EquipmentSlot slot = st.getItem() instanceof ElytraItem ? EquipmentSlot.CHEST : ((ArmorItem) st.getItem()).getSlotType();
            for (Map.Entry<EquipmentSlot, int[]> e : armorMap.entrySet()) {
                if (autoElytra.value && elytraFlyOn() && e.getKey() == EquipmentSlot.CHEST) {
                    ItemStack chest = inv.getStack(38);
                    if (!chest.isEmpty() && chest.getItem() instanceof ElytraItem && ElytraItem.isUsable(chest)) continue;
                    int cur = e.getValue()[2];
                    if (cur != -1 && !inv.getStack(cur).isEmpty() && inv.getStack(cur).getItem() instanceof ElytraItem
                            && ElytraItem.isUsable(inv.getStack(cur))) continue;
                    if (st.getItem() instanceof ElytraItem && ElytraItem.isUsable(st)) e.getValue()[2] = s;
                    continue;
                }
                if (protection > 0 && e.getKey() == slot) {
                    if (protection > e.getValue()[1] && protection > e.getValue()[3]) {
                        e.getValue()[2] = s;
                        e.getValue()[3] = protection;
                    }
                }
            }
        }

        for (Map.Entry<EquipmentSlot, int[]> en : armorMap.entrySet()) {
            int[] v = en.getValue();
            if (v[2] == -1) continue;
            int armorSlot = 44 - v[0];
            if (v[2] < 9) {
                if (hotbarSwap.is("Swap")) {
                    mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, armorSlot, v[2], SlotActionType.SWAP, mc.player);
                } else {
                    int old = inv.selectedSlot;
                    Util.switchToSlot(v[2]);
                    Util.sendSequenced(id -> new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, id, mc.player.getYaw(), mc.player.getPitch()));
                    Util.switchToSlot(old);
                }
            } else if (mc.player.playerScreenHandler == mc.player.currentScreenHandler) {
                int newSlot = v[2];
                if (inventorySwap.is("Pick")) {
                    mc.getNetworkHandler().sendPacket(new PickFromInventoryC2SPacket(newSlot));
                    Util.sendSequenced(id -> new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, id, mc.player.getYaw(), mc.player.getPitch()));
                    mc.getNetworkHandler().sendPacket(new PickFromInventoryC2SPacket(newSlot));
                } else {
                    mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, newSlot, 0, SlotActionType.PICKUP, mc.player);
                    mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, armorSlot, 0, SlotActionType.PICKUP, mc.player);
                    if (v[1] != -1) {
                        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, newSlot, 0, SlotActionType.PICKUP, mc.player);
                    }
                }
            }
            return; // moi lan chi doi 1 mon
        }
    }

    private Setting.Mode modeFor(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> head;
            case LEGS -> tights;
            case FEET -> feet;
            default -> body;
        };
    }

    private int level(Registry<Enchantment> reg, net.minecraft.registry.RegistryKey<Enchantment> key, ItemStack st) {
        RegistryEntry<Enchantment> entry = reg.getEntry(key).orElse(null);
        return entry == null ? 0 : EnchantmentHelper.getLevel(entry, st);
    }

    /** Diem giap: -1 = o trong, 0 = khong phai giap, &gt;0 = tot hon. */
    private int getProtection(ItemStack is) {
        if (is.isEmpty()) return -1;
        boolean armor = is.getItem() instanceof ArmorItem;
        boolean elytra = is.getItem() == Items.ELYTRA;
        if (!armor && !elytra) return 0;

        int prot = 0;
        EquipmentSlot slot = armor ? ((ArmorItem) is.getItem()).getSlotType() : EquipmentSlot.CHEST;
        if (elytra) {
            if (!ElytraItem.isUsable(is)) return 0;
            prot = 1;
        }
        boolean wantProt = modeFor(slot).is("Protection");
        int protMul = wantProt ? 2 : 1;
        int blastMul = wantProt ? 1 : 2;

        if (is.hasEnchantments()) {
            Registry<Enchantment> reg = mc.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
            prot += level(reg, Enchantments.PROTECTION, is) * protMul;
            prot += level(reg, Enchantments.BLAST_PROTECTION, is) * blastMul;
            if (ignoreCurse.value && level(reg, Enchantments.BINDING_CURSE, is) > 0) prot = -999;
        }
        return (armor ? ((ArmorItem) is.getItem()).getProtection() : 0) + prot;
    }
}
