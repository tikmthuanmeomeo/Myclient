package com.myclient.module.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import com.myclient.gui.Draw;
import com.myclient.gui.Theme;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Hieu ung troi: sao bang bay quanh 360 do (bi che boi dia hinh / tran nha, hoat dong o moi dimension)
 * va hat bay bay quanh nguoi choi. Chinh so luong / toc do / tam xa.
 */
public class Particles extends Module {
    public final Setting.Num meteors = add(new Setting.Num("Meteors", 24, 0, 100, 1));
    public final Setting.Num meteorSpeed = add(new Setting.Num("Meteor speed", 1.0, 0.5, 3.0, 0.1));
    public final Setting.Num floating = add(new Setting.Num("Floating", 25, 0, 100, 5));
    public final Setting.Num floatRange = add(new Setting.Num("Floating range", 20, 8, 32, 2));

    private static class Meteor {
        final Vector3f d0 = new Vector3f();
        final Vector3f t = new Vector3f();
        double born, life, omega;
    }

    private final List<Meteor> list = new ArrayList<>();
    private final Random rng = new Random();
    private final Vector3f wd = new Vector3f();
    private final Vector3f tmpV = new Vector3f();
    private final Vector4f tmpC = new Vector4f();
    private final int[] seg = new int[4];
    private Quaternionf invRot;
    private Matrix4f proj;
    private Vec3d camPos = Vec3d.ZERO;
    private boolean haveView;
    private double partAcc;

    public Particles() {
        super("Particles", Category.RENDER);
    }

    @Override
    public void onDisable() {
        list.clear();
        haveView = false;
    }

    // ------------------------------------------------------------------ hat bay bay (hat that trong the gioi)
    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        int per = (int) floating.value;
        if (per <= 0) return;

        partAcc += per / 20.0;
        int n = 0;
        while (partAcc >= 1.0 && n < 12) {
            partAcc -= 1.0;
            n++;
            spawnParticle();
        }
        if (partAcc > 2.0) partAcc = 0;
    }

    private void spawnParticle() {
        double range = floatRange.value;
        double ang = rng.nextDouble() * Math.PI * 2;
        double r = 3 + rng.nextDouble() * Math.max(1, range - 3);
        double x = mc.player.getX() + Math.cos(ang) * r;
        double z = mc.player.getZ() + Math.sin(ang) * r;
        double y = mc.player.getY() + rng.nextDouble() * 10 - 2;
        if (!mc.world.getBlockState(BlockPos.ofFloored(x, y, z)).isAir()) return;
        mc.world.addParticle(ParticleTypes.END_ROD, x, y, z,
                (rng.nextDouble() - 0.5) * 0.08,
                (rng.nextDouble() - 0.5) * 0.05,
                (rng.nextDouble() - 0.5) * 0.08);
    }

    // ------------------------------------------------------------------ sao bang
    /** Goi luc render the gioi: luu huong camera + projection de chieu sao bang len man hinh. */
    public void collect(WorldRenderContext ctx) {
        if (!isEnabled() || mc.world == null) {
            haveView = false;
            return;
        }
        invRot = new Quaternionf(ctx.camera().getRotation()).conjugate();
        proj = new Matrix4f(RenderSystem.getProjectionMatrix());
        camPos = ctx.camera().getPos();
        haveView = true;
    }

    private void respawn(Meteor m, double now, boolean stagger) {
        // 360 do quanh nguoi choi
        double yr = rng.nextDouble() * Math.PI * 2;
        double el = Math.toRadians(8 + rng.nextFloat() * 62);
        m.d0.set((float) (-Math.sin(yr) * Math.cos(el)), (float) Math.sin(el), (float) (Math.cos(yr) * Math.cos(el)));

        // Tiep tuyen ngau nhien tai d0, luon huong xuong
        Vector3f rv = new Vector3f();
        for (int tries = 0; tries < 6; tries++) {
            rv.set(rng.nextFloat() - 0.5f, rng.nextFloat() - 0.5f, rng.nextFloat() - 0.5f);
            float dot = rv.dot(m.d0);
            m.t.set(rv.x - m.d0.x * dot, rv.y - m.d0.y * dot, rv.z - m.d0.z * dot);
            if (m.t.lengthSquared() > 1.0e-3f) break;
        }
        if (m.t.lengthSquared() < 1.0e-6f) m.t.set(0f, -1f, 0f);
        m.t.normalize();
        if (m.t.y > 0f) m.t.negate();

        m.omega = (0.18 + rng.nextFloat() * 0.25) * meteorSpeed.value;
        m.life = 1.4 + rng.nextFloat() * 1.6;
        m.born = now - (stagger ? rng.nextDouble() * m.life : 0.0);
    }

    /** Tia ngam tu camera theo huong d: true neu bi block che (dia hinh, tran nha, la cay...). */
    private boolean blocked(Vector3f d, double dist) {
        Vec3d end = camPos.add(d.x * dist, d.y * dist, d.z * dist);
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                camPos, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK;
    }

    /** Ve sao bang len HUD (duoi cac phan HUD khac). */
    public void drawHud(DrawContext ctx) {
        if (!haveView || invRot == null || proj == null) return;
        if (mc.player == null || mc.world == null) return;
        int target = (int) meteors.value;
        if (target <= 0) {
            list.clear();
            return;
        }
        if (mc.player.isSubmergedInWater()) return;

        double now = System.nanoTime() / 1.0e9;
        while (list.size() > target) list.remove(list.size() - 1);
        while (list.size() < target) {
            Meteor m = new Meteor();
            respawn(m, now, true);
            list.add(m);
        }

        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        final int n = 28;
        final double trail = 0.14;
        final double rayDist = Math.min(192.0, mc.options.getViewDistance().getValue() * 16.0);

        for (Meteor m : list) {
            double age = (now - m.born) / m.life;
            if (age >= 1.0) {
                respawn(m, now, false);
                continue;
            }
            if (age < 0) continue;
            float env = (float) Math.pow(Math.sin(Math.PI * age), 0.7);
            double a = m.omega * (now - m.born);
            seg[0] = seg[1] = seg[2] = seg[3] = 0;

            for (int j = 0; j < n; j++) {
                double aj = a - j * (trail / n);
                if (aj < 0) break;
                double ca = Math.cos(aj);
                double sa = Math.sin(aj);
                wd.set((float) (m.d0.x * ca + m.t.x * sa),
                        (float) (m.d0.y * ca + m.t.y * sa),
                        (float) (m.d0.z * ca + m.t.z * sa));

                // Che khuat: thu tia ngam moi 7 diem cua duoi
                int s = Math.min(3, j / 7);
                if (seg[s] == 0) seg[s] = blocked(wd, rayDist) ? 2 : 1;
                if (seg[s] == 2) continue;

                tmpV.set(wd);
                invRot.transform(tmpV);
                tmpC.set(tmpV.x, tmpV.y, tmpV.z, 1f);
                proj.transform(tmpC);
                if (tmpC.w <= 0.05f) continue;
                int px = (int) ((tmpC.x / tmpC.w * 0.5f + 0.5f) * sw);
                int py = (int) ((1f - (tmpC.y / tmpC.w * 0.5f + 0.5f)) * sh);
                float fade = (float) Math.pow(1.0 - (double) j / n, 1.6);
                int al = (int) (0xE8 * fade * env);
                if (al < 4) continue;
                int sz = j < 4 ? 2 : 1;
                ctx.fill(px, py, px + sz, py + sz, Theme.alpha(0xEAF2FF, al));
                if (j == 0) Draw.glow(ctx, px, py, 4, 0xBFD9FF, (int) (0x12 * env));
            }
        }
    }
}
