package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;

/** Tat cac hieu ung render gay vuong. Logic nam trong mixin. */
public class NoRender extends Module {
    public final Setting.Bool fog = add(new Setting.Bool("Fog", true));
    public final Setting.Bool wall = add(new Setting.Bool("In-wall overlay", true));
    public final Setting.Bool fire = add(new Setting.Bool("Fire overlay", true));
    public final Setting.Bool water = add(new Setting.Bool("Water overlay", true));

    public NoRender() {
        super("NoRender", Category.RENDER);
    }
}
