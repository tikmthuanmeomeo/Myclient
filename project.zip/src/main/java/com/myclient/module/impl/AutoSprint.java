package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;

/** Tu dong chay nhanh khi di thang. */
public class AutoSprint extends Module {
    public AutoSprint() {
        super("AutoSprint", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.options == null) return;
        if (mc.options.forwardKey.isPressed()
                && !mc.player.horizontalCollision
                && !mc.player.isSneaking()
                && !mc.player.isUsingItem()
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
