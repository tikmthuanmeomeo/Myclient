package com.myclient.module.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import com.myclient.gui.Draw;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Nametag ve 2D tren HUD (chu ro, mau dong nhat): ten, ping, mau, khoang cach
 * + icon armor / do cam tay. Vi tri tinh bang cach chieu vi tri dau nguoi choi len man hinh.
 */
public class Nametags extends Module {
    public final Setting.Num scale = add(new Setting.Num("Scale", 1.0, 0.5, 3.0, 0.1));
    public final Setting.Bool health = add(new Setting.Bool("Health", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping", true));
    public final Setting.Bool distance = add(new Setting.Bool("Distance", false));
    public final Setting.Bool armor = add(new Setting.Bool("Armor", true));
    public final Setting.Bool held = add(new Setting.Bool("Held items", true));
    public final Setting.Bool self = add(new Setting.Bool("Show self", false));

    private static class Tag {
        PlayerEntity p;
        float x, y;
        double dist;
    }

    private final List<Tag> tags = new ArrayList<>();

    public Nametags() {
        super("Nametags", Category.RENDER);
    }

    @Override
    public void onDisable() {
        tags.clear();
    }

    /** Goi trong luc render the gioi: tinh vi tri tren man hinh cua tung nguoi choi. */
    public void collect(WorldRenderContext ctx) {
        tags.clear();
        if (mc.world == null || mc.player == null) return;

        Camera cam = ctx.camera();
        Vec3d camPos = cam.getPos();
        Quaternionf inv = new Quaternionf(cam.getRotation()).conjugate();
        Matrix4f proj = new Matrix4f(RenderSystem.getProjectionMatrix());
        float td = mc.getRenderTickCounter().getTickDelta(false);
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player && !self.value) continue;
            if (p.isSpectator()) continue;

            Vec3d pos = p.getLerpedPos(td).add(0, p.getHeight() + 0.45, 0);
            Vector3f v = new Vector3f(
                    (float) (pos.x - camPos.x), (float) (pos.y - camPos.y), (float) (pos.z - camPos.z));
            inv.transform(v);
            Vector4f c = new Vector4f(v.x, v.y, v.z, 1.0f);
            proj.transform(c);
            if (c.w <= 0.01f) continue;
            float nx = c.x / c.w;
            float ny = c.y / c.w;
            if (Math.abs(nx) > 1.3f || Math.abs(ny) > 1.3f) continue;

            Tag t = new Tag();
            t.p = p;
            t.x = (nx * 0.5f + 0.5f) * sw;
            t.y = (1.0f - (ny * 0.5f + 0.5f)) * sh;
            t.dist = camPos.distanceTo(pos);
            tags.add(t);
        }
        tags.sort((a, b) -> Double.compare(b.dist, a.dist)); // xa ve truoc, gan de len tren
    }

    /** Goi trong HUD: ve nametag + armor. */
    public void drawHud(DrawContext ctx) {
        if (mc.world == null || tags.isEmpty()) return;
        TextRenderer tr = mc.textRenderer;
        MatrixStack ms = ctx.getMatrices();
        float sc = (float) scale.value;

        for (Tag t : tags) {
            PlayerEntity p = t.p;

            MutableText line = Text.literal(p.getName().getString()).setStyle(Style.EMPTY.withColor(0xFFFFFF));
            if (ping.value && mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (e != null) {
                    int l = e.getLatency();
                    int pc = l <= 80 ? 0x55FF55 : (l <= 150 ? 0xFFFF55 : 0xFF5555);
                    line.append(Text.literal(" " + l + "ms").setStyle(Style.EMPTY.withColor(pc)));
                }
            }
            if (health.value) {
                float hp = p.getHealth() + p.getAbsorptionAmount();
                int hc = hp >= 15 ? 0x55FF55 : (hp >= 8 ? 0xFFFF55 : 0xFF5555);
                line.append(Text.literal(" " + (int) Math.ceil(hp)).setStyle(Style.EMPTY.withColor(hc)));
            }
            if (distance.value) {
                line.append(Text.literal(" " + (int) t.dist + "m").setStyle(Style.EMPTY.withColor(0x55FFFF)));
            }

            int tw = tr.getWidth(line);
            ms.push();
            ms.translate(t.x, t.y, 0);
            ms.scale(sc, sc, 1.0f);

            Draw.rrect(ctx, -tw / 2 - 3, -10, tw + 6, 12, 3, 0xB0000000);
            ctx.drawTextWithShadow(tr, line, -tw / 2, -8, 0xFFFFFFFF);

            List<ItemStack> items = new ArrayList<>();
            if (held.value) items.add(p.getMainHandStack());
            if (armor.value) {
                items.add(p.getEquippedStack(EquipmentSlot.HEAD));
                items.add(p.getEquippedStack(EquipmentSlot.CHEST));
                items.add(p.getEquippedStack(EquipmentSlot.LEGS));
                items.add(p.getEquippedStack(EquipmentSlot.FEET));
            }
            if (held.value) items.add(p.getOffHandStack());
            items.removeIf(ItemStack::isEmpty);

            if (!items.isEmpty()) {
                int ix = -(items.size() * 18 - 2) / 2;
                int iy = -28;
                for (ItemStack s : items) {
                    ctx.drawItem(s, ix, iy);
                    ms.push();
                    ms.translate(0, 0, 200);
                    if (s.isItemBarVisible()) {
                        int bar = s.getItemBarStep();
                        ctx.fill(ix + 2, iy + 13, ix + 15, iy + 15, 0xFF000000);
                        ctx.fill(ix + 2, iy + 13, ix + 2 + bar, iy + 14, 0xFF000000 | s.getItemBarColor());
                    }
                    if (s.getCount() > 1) {
                        String c = String.valueOf(s.getCount());
                        ctx.drawTextWithShadow(tr, c, ix + 17 - tr.getWidth(c), iy + 9, 0xFFFFFFFF);
                    }
                    ms.pop();
                    ix += 18;
                }
            }
            ms.pop();
        }
    }
}
