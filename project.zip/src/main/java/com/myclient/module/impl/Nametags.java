package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Nametag tu ve: nhin xuyen tuong, co mau, mau, ping, khoang cach. */
public class Nametags extends Module {
    public final Setting.Num scale = add(new Setting.Num("Scale", 1.0, 0.5, 3.0, 0.1));
    public final Setting.Bool health = add(new Setting.Bool("Health", true));
    public final Setting.Bool ping = add(new Setting.Bool("Ping", true));
    public final Setting.Bool distance = add(new Setting.Bool("Distance", false));
    public final Setting.Bool self = add(new Setting.Bool("Show self", false));

    public Nametags() {
        super("Nametags", Category.RENDER);
    }

    public void render(WorldRenderContext ctx) {
        if (mc.world == null || mc.player == null) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;

        Camera cam = ctx.camera();
        Vec3d camPos = cam.getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        TextRenderer tr = mc.textRenderer;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player && !self.value) continue;
            if (p.isSpectator()) continue;

            Vec3d pos = p.getLerpedPos(td).add(0, p.getHeight() + 0.55, 0);
            double dist = camPos.distanceTo(pos);

            MutableText t = Text.literal(p.getName().getString()).setStyle(Style.EMPTY.withColor(0xFFFFFF));
            if (ping.value && mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (e != null) {
                    t.append(Text.literal(" " + e.getLatency() + "ms").setStyle(Style.EMPTY.withColor(0xAAAAAA)));
                }
            }
            if (health.value) {
                float hp = p.getHealth() + p.getAbsorptionAmount();
                int col = hp >= 15 ? 0x55FF55 : (hp >= 8 ? 0xFFFF55 : 0xFF5555);
                t.append(Text.literal(" " + (int) Math.ceil(hp)).setStyle(Style.EMPTY.withColor(col)));
            }
            if (distance.value) {
                t.append(Text.literal(" " + (int) dist + "m").setStyle(Style.EMPTY.withColor(0x8888FF)));
            }

            ms.push();
            ms.translate(pos.x - camPos.x, pos.y - camPos.y, pos.z - camPos.z);
            ms.multiply(cam.getRotation());
            float s = (float) (0.025 * Math.max(1.0, dist / 5.0) * scale.value);
            ms.scale(s, -s, s);
            Matrix4f m = ms.peek().getPositionMatrix();
            float w = tr.getWidth(t);
            tr.draw(t, -w / 2f, 0, 0xFFFFFFFF, false, m, vcp,
                    TextRenderer.TextLayerType.SEE_THROUGH, 0x90000000, 0xF000F0);
            ms.pop();
        }
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw();
    }
}
