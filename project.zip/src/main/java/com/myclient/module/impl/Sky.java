package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Chinh mau bau troi (chi phia client, chi o Overworld): mau troi / chan troi,
 * monochrome, rainbow, sao hien ca ban ngay, may nhuom mau. Logic nam trong mixin.
 */
public class Sky extends Module {
    public final Setting.Bool mono = add(new Setting.Bool("Monochrome", true));
    public final Setting.Num hue = add(new Setting.Num("Hue", 250, 0, 360, 5));
    public final Setting.Num sat = add(new Setting.Num("Saturation", 0.7, 0.0, 1.0, 0.05));
    public final Setting.Num bright = add(new Setting.Num("Brightness", 0.3, 0.1, 1.0, 0.05));
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Num rainbowSpeed = add(new Setting.Num("Rainbow speed", 12, 1, 60, 1));
    public final Setting.Bool stars = add(new Setting.Bool("Stars (always)", false));
    public final Setting.Bool clouds = add(new Setting.Bool("Tint clouds", true));

    public Sky() {
        super("Sky", Category.RENDER);
    }

    /** Chi ap dung o Overworld. */
    public boolean isActive() {
        return isEnabled() && mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD;
    }

    private float currentHue() {
        if (rainbow.value) {
            return (float) ((System.currentTimeMillis() / 1000.0 * rainbowSpeed.value) % 360.0);
        }
        return (float) hue.value;
    }

    private boolean grey() {
        return mono.value && !rainbow.value;
    }

    private static Vec3d rgb(int c) {
        return new Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
    }

    /** Mau dinh troi. */
    public Vec3d skyColor() {
        float s = grey() ? 0f : (float) sat.value;
        return rgb(MathHelper.hsvToRgb(currentHue() / 360f, s, (float) bright.value));
    }

    /** Mau chan troi / suong: sang hon dinh troi -> gradient. */
    public Vec3d horizonColor() {
        if (grey()) {
            return rgb(MathHelper.hsvToRgb(0f, 0f, (float) Math.min(1.0, bright.value + 0.22)));
        }
        float h = ((currentHue() - 40f) % 360f + 360f) % 360f;
        return rgb(MathHelper.hsvToRgb(h / 360f, (float) (sat.value * 0.7),
                (float) Math.min(1.0, bright.value + 0.35)));
    }

    /** Mau may. */
    public Vec3d cloudColor() {
        if (grey()) return rgb(MathHelper.hsvToRgb(0f, 0f, 0.75f));
        return rgb(MathHelper.hsvToRgb(((currentHue() + 20f) % 360f) / 360f, (float) (sat.value * 0.35), 1.0f));
    }
}
