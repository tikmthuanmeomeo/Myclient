package com.myclient.module.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import com.myclient.gui.Draw;
import com.myclient.gui.Theme;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Bau troi dep (chi phia client, chi o Overworld):
 *  - mau troi / chan troi (mac dinh xam toi nhu video), rainbow, sao, may nhuom mau
 *  - sao bang bay tren troi (ve len HUD, gan voi huong cua troi) - chinh duoc so luong / toc do
 *  - hat bay bay quanh nguoi choi (END_ROD) - chinh duoc so luong / tam xa
 */
public class Sky extends Module {
    public final Setting.Bool mono = add(new Setting.Bool("Monochrome", true));
    public final Setting.Num hue = add(new Setting.Num("Hue", 250, 0, 360, 5));
    public final Setting.Num sat = add(new Setting.Num("Saturation", 0.7, 0.0, 1.0, 0.05));
    public final Setting.Num bright = add(new Setting.Num("Brightness", 0.3, 0.1, 1.0, 0.05));
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Num rainbowSpeed = add(new Setting.Num("Rainbow speed", 12, 1, 60, 1));
    public final Setting.Bool stars = add(new Setting.Bool("Stars (always)", false));
    public final Setting.Bool clouds = add(new Setting.Bool("Tint clouds", true));
    public final Setting.Num meteors = add(new Setting.Num("Meteors", 10, 0, 40, 1));
    public final Setting.Num meteorSpeed = add(new Setting.Num("Meteor speed", 1.0, 0.5, 3.0, 0.1));
    public final Setting.Num particles = add(new Setting.Num("Particles", 25, 0, 100, 5));
    public final Setting.Num particleRange = add(new Setting.Num("Particle range", 20, 8, 40, 2));

    private static class Meteor {
        final Vector3f d0 = new Vector3f();
        final Vector3f t = new Vector3f();
        double born, life, omega;
    }

    private final List<Meteor> list = new ArrayList<>();
    private final Random rng = new Random();
    private final Vector3f tmpV = new Vector3f();
    private final Vector4f tmpC = new Vector4f();
    private Quaternionf invRot;
    private Matrix4f proj;
    private boolean haveView;
    private double partAcc;

    public Sky() {
        super("Sky", Category.RENDER);
    }

    /** Chi ap dung o Overworld. */
    public boolean isActive() {
        return isEnabled() && mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD;
    }

    @Override
    public void onDisable() {
        list.clear();
        haveView = false;
    }

    // ------------------------------------------------------------------ mau
    private float currentHue() {
        if (rainbow.value) {
            return (float) ((System.currentTimeMillis() / 1000.0 * rainbowSpeed.value) % 360.0);
        }
        return (float) hue.value;
    }

    private boolean grey() {
        return mono.value && !rainbow.value;
    }

    private static Vec3d rgb(int c) {
        return new Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
    }

    /** Mau dinh troi. */
    public Vec3d skyColor() {
        float s = grey() ? 0f : (float) sat.value;
        return rgb(MathHelper.hsvToRgb(currentHue() / 360f, s, (float) bright.value));
    }

    /** Mau chan troi / suong: sang hon dinh troi -> gradient. */
    public Vec3d horizonColor() {
        if (grey()) {
            return rgb(MathHelper.hsvToRgb(0f, 0f, (float) Math.min(1.0, bright.value + 0.22)));
        }
        float h = ((currentHue() - 40f) % 360f + 360f) % 360f;
        return rgb(MathHelper.hsvToRgb(h / 360f, (float) (sat.value * 0.7),
                (float) Math.min(1.0, bright.value + 0.35)));
    }

    /** Mau may. */
    public Vec3d cloudColor() {
        if (grey()) return rgb(MathHelper.hsvToRgb(0f, 0f, 0.75f));
        return rgb(MathHelper.hsvToRgb(((currentHue() + 20f) % 360f) / 360f, (float) (sat.value * 0.35), 1.0f));
    }

    // ------------------------------------------------------------------ hat bay bay (3D that)
    @Override
    public void onTick() {
        if (!isActive() || mc.player == null) return;
        int per = (int) particles.value;
        if (per <= 0 || !mc.world.isSkyVisible(mc.player.getBlockPos())) return;

        partAcc += per / 20.0;
        int n = 0;
        while (partAcc >= 1.0 && n < 12) {
            partAcc -= 1.0;
            n++;
            spawnParticle();
        }
        if (partAcc > 2.0) partAcc = 0;
    }

    private void spawnParticle() {
        double range = particleRange.value;
        double ang = rng.nextDouble() * Math.PI * 2;
        double r = 3 + rng.nextDouble() * Math.max(1, range - 3);
        double x = mc.player.getX() + Math.cos(ang) * r;
        double z = mc.player.getZ() + Math.sin(ang) * r;
        double y = mc.player.getY() + rng.nextDouble() * 12 - 2;
        mc.world.addParticle(ParticleTypes.END_ROD, x, y, z,
                (rng.nextDouble() - 0.5) * 0.08,
                (rng.nextDouble() - 0.5) * 0.05,
                (rng.nextDouble() - 0.5) * 0.08);
    }

    // ------------------------------------------------------------------ sao bang
    /** Goi luc render the gioi: luu huong camera + projection de chieu sao bang len man hinh. */
    public void collect(WorldRenderContext ctx) {
        if (!isActive()) {
            haveView = false;
            return;
        }
        invRot = new Quaternionf(ctx.camera().getRotation()).conjugate();
        proj = new Matrix4f(RenderSystem.getProjectionMatrix());
        haveView = true;
    }

    private void respawn(Meteor m, double now, boolean stagger) {
        float yaw = (mc.player != null ? mc.player.getYaw() : 0f) + (rng.nextFloat() * 140f - 70f);
        double yr = Math.toRadians(yaw);
        double el = Math.toRadians(12 + rng.nextFloat() * 58);
        m.d0.set((float) (-Math.sin(yr) * Math.cos(el)), (float) Math.sin(el), (float) (Math.cos(yr) * Math.cos(el)));

        // Tiep tuyen ngau nhien tai d0, luon huong xuong
        Vector3f rv = new Vector3f();
        for (int tries = 0; tries < 6; tries++) {
            rv.set(rng.nextFloat() - 0.5f, rng.nextFloat() - 0.5f, rng.nextFloat() - 0.5f);
            float dot = rv.dot(m.d0);
            m.t.set(rv.x - m.d0.x * dot, rv.y - m.d0.y * dot, rv.z - m.d0.z * dot);
            if (m.t.lengthSquared() > 1.0e-3f) break;
        }
        if (m.t.lengthSquared() < 1.0e-6f) m.t.set(0f, -1f, 0f);
        m.t.normalize();
        if (m.t.y > 0f) m.t.negate();

        m.omega = (0.18 + rng.nextFloat() * 0.25) * meteorSpeed.value;
        m.life = 1.4 + rng.nextFloat() * 1.6;
        m.born = now - (stagger ? rng.nextDouble() * m.life : 0.0);
    }

    /** Ve sao bang len HUD (duoi cac phan HUD khac). */
    public void drawHud(DrawContext ctx) {
        if (!haveView || invRot == null || proj == null) return;
        if (mc.player == null || mc.world == null) return;
        int target = (int) meteors.value;
        if (target <= 0) {
            list.clear();
            return;
        }
        if (!mc.world.isSkyVisible(mc.player.getBlockPos()) || mc.player.isSubmergedInWater()) return;

        double now = System.nanoTime() / 1.0e9;
        while (list.size() > target) list.remove(list.size() - 1);
        while (list.size() < target) {
            Meteor m = new Meteor();
            respawn(m, now, true);
            list.add(m);
        }

        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        final int n = 28;
        final double trail = 0.14;

        for (Meteor m : list) {
            double age = (now - m.born) / m.life;
            if (age >= 1.0) {
                respawn(m, now, false);
                continue;
            }
            if (age < 0) continue;
            float env = (float) Math.pow(Math.sin(Math.PI * age), 0.7);
            double a = m.omega * (now - m.born);

            for (int j = 0; j < n; j++) {
                double aj = a - j * (trail / n);
                if (aj < 0) break;
                double ca = Math.cos(aj);
                double sa = Math.sin(aj);
                tmpV.set((float) (m.d0.x * ca + m.t.x * sa),
                        (float) (m.d0.y * ca + m.t.y * sa),
                        (float) (m.d0.z * ca + m.t.z * sa));
                invRot.transform(tmpV);
                tmpC.set(tmpV.x, tmpV.y, tmpV.z, 1f);
                proj.transform(tmpC);
                if (tmpC.w <= 0.05f) continue;
                int px = (int) ((tmpC.x / tmpC.w * 0.5f + 0.5f) * sw);
                int py = (int) ((1f - (tmpC.y / tmpC.w * 0.5f + 0.5f)) * sh);
                float fade = (float) Math.pow(1.0 - (double) j / n, 1.6);
                int al = (int) (0xE8 * fade * env);
                if (al < 4) continue;
                int sz = j < 4 ? 2 : 1;
                ctx.fill(px, py, px + sz, py + sz, Theme.alpha(0xEAF2FF, al));
                if (j == 0) Draw.glow(ctx, px, py, 4, 0xBFD9FF, (int) (0x12 * env));
            }
        }
    }
}
