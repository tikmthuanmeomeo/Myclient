package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.Setting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Bau troi dep (chi phia client): mau troi + mau chan troi gradient, rainbow,
 * sao hien ca ban ngay, may nhuom mau. Logic nam trong mixin.
 */
public class Sky extends Module {
    public final Setting.Num hue = add(new Setting.Num("Hue", 250, 0, 360, 5));
    public final Setting.Num sat = add(new Setting.Num("Saturation", 0.7, 0.0, 1.0, 0.05));
    public final Setting.Num bright = add(new Setting.Num("Brightness", 0.5, 0.1, 1.0, 0.05));
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Num rainbowSpeed = add(new Setting.Num("Rainbow speed", 12, 1, 60, 1));
    public final Setting.Bool stars = add(new Setting.Bool("Stars (always)", true));
    public final Setting.Bool clouds = add(new Setting.Bool("Tint clouds", true));

    public Sky() {
        super("Sky", Category.RENDER);
    }

    /** Chi ap dung o Overworld. */
    public boolean isActive() {
        return isEnabled() && mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD;
    }

    private float currentHue() {
        if (rainbow.value) {
            return (float) ((System.currentTimeMillis() / 1000.0 * rainbowSpeed.value) % 360.0);
        }
        return (float) hue.value;
    }

    private static Vec3d rgb(int c) {
        return new Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
    }

    /** Mau dinh troi. */
    public Vec3d skyColor() {
        return rgb(MathHelper.hsvToRgb(currentHue() / 360f, (float) sat.value, (float) bright.value));
    }

    /** Mau chan troi / suong: lech sang xanh nhat va sang hon -> gradient dep. */
    public Vec3d horizonColor() {
        float h = ((currentHue() - 40f) % 360f + 360f) % 360f;
        return rgb(MathHelper.hsvToRgb(h / 360f, (float) (sat.value * 0.7),
                (float) Math.min(1.0, bright.value + 0.35)));
    }

    /** Mau may pastel. */
    public Vec3d cloudColor() {
        return rgb(MathHelper.hsvToRgb(((currentHue() + 20f) % 360f) / 360f, (float) (sat.value * 0.35), 1.0f));
    }
}
