package com.myclient.module.impl;

import com.myclient.module.Category;
import com.myclient.module.Setting;
import com.myclient.util.Util;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/** Surround port tu AlienClient: dat obsidian bao quanh chan. */
public class Surround extends PlaceBase {
    public final Setting.Bool onlySelf = add(new Setting.Bool("OnlySelf", false));

    public Surround() {
        super("Surround", Category.COMBAT);
    }

    @Override
    protected boolean shouldExtend(BlockPos pos) {
        return Util.selfIntersect(pos) || (!onlySelf.value && otherIntersect(pos));
    }

    private boolean otherIntersect(BlockPos pos) {
        Box box = new Box(pos);
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (p.getBoundingBox().intersects(box)) return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        if (!preTick()) return;
        doSurround(BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        doSurround(BlockPos.ofFloored(mc.player.getX(), mc.player.getY() + 0.8, mc.player.getZ()));
    }
}
