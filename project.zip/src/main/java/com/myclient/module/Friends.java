package com.myclient.module;

import com.myclient.config.Config;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Danh sach ban be (quan ly bang lenh #friend add / remove / list).
 * Ban be khong bi: AntiRekit dap shulker, CrystalAura no crystal gan ho, AutoRegear tinh la dich.
 */
public final class Friends {
    /** key = ten viet thuong, value = ten goc. */
    private static final Map<String, String> NAMES = new LinkedHashMap<>();

    private Friends() { }

    public static boolean isFriend(String name) {
        if (name == null) return false;
        return NAMES.containsKey(name.toLowerCase(Locale.ROOT));
    }

    public static boolean add(String name) {
        if (name == null || name.isBlank()) return false;
        String n = name.trim();
        if (NAMES.putIfAbsent(n.toLowerCase(Locale.ROOT), n) != null) return false;
        Config.save();
        return true;
    }

    public static boolean remove(String name) {
        if (name == null) return false;
        boolean r = NAMES.remove(name.trim().toLowerCase(Locale.ROOT)) != null;
        if (r) Config.save();
        return r;
    }

    public static List<String> all() {
        return new ArrayList<>(NAMES.values());
    }

    /** Dung khi doc config (khong luu lai). */
    public static void addSilently(String name) {
        if (name == null || name.isBlank()) return;
        NAMES.putIfAbsent(name.trim().toLowerCase(Locale.ROOT), name.trim());
    }
}
