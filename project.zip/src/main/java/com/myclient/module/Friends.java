package com.myclient.module;

import com.myclient.module.impl.AntiRekit;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Danh sach ban be (lay tu o "Friends" cua AntiRekit, cach nhau bang dau phay / khoang trang). */
public final class Friends {
    private static String lastRaw = null;
    private static final Set<String> CACHE = new HashSet<>();

    private static void refresh() {
        AntiRekit ar = ModuleManager.get(AntiRekit.class);
        String raw = ar == null ? "" : ar.friends.value;
        if (raw.equals(lastRaw)) return;
        lastRaw = raw;
        CACHE.clear();
        for (String s : raw.split("[,;\\s]+")) {
            if (!s.isBlank()) CACHE.add(s.toLowerCase(Locale.ROOT));
        }
    }

    public static boolean isFriend(String name) {
        if (name == null) return false;
        refresh();
        return CACHE.contains(name.toLowerCase(Locale.ROOT));
    }

    private Friends() { }
}
