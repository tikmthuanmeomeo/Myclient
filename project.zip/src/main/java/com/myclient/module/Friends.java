package com.myclient.module;

import com.myclient.module.impl.AntiRekit;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Danh sach ban be (lay tu danh sach "Friends" cua AntiRekit). */
public final class Friends {
    private static String lastRaw = null;
    private static final Set<String> CACHE = new HashSet<>();

    private static void refresh() {
        AntiRekit ar = ModuleManager.get(AntiRekit.class);
        String raw = ar == null ? "" : String.join(",", ar.friends.names);
        if (raw.equals(lastRaw)) return;
        lastRaw = raw;
        CACHE.clear();
        if (ar == null) return;
        for (String s : ar.friends.names) {
            if (s != null && !s.isBlank()) CACHE.add(s.trim().toLowerCase(Locale.ROOT));
        }
    }

    public static boolean isFriend(String name) {
        if (name == null) return false;
        refresh();
        return CACHE.contains(name.toLowerCase(Locale.ROOT));
    }

    private Friends() { }
}
