package com.myclient.command;

import com.myclient.module.Friends;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Lenh trong chat bat dau bang '#': khong gui len server.
 *   #friend add <ten>      them ban
 *   #friend remove <ten>   xoa ban
 *   #friend list           xem danh sach ban
 */
public final class Commands {
    private Commands() { }

    /** Tra ve true neu tin nhan la lenh cua client (khong gui len server). */
    public static boolean handle(String msg) {
        if (msg == null) return false;
        String t = msg.trim();
        if (!t.startsWith("#")) return false;

        String[] a = t.substring(1).trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) {
            return false; // chi go "#" -> de chat binh thuong
        }
        String cmd = a[0].toLowerCase();
        if (cmd.equals("friend") || cmd.equals("friends") || cmd.equals("f")) {
            friend(a);
            return true;
        }
        return false; // khong phai lenh cua minh -> gui chat binh thuong
    }

    private static void friend(String[] a) {
        String sub = a.length >= 2 ? a[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> {
                if (a.length < 3) { say("Usage: #friend add <name>", Formatting.RED); return; }
                String name = a[2];
                if (Friends.add(name)) say("Added friend: " + name, Formatting.GREEN);
                else say(name + " is already a friend.", Formatting.YELLOW);
            }
            case "remove", "del", "delete" -> {
                if (a.length < 3) { say("Usage: #friend remove <name>", Formatting.RED); return; }
                String name = a[2];
                if (Friends.remove(name)) say("Removed friend: " + name, Formatting.GREEN);
                else say(name + " is not in your friend list.", Formatting.YELLOW);
            }
            case "list" -> {
                List<String> all = Friends.all();
                if (all.isEmpty()) say("Friend list is empty.", Formatting.YELLOW);
                else say("Friends (" + all.size() + "): " + String.join(", ", all), Formatting.AQUA);
            }
            default -> say("Usage: #friend add <name> | #friend remove <name> | #friend list", Formatting.GRAY);
        }
    }

    private static void say(String s, Formatting color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud == null) return;
        mc.inGameHud.getChatHud().addMessage(Text.literal("[Flux] ").formatted(Formatting.DARK_AQUA)
                .append(Text.literal(s).formatted(color)));
    }
}
