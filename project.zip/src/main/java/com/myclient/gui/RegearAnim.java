package com.myclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Animation do bay tu shulker ve hotbar khi AutoRegear lay do. */
public final class RegearAnim {
    private static final class Fly {
        ItemStack stack;
        float sx, sy, ex, ey, bend;
        long start;
    }

    private static final int DUR = 560;
    private static final int BURST = 380;
    private static final List<Fly> FLIES = new ArrayList<>();
    private static final Random RNG = new Random();

    /** (sx,sy) = diem xuat phat tren man hinh, dest = o hotbar (0-8) hoac -1 neu khong ro. */
    public static void spawn(ItemStack stack, float sx, float sy, int hotbarIdx, int order) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        Fly f = new Fly();
        f.stack = stack.copyWithCount(1);
        f.sx = sx + (RNG.nextFloat() - 0.5f) * 10;
        f.sy = sy + (RNG.nextFloat() - 0.5f) * 10;
        int idx = hotbarIdx >= 0 ? hotbarIdx : 4;
        f.ex = sw / 2f - 80 + 20 * idx;
        f.ey = sh - 11;
        f.bend = (RNG.nextBoolean() ? 1 : -1) * (30 + RNG.nextInt(40));
        f.start = System.currentTimeMillis() + order * 90L;
        FLIES.add(f);
    }

    public static void clear() { FLIES.clear(); }

    private static float ease(float t) { return t * t * (3 - 2 * t); }

    private static float[] pos(Fly f, float t) {
        float e = ease(Math.max(0f, Math.min(1f, t)));
        float cx = (f.sx + f.ex) / 2f + f.bend;
        float cy = Math.min(f.sy, f.ey) - 55;
        float u = 1 - e;
        return new float[]{
                u * u * f.sx + 2 * u * e * cx + e * e * f.ex,
                u * u * f.sy + 2 * u * e * cy + e * e * f.ey};
    }

    public static void render(DrawContext ctx) {
        if (FLIES.isEmpty()) return;
        long now = System.currentTimeMillis();
        FLIES.removeIf(f -> now - f.start > DUR + BURST);
        MatrixStack ms = ctx.getMatrices();

        for (Fly f : FLIES) {
            long age = now - f.start;
            if (age < 0) continue;
            if (age <= DUR) {
                float t = age / (float) DUR;
                // vet sang phia sau
                for (int k = 6; k >= 1; k--) {
                    float[] tp = pos(f, t - k * 0.04f);
                    int a = Math.max(0, 0x70 - k * 0x12);
                    Draw.circle(ctx, (int) tp[0], (int) tp[1], Math.max(1, 5 - k / 2), Theme.alpha(Theme.ACCENT2, a));
                }
                float[] p = pos(f, t);
                float sc = 0.9f + 0.8f * (float) Math.sin(Math.PI * t);
                if (t > 0.85f) sc *= 1f - (t - 0.85f) / 0.15f * 0.5f;
                Draw.glow(ctx, (int) p[0], (int) p[1], 13, 0x22D3EE, 0x14);
                ms.push();
                ms.translate(p[0], p[1], 400);
                ms.scale(sc, sc, 1f);
                ctx.drawItem(f.stack, -8, -8);
                ms.pop();
            } else {
                float q = (age - DUR) / (float) BURST;
                int a = (int) ((1f - q) * 0xC0);
                int cx = (int) f.ex, cy = (int) f.ey;
                // o hotbar sang len
                Draw.outline(ctx, cx - 10, cy - 10, 20, 20, Theme.alpha(Theme.ACCENT2, a));
                // vong tron lan ra
                int r = (int) (5 + 18 * q);
                for (int i = 0; i < 28; i++) {
                    double ang = i * Math.PI * 2 / 28;
                    int px = cx + (int) Math.round(Math.cos(ang) * r);
                    int py = cy + (int) Math.round(Math.sin(ang) * r);
                    ctx.fill(px, py, px + 2, py + 2, Theme.alpha(Theme.ACCENT1, a));
                }
                // tia sang
                for (int i = 0; i < 6; i++) {
                    double ang = i * Math.PI / 3 + 0.4;
                    int px = cx + (int) (Math.cos(ang) * (8 + 22 * q));
                    int py = cy + (int) (Math.sin(ang) * (8 + 22 * q));
                    Draw.sparkle(ctx, px, py, 2, Theme.alpha(0x7DE8FF, a));
                }
            }
        }
    }

    private RegearAnim() { }
}
