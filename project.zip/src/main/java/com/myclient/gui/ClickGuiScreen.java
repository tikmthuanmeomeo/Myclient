package com.myclient.gui;

import com.myclient.MyClient;
import com.myclient.config.Config;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import com.myclient.module.impl.ClickGui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Click GUI dang bang: moi Category la 1 panel dung canh nhau.
 * Click trai = bat/tat module, click phai (hoac nut ...) = mo setting.
 * Keo tieu de panel = di chuyen, bam tieu de = thu gon. Keo cho trong / lan chuot = cuon.
 */
public class ClickGuiScreen extends Screen {
    private static final int HEAD_H = 16;
    private static final int ROW_H = 14;

    private static class Panel {
        Category cat;
        int x, y;
        boolean open = true;
        boolean placed;
    }

    private static class Hit {
        final int x, y, w, h;
        final Runnable left, right;
        final Setting.Num slider;
        final Panel panel; // != null: tieu de panel (keo duoc)

        Hit(int x, int y, int w, int h, Runnable left, Runnable right, Setting.Num slider, Panel panel) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
            this.right = right;
            this.slider = slider;
            this.panel = panel;
        }

        boolean in(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Panel> panels = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private Module expanded;
    private Module listening;     // module dang cho bam phim de gan key
    private Setting.Text editing; // o chu dang nhap

    private double scroll;
    private int contentHeight;

    private Hit pressed;
    private int pressedButton;
    private double pressX, pressY;
    private boolean moved;
    private Hit sliderHit;
    private Panel dragging;

    public ClickGuiScreen() {
        super(Text.literal(MyClient.NAME));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        if (panels.isEmpty()) {
            for (Category c : Category.values()) {
                if (ModuleManager.byCategory(c).isEmpty()) continue;
                Panel p = new Panel();
                p.cat = c;
                panels.add(p);
            }
        }
        int pw = panelWidth();
        int n = panels.size();
        int startX = Math.max(4, (width - (n * pw + (n - 1) * 4)) / 2);
        int i = 0;
        for (Panel p : panels) {
            if (!p.placed) {
                p.x = startX + i * (pw + 4);
                p.y = 12;
                p.placed = true;
            }
            p.x = Math.max(0, Math.min(width - pw, p.x));
            i++;
        }
    }

    private int panelWidth() {
        int n = Math.max(1, panels.size());
        int pw = (width - 12 - (n - 1) * 4) / n;
        return Math.max(78, Math.min(112, pw));
    }

    private void clampScroll() {
        double max = Math.max(0, contentHeight - height);
        scroll = Math.max(0, Math.min(max, scroll));
    }

    // =====================================================================
    //  RENDER
    // =====================================================================
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        ctx.fillGradient(0, 0, width, height, 0x90040A1C, 0x90010310);

        int pw = panelWidth();
        int maxBottom = 0;
        int accent = Theme.accent(0f);

        for (Panel p : panels) {
            List<Module> list = ModuleManager.byCategory(p.cat);
            int px = p.x;
            int py = p.y - (int) scroll;

            int bodyH = 0;
            if (p.open) for (Module m : list) bodyH += moduleHeight(m);
            int totalH = HEAD_H + bodyH;

            Draw.rrect(ctx, px - 1, py - 1, pw + 2, totalH + 2, 3, Theme.alpha(accent, 0x70));
            Draw.rrect(ctx, px, py, pw, totalH, 3, 0xEA060E20);

            // Tieu de
            Draw.hGradient(ctx, px + 1, py + 1, pw - 2, HEAD_H - 2, Theme.alpha(Theme.ACCENT1, 0xD0), Theme.alpha(Theme.ACCENT2, 0x60));
            Text title = Text.literal(p.cat.label).setStyle(Style.EMPTY.withBold(true).withColor(0xFFFFFF));
            ctx.drawTextWithShadow(textRenderer, title, px + 6, py + 4, 0xFFFFFFFF);
            String ind = p.open ? "-" : "+";
            ctx.drawTextWithShadow(textRenderer, ind, px + pw - 10, py + 4, 0xFFDCEBFF);
            hits.add(new Hit(px, py, pw, HEAD_H, () -> p.open = !p.open, null, null, p));

            if (p.open) {
                int ry = py + HEAD_H;
                for (Module m : list) ry = drawModule(ctx, m, px, pw, ry, mx, my);
            }
            maxBottom = Math.max(maxBottom, p.y + totalH);
        }
        contentHeight = maxBottom + 24;
        clampScroll();

        String hint = "Left: toggle  |  Right: settings  |  Drag title: move  |  Eclipse > ClickGui: doi phim";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2, height - 11, 0xFF5B7399);

        Notifications.render(ctx, textRenderer, width, height);
    }

    private int settingsHeight(Module m) {
        int total = 4;
        for (Setting s : m.settings) total += settingHeight(s);
        return total + 14; // + dong Key
    }

    private int moduleHeight(Module m) {
        return ROW_H + (expanded == m ? settingsHeight(m) : 0);
    }

    private int drawModule(DrawContext ctx, Module m, int px, int pw, int ry, int mx, int my) {
        int accent = Theme.accent(0f);
        boolean on = m.isEnabled();
        boolean hover = mx >= px && mx < px + pw && my >= ry && my < ry + ROW_H;

        ctx.fill(px + 1, ry, px + pw - 1, ry + ROW_H, hover ? 0xE0132344 : 0xC80A1430);
        if (on) {
            Draw.hGradient(ctx, px + 1, ry, pw - 2, ROW_H, Theme.alpha(Theme.ACCENT1, 0xC0), Theme.alpha(Theme.ACCENT2, 0x38));
            ctx.fill(px + 1, ry, px + 3, ry + ROW_H, Theme.ACCENT2);
        }
        ctx.drawTextWithShadow(textRenderer, m.name, px + 7, ry + 3, on ? 0xFFFFFFFF : 0xFFA6B8D8);

        // Dau "..." mo setting
        int dx = px + pw - 14;
        int dc = expanded == m ? 0xFFFFFFFF : (on ? 0xFFCFE6FF : 0xFF5F7BA6);
        ctx.fill(dx, ry + 7, dx + 2, ry + 9, dc);
        ctx.fill(dx + 4, ry + 7, dx + 6, ry + 9, dc);
        ctx.fill(dx + 8, ry + 7, dx + 10, ry + 9, dc);

        Runnable toggleExpand = () -> {
            expanded = (expanded == m ? null : m);
            listening = null;
            editing = null;
        };
        hits.add(new Hit(px, ry, pw - 18, ROW_H, m::toggle, toggleExpand, null, null));
        hits.add(new Hit(px + pw - 18, ry, 18, ROW_H, toggleExpand, toggleExpand, null, null));
        ry += ROW_H;

        if (expanded != m) return ry;

        int total = settingsHeight(m);
        ctx.fill(px + 1, ry, px + pw - 1, ry + total, 0xE0050B1A);
        ctx.fillGradient(px + 1, ry, px + 3, ry + total, Theme.alpha(Theme.ACCENT2, 0xC0), Theme.alpha(Theme.ACCENT1, 0x60));

        int bx = px + 6;
        int bw = pw - 11;
        int sy = ry + 3;
        for (Setting s : m.settings) {
            if (s instanceof Setting.Bool b) {
                ctx.drawTextWithShadow(textRenderer, b.name, bx + 2, sy + 2, 0xFFB8CBE8);
                int cx = bx + bw - 11;
                int cy = sy + 2;
                ctx.fill(cx, cy, cx + 9, cy + 9, b.value ? Theme.alpha(accent, 0xFF) : 0xFF1E2C4A);
                Draw.outline(ctx, cx, cy, 9, 9, b.value ? 0xFFBFE6FF : 0xFF3A5280);
                if (b.value) Draw.check(ctx, cx + 1, cy + 2, 0xFFFFFFFF);
                hits.add(new Hit(bx, sy, bw, 13, () -> b.value = !b.value, null, null, null));
                sy += 13;
            } else if (s instanceof Setting.Num n) {
                ctx.drawTextWithShadow(textRenderer, n.name, bx + 2, sy + 1, 0xFFB8CBE8);
                String v = n.display();
                ctx.drawTextWithShadow(textRenderer, v, bx + bw - 2 - textRenderer.getWidth(v), sy + 1, 0xFFFFFFFF);
                int barX = bx + 2;
                int barW = bw - 4;
                int barY = sy + 12;
                ctx.fill(barX, barY, barX + barW, barY + 3, 0xFF16264A);
                int fillW = (int) (barW * n.fraction());
                if (fillW > 0) Draw.hGradient(ctx, barX, barY, fillW, 3, Theme.ACCENT1, Theme.ACCENT2);
                ctx.fill(barX + fillW - 2, barY - 2, barX + fillW + 2, barY + 5, 0xFFFFFFFF);
                hits.add(new Hit(barX, sy + 9, barW, 11, null, null, n, null));
                sy += 20;
            } else if (s instanceof Setting.Text tx) {
                ctx.drawTextWithShadow(textRenderer, tx.name, bx + 2, sy + 1, 0xFFB8CBE8);
                int boxX = bx + 2;
                int boxW = bw - 4;
                int boxY = sy + 11;
                boolean ed = editing == tx;
                ctx.fill(boxX, boxY, boxX + boxW, boxY + 11, 0xFF0B1630);
                Draw.outline(ctx, boxX, boxY, boxW, 11, ed ? Theme.alpha(accent, 0xFF) : 0xFF22345C);
                String cur = (ed && (System.currentTimeMillis() / 450) % 2 == 0) ? "_" : "";
                if (tx.value.isEmpty() && !ed) {
                    ctx.drawTextWithShadow(textRenderer, "tap to type", boxX + 3, boxY + 2, 0xFF4B6690);
                } else {
                    String disp = tx.value;
                    while (disp.length() > 1 && textRenderer.getWidth(disp + cur) > boxW - 6) disp = disp.substring(1);
                    ctx.drawTextWithShadow(textRenderer, disp + cur, boxX + 3, boxY + 2, 0xFFFFFFFF);
                }
                hits.add(new Hit(bx, sy, bw, 24, () -> {
                    listening = null;
                    editing = (editing == tx ? null : tx);
                }, null, null, null));
                sy += 24;
            }
        }

        // Dong gan phim
        ctx.drawTextWithShadow(textRenderer, "Key", bx + 2, sy + 3, 0xFFB8CBE8);
        boolean lis = listening == m;
        String kt = lis ? "..." : (m.key < 0 ? "None" : keyName(m.key));
        int kw = textRenderer.getWidth(kt) + 10;
        int kbx = bx + bw - kw - 1;
        ctx.fill(kbx, sy + 1, kbx + kw, sy + 12, lis ? Theme.alpha(accent, 0x90) : 0xFF16264A);
        ctx.drawCenteredTextWithShadow(textRenderer, kt, kbx + kw / 2, sy + 3, 0xFFFFFFFF);
        hits.add(new Hit(bx, sy, bw, 13, () -> {
            editing = null;
            listening = (listening == m ? null : m);
        }, null, null, null));

        return ry + total;
    }

    private static int settingHeight(Setting s) {
        if (s instanceof Setting.Num) return 20;
        if (s instanceof Setting.Text) return 24;
        return 13;
    }

    private static String keyName(int code) {
        return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString();
    }

    private void applySlider(Hit hit, double mx) {
        hit.slider.setFraction((mx - hit.x) / (double) hit.w);
    }

    // =====================================================================
    //  INPUT
    // =====================================================================
    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (editing != null) {
            if (chr >= 32 && chr != 127 && editing.value.length() < editing.max) editing.value += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        pressX = mx;
        pressY = my;
        moved = false;
        pressed = null;
        dragging = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (!hit.in(mx, my)) continue;
            if (hit.slider != null) {
                if (button == 0) {
                    sliderHit = hit;
                    applySlider(hit, mx);
                }
                return true;
            }
            pressed = hit;
            pressedButton = button;
            if (hit.panel != null && button == 0) dragging = hit.panel;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliderHit != null) {
            applySlider(sliderHit, mx);
            return true;
        }
        if (Math.abs(my - pressY) > 4 || Math.abs(mx - pressX) > 4) moved = true;
        if (!moved) return true;
        if (dragging != null) {
            int pw = panelWidth();
            dragging.x = (int) Math.max(0, Math.min(width - pw, dragging.x + dx));
            dragging.y = (int) Math.max(0, dragging.y + dy);
        } else {
            scroll -= dy;
            clampScroll();
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliderHit != null) {
            sliderHit = null;
            Config.save();
            return true;
        }
        if (pressed != null && !moved) {
            Runnable r = pressedButton == 0 ? pressed.left : (pressedButton == 1 ? pressed.right : null);
            if (r != null) {
                r.run();
                Config.save();
            }
        }
        pressed = null;
        dragging = null;
        moved = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll -= vAmount * 14;
        clampScroll();
        return true;
    }

    @Override
    public void removed() {
        editing = null;
        Config.save();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (editing != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                editing = null;
                Config.save();
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!editing.value.isEmpty()) editing.value = editing.value.substring(0, editing.value.length() - 1);
            } else if (Screen.isPaste(keyCode)) {
                String clip = this.client.keyboard.getClipboard();
                StringBuilder sb = new StringBuilder(editing.value);
                for (char ch : clip.toCharArray()) {
                    if (ch >= 32 && ch != 127 && sb.length() < editing.max) sb.append(ch);
                }
                editing.value = sb.toString();
            }
            return true;
        }
        if (listening != null) {
            // ESC = reset key, phim khac = gan key
            listening.key = (keyCode == GLFW.GLFW_KEY_ESCAPE) ? -1 : keyCode;
            listening = null;
            Config.save();
            return true;
        }
        ClickGui cg = ModuleManager.get(ClickGui.class);
        int closeKey = cg != null && cg.key >= 0 ? cg.key : GLFW.GLFW_KEY_RIGHT_SHIFT;
        if (keyCode == closeKey) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
