package com.myclient.gui;

import com.myclient.MyClient;
import com.myclient.config.Config;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * GUI: tab category + danh sach module.
 * Click trai = bat/tat. Click phai (hoac giu lau tren dien thoai) = mo setting.
 * Keo tren danh sach = cuon. Setting dang so co thanh truot (cham/keo).
 */
public class ClickGuiScreen extends Screen {
    private static class Hit {
        final int x, y, w, h;
        final Runnable left, right;
        final Setting.Num slider;
        final boolean scrolls;

        Hit(int x, int y, int w, int h, Runnable left, Runnable right, Setting.Num slider, boolean scrolls) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
            this.right = right;
            this.slider = slider;
            this.scrolls = scrolls;
        }

        boolean in(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Hit> hits = new ArrayList<>();
    private Category tab = Category.COMBAT;
    private Module expanded;

    private double scroll;
    private int contentTop, contentBottom, contentHeight;

    private Hit pressed;
    private int pressedButton;
    private double pressX, pressY;
    private boolean moved;
    private Hit sliderHit;

    public ClickGuiScreen() {
        super(Text.literal(MyClient.NAME));
    }

    @Override
    public boolean shouldPause() { return false; }

    private void clampScroll() {
        double max = Math.max(0, contentHeight - (contentBottom - contentTop));
        scroll = Math.max(0, Math.min(max, scroll));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        ctx.fillGradient(0, 0, width, height, 0xC0140A22, 0xC005050C);

        int w = Math.min(width - 10, 300);
        int h = Math.min(height - 10, 230);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        int accent = Theme.accent(0f);

        Draw.rrect(ctx, x - 1, y - 1, w + 2, h + 2, 4, Theme.alpha(accent, 0x90));
        Draw.rrect(ctx, x, y, w, h, 4, 0xFF0E0E18);

        // Header
        Text title = Text.literal(MyClient.NAME.toUpperCase())
                .setStyle(Style.EMPTY.withBold(true).withColor(accent & 0xFFFFFF));
        ctx.drawTextWithShadow(textRenderer, title, x + 10, y + 8, 0xFFFFFFFF);
        String ver = "1.21.1";
        ctx.drawTextWithShadow(textRenderer, ver, x + w - 10 - textRenderer.getWidth(ver), y + 8, 0xFF6B6B82);
        Draw.hGradient(ctx, x + 8, y + 21, w - 16, 1, Theme.ACCENT1, Theme.ACCENT2);

        // Tabs
        int tabY = y + 25;
        int tabW = (w - 16) / Category.values().length;
        int i = 0;
        for (Category c : Category.values()) {
            int tx = x + 8 + i * tabW;
            boolean sel = c == tab;
            boolean hover = mx >= tx && mx < tx + tabW && my >= tabY && my < tabY + 16;
            ctx.drawCenteredTextWithShadow(textRenderer, c.label, tx + tabW / 2, tabY + 4,
                    sel ? 0xFFFFFFFF : (hover ? 0xFFC8C8DC : 0xFF77778F));
            if (sel) Draw.hGradient(ctx, tx + 4, tabY + 14, tabW - 8, 2, Theme.ACCENT1, Theme.ACCENT2);
            hits.add(new Hit(tx, tabY, tabW, 16, () -> {
                tab = c;
                scroll = 0;
                expanded = null;
            }, null, null, false));
            i++;
        }

        // Content
        contentTop = y + 44;
        contentBottom = y + h - 18;
        clampScroll();
        ctx.enableScissor(x + 4, contentTop, x + w - 4, contentBottom);
        int ry = contentTop + 2 - (int) scroll;
        List<Module> list = ModuleManager.byCategory(tab);
        if (list.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Coming soon", x + w / 2, contentTop + 20, 0xFF55556B);
        }
        for (Module m : list) {
            ry = drawModule(ctx, m, x, w, ry, mx, my);
        }
        contentHeight = ry + (int) scroll - contentTop + 2;
        ctx.disableScissor();

        // Footer
        String hint = "Click: toggle  |  Right-click: settings";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, x + w / 2, y + h - 12, 0xFF6B6B82);
    }

    private int drawModule(DrawContext ctx, Module m, int x, int w, int ry, int mx, int my) {
        int accent = Theme.accent(0f);
        int rowX = x + 8;
        int rowW = w - 16;
        boolean on = m.isEnabled();
        boolean hover = mx >= rowX && mx < rowX + rowW && my >= ry && my < ry + 20
                && my >= contentTop && my < contentBottom;

        Draw.rrect(ctx, rowX, ry, rowW, 20, 3,
                on ? Theme.alpha(accent, 0x60) : (hover ? 0xFF272738 : 0xFF1A1A28));
        if (on) ctx.fill(rowX, ry + 4, rowX + 2, ry + 16, accent);
        ctx.drawTextWithShadow(textRenderer, m.name, rowX + 9, ry + 6, on ? 0xFFFFFFFF : 0xFFB0B0C6);

        // Switch
        int swW = 22, swH = 10;
        int sx = rowX + rowW - swW - 7;
        int sy = ry + 5;
        Draw.rrect(ctx, sx, sy, swW, swH, 4, on ? accent : 0xFF35354A);
        int kx = on ? sx + swW - swH + 1 : sx + 1;
        Draw.rrect(ctx, kx, sy + 1, swH - 2, swH - 2, 3, 0xFFFFFFFF);

        hits.add(new Hit(rowX, ry, rowW, 20, m::toggle,
                () -> expanded = (expanded == m ? null : m), null, true));

        if (!m.settings.isEmpty()) {
            int dx = sx - 16;
            int dc = expanded == m ? accent : 0xFF7A7A92;
            ctx.fill(dx, ry + 9, dx + 2, ry + 11, dc);
            ctx.fill(dx + 4, ry + 9, dx + 6, ry + 11, dc);
            ctx.fill(dx + 8, ry + 9, dx + 10, ry + 11, dc);
            hits.add(new Hit(dx - 4, ry, 18, 20, () -> expanded = (expanded == m ? null : m), null, null, true));
        }
        ry += 22;

        if (expanded == m) {
            int bx = rowX + 4;
            int bw = rowW - 8;
            int total = 6;
            for (Setting s : m.settings) total += (s instanceof Setting.Num) ? 26 : 18;
            Draw.rrect(ctx, bx, ry, bw, total, 3, 0xFF141420);
            ctx.fill(bx, ry + 3, bx + 2, ry + total - 3, Theme.alpha(accent, 0xB0));

            int sy2 = ry + 4;
            for (Setting s : m.settings) {
                if (s instanceof Setting.Bool b) {
                    ctx.drawTextWithShadow(textRenderer, b.name, bx + 9, sy2 + 4, 0xFFC4C4D8);
                    int bsx = bx + bw - 24;
                    int bsy = sy2 + 3;
                    Draw.rrect(ctx, bsx, bsy, 18, 9, 4, b.value ? accent : 0xFF35354A);
                    Draw.rrect(ctx, b.value ? bsx + 10 : bsx + 1, bsy + 1, 7, 7, 3, 0xFFFFFFFF);
                    hits.add(new Hit(bx, sy2, bw, 16, () -> b.value = !b.value, null, null, true));
                    sy2 += 18;
                } else if (s instanceof Setting.Num n) {
                    ctx.drawTextWithShadow(textRenderer, n.name, bx + 9, sy2 + 2, 0xFFC4C4D8);
                    String v = n.display();
                    ctx.drawTextWithShadow(textRenderer, v, bx + bw - 8 - textRenderer.getWidth(v), sy2 + 2, 0xFFFFFFFF);
                    int barX = bx + 9;
                    int barW = bw - 18;
                    int barY = sy2 + 15;
                    Draw.rrect(ctx, barX, barY, barW, 4, 2, 0xFF2A2A3E);
                    int fillW = (int) (barW * n.fraction());
                    if (fillW > 0) Draw.hGradient(ctx, barX, barY, fillW, 4, Theme.ACCENT1, Theme.ACCENT2);
                    Draw.rrect(ctx, barX + fillW - 3, barY - 2, 6, 8, 2, 0xFFFFFFFF);
                    hits.add(new Hit(barX, sy2 + 11, barW, 14, null, null, n, true));
                    sy2 += 26;
                }
            }
            ry += total + 3;
        }
        return ry;
    }

    private void applySlider(Hit hit, double mx) {
        hit.slider.setFraction((mx - hit.x) / (double) hit.w);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        pressX = mx;
        pressY = my;
        moved = false;
        pressed = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (!hit.in(mx, my)) continue;
            if (hit.scrolls && (my < contentTop || my >= contentBottom)) continue;
            if (hit.slider != null) {
                if (button == 0) {
                    sliderHit = hit;
                    applySlider(hit, mx);
                }
                return true;
            }
            pressed = hit;
            pressedButton = button;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliderHit != null) {
            applySlider(sliderHit, mx);
            return true;
        }
        if (Math.abs(my - pressY) > 5 || Math.abs(mx - pressX) > 5) moved = true;
        if (moved && (pressed == null || pressed.scrolls)) {
            scroll -= dy;
            clampScroll();
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliderHit != null) {
            sliderHit = null;
            Config.save();
            return true;
        }
        if (pressed != null && !moved) {
            Runnable r = pressedButton == 0 ? pressed.left : (pressedButton == 1 ? pressed.right : null);
            if (r != null) {
                r.run();
                Config.save();
            }
        }
        pressed = null;
        moved = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll -= vAmount * 14;
        clampScroll();
        return true;
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
