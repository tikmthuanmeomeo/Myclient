package com.myclient.gui;

import com.myclient.MyClient;
import com.myclient.config.Config;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * GUI huyen ao: nen troi sao + cuc quang + qua cau sang, cua so xanh.
 * Click trai = bat/tat. Click phai (hoac giu lau tren dien thoai) = setting.
 * Keo tren danh sach = cuon. Setting dang so co thanh truot.
 */
public class ClickGuiScreen extends Screen {
    private static class Hit {
        final int x, y, w, h;
        final Runnable left, right;
        final Setting.Num slider;
        final boolean scrolls;

        Hit(int x, int y, int w, int h, Runnable left, Runnable right, Setting.Num slider, boolean scrolls) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
            this.right = right;
            this.slider = slider;
            this.scrolls = scrolls;
        }

        boolean in(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private static class Spark {
        float x, y, vx, vy;
        long born;
    }

    // ---- sky ----
    private static final int STARS = 110;
    private final float[] starX = new float[STARS];
    private final float[] starY = new float[STARS];
    private final float[] starPhase = new float[STARS];
    private final float[] starSpeed = new float[STARS];
    private final int[] starSize = new int[STARS];
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rng = new Random();
    private final long startTime = System.currentTimeMillis();
    private double lastMx = -1, lastMy = -1;

    // ---- gui state ----
    private final List<Hit> hits = new ArrayList<>();
    private Category tab = Category.COMBAT;
    private Module expanded;
    private Module listening; // module dang cho bam phim de gan key
    private Setting.Text editing; // o chu dang nhap

    private double scroll;
    private int contentTop, contentBottom, contentHeight;

    private Hit pressed;
    private int pressedButton;
    private double pressX, pressY;
    private boolean moved;
    private Hit sliderHit;

    public ClickGuiScreen() {
        super(Text.literal(MyClient.NAME));
        Random r = new Random(42);
        for (int i = 0; i < STARS; i++) {
            starX[i] = r.nextFloat();
            starY[i] = r.nextFloat();
            starPhase[i] = r.nextFloat() * 6.28f;
            starSpeed[i] = 0.8f + r.nextFloat() * 2.2f;
            float k = r.nextFloat();
            starSize[i] = k < 0.12f ? 2 : (k < 0.4f ? 1 : 0);
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    private void clampScroll() {
        double max = Math.max(0, contentHeight - (contentBottom - contentTop));
        scroll = Math.max(0, Math.min(max, scroll));
    }

    // =====================================================================
    //  SKY
    // =====================================================================
    private void drawSky(DrawContext ctx, int mx, int my, double t) {
        ctx.fillGradient(0, 0, width, height, 0xF0030A1C, 0xF0010310);

        // Cuc quang
        for (int layer = 0; layer < 2; layer++) {
            int col = layer == 0 ? 0x22D3EE : 0x6366F1;
            int peak = Theme.alpha(col, layer == 0 ? 0x38 : 0x2C);
            int none = Theme.alpha(col, 0);
            for (int px = 0; px < width; px += 4) {
                double wave = Math.sin(px * 0.018 + t * 0.6 + layer * 1.7)
                        + 0.6 * Math.sin(px * 0.041 - t * 0.4 + layer);
                int hh = Math.max(8, (int) (height * 0.17 + height * 0.07 * wave) + layer * 10);
                int mid = hh / 2;
                ctx.fillGradient(px, 0, px + 4, mid, none, peak);
                ctx.fillGradient(px, mid, px + 4, hh, peak, none);
            }
        }

        // Sao lap lanh troi cham
        for (int i = 0; i < STARS; i++) {
            double tw = 0.5 + 0.5 * Math.sin(t * starSpeed[i] + starPhase[i]);
            int a = (int) (0x30 + 0xC0 * tw);
            int px = (int) (((starX[i] * width + t * (2 + starSize[i] * 2)) % width + width) % width);
            int py = (int) (starY[i] * height);
            if (starSize[i] == 2) {
                Draw.sparkle(ctx, px, py, 2, Theme.alpha(0xFFFFFF, a));
            } else if (starSize[i] == 1) {
                ctx.fill(px, py, px + 2, py + 2, Theme.alpha(0xBFD9FF, a));
            } else {
                ctx.fill(px, py, px + 1, py + 1, Theme.alpha(0xBFD9FF, a));
            }
        }

        // Qua cau sang troi noi
        int[] orbCols = {0x3B82F6, 0x22D3EE, 0x8B5CF6, 0x38BDF8, 0x3B82F6, 0x22D3EE};
        for (int i = 0; i < orbCols.length; i++) {
            double fx = (i * 0.37 + 0.13) % 1.0;
            double fy = (i * 0.61 + 0.21) % 1.0;
            int cx = (int) (width * (0.08 + 0.84 * fx) + Math.sin(t * 0.3 + i * 1.3) * 18);
            int cy = (int) (height * (0.15 + 0.7 * fy) + Math.cos(t * 0.25 + i * 2.1) * 14);
            int r = 10 + (i % 3) * 6;
            int pulse = (int) (0x0B + 0x06 * Math.sin(t * 0.8 + i));
            Draw.glow(ctx, cx, cy, r, orbCols[i], pulse);
        }

        // Sao bang
        double cycle = 7.0;
        long idx = (long) (t / cycle);
        double ph = (t % cycle) / cycle;
        if (ph < 0.14) {
            float p = (float) (ph / 0.14);
            Random r = new Random(idx * 7919L + 13);
            float sx = width * (0.5f + 0.5f * r.nextFloat());
            float sy = height * (0.02f + 0.25f * r.nextFloat());
            float dx = -width * 0.45f;
            float dy = height * 0.30f;
            for (int k = 0; k < 14; k++) {
                float pk = p - k * 0.02f;
                if (pk < 0) break;
                int px = (int) (sx + dx * pk);
                int py = (int) (sy + dy * pk);
                int a = (int) (0xD0 * (1f - k / 14f) * (1f - p * 0.4f));
                ctx.fill(px, py, px + 2, py + 1, Theme.alpha(0xCFE8FF, a));
            }
        }

        // Tia sang theo con tro / ngon tay
        if (lastMx >= 0 && Math.abs(mx - lastMx) + Math.abs(my - lastMy) > 1) {
            for (int k = 0; k < 2 && sparks.size() < 60; k++) {
                Spark s = new Spark();
                s.x = mx + rng.nextFloat() * 4 - 2;
                s.y = my + rng.nextFloat() * 4 - 2;
                s.vx = rng.nextFloat() * 0.8f - 0.4f;
                s.vy = -0.2f - rng.nextFloat() * 0.5f;
                s.born = System.currentTimeMillis();
                sparks.add(s);
            }
        }
        lastMx = mx;
        lastMy = my;
        long now = System.currentTimeMillis();
        for (int i = sparks.size() - 1; i >= 0; i--) {
            Spark s = sparks.get(i);
            float age = (now - s.born) / 700f;
            if (age >= 1f) {
                sparks.remove(i);
                continue;
            }
            s.x += s.vx;
            s.y += s.vy;
            int col = (i % 2 == 0) ? 0x7DE8FF : 0xFFFFFF;
            Draw.sparkle(ctx, (int) s.x, (int) s.y, 1, Theme.alpha(col, (int) (0xC0 * (1f - age))));
        }
    }

    // =====================================================================
    //  RENDER
    // =====================================================================
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        double t = (System.currentTimeMillis() - startTime) / 1000.0;
        drawSky(ctx, mx, my, t);

        int w = Math.min(width - 10, 300);
        int h = Math.min(height - 10, 230);
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        int accent = Theme.accent(0f);

        // Hao quang quanh cua so
        Draw.rrect(ctx, x - 3, y - 3, w + 6, h + 6, 5, Theme.alpha(accent, 0x16));
        Draw.rrect(ctx, x - 2, y - 2, w + 4, h + 4, 4, Theme.alpha(accent, 0x30));
        Draw.rrect(ctx, x - 1, y - 1, w + 2, h + 2, 4, Theme.alpha(accent, 0x80));
        Draw.rrect(ctx, x, y, w, h, 4, 0xF2071024);
        ctx.fillGradient(x + 1, y + 1, x + w - 1, y + 24, Theme.alpha(Theme.ACCENT1, 0x48), Theme.alpha(Theme.ACCENT1, 0));
        ctx.fill(x + 4, y + 1, x + w - 4, y + 2, 0x22FFFFFF);

        // Sao lap lanh o goc cua so
        int tw1 = (int) (0x40 + 0x90 * (0.5 + 0.5 * Math.sin(t * 2.1)));
        int tw2 = (int) (0x40 + 0x90 * (0.5 + 0.5 * Math.sin(t * 1.7 + 2)));
        Draw.sparkle(ctx, x + w + 5, y - 4, 3, Theme.alpha(0x7DE8FF, tw1));
        Draw.sparkle(ctx, x - 5, y + h + 4, 3, Theme.alpha(0xA78BFA, tw2));

        // Header: chu gradient lap lanh
        String name = MyClient.NAME.toUpperCase();
        int cx = x + 16;
        for (int i = 0; i < name.length(); i++) {
            float k = (float) (0.5 + 0.5 * Math.sin(t * 2.0 - i * 0.6));
            int col = Theme.lerp(Theme.ACCENT1, 0xFFB8F3FF, k);
            Text chr = Text.literal(String.valueOf(name.charAt(i)))
                    .setStyle(Style.EMPTY.withBold(true).withColor(col & 0xFFFFFF));
            ctx.drawTextWithShadow(textRenderer, chr, cx, y + 8, 0xFFFFFFFF);
            cx += textRenderer.getWidth(chr);
        }
        Draw.sparkle(ctx, x + 9, y + 12, 3, Theme.alpha(0xBFEFFF, (int) (0x90 + 0x60 * Math.sin(t * 3))));
        String ver = "1.21.1";
        ctx.drawTextWithShadow(textRenderer, ver, x + w - 10 - textRenderer.getWidth(ver), y + 8, 0xFF5B7399);
        Draw.hGradient(ctx, x + 8, y + 21, w - 16, 1, Theme.ACCENT1, Theme.ACCENT2);

        // Tabs
        int tabY = y + 25;
        int tabW = (w - 16) / Category.values().length;
        int i = 0;
        for (Category c : Category.values()) {
            int tx = x + 8 + i * tabW;
            boolean sel = c == tab;
            boolean hover = mx >= tx && mx < tx + tabW && my >= tabY && my < tabY + 16;
            if (sel) Draw.rrect(ctx, tx + 2, tabY, tabW - 4, 16, 3, Theme.alpha(accent, 0x2C));
            ctx.drawCenteredTextWithShadow(textRenderer, c.label, tx + tabW / 2, tabY + 4,
                    sel ? 0xFFFFFFFF : (hover ? 0xFF9DB8E0 : 0xFF5F7BA6));
            if (sel) Draw.hGradient(ctx, tx + 4, tabY + 14, tabW - 8, 2, Theme.ACCENT1, Theme.ACCENT2);
            hits.add(new Hit(tx, tabY, tabW, 16, () -> {
                tab = c;
                scroll = 0;
                expanded = null;
                listening = null;
                editing = null;
            }, null, null, false));
            i++;
        }

        // Content
        contentTop = y + 44;
        contentBottom = y + h - 18;
        clampScroll();
        ctx.enableScissor(x + 4, contentTop, x + w - 4, contentBottom);
        int ry = contentTop + 3 - (int) scroll;
        List<Module> list = ModuleManager.byCategory(tab);
        if (list.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Coming soon", x + w / 2, contentTop + 20, 0xFF3F5580);
        }
        for (Module m : list) {
            ry = drawModule(ctx, m, x, w, ry, mx, my);
        }
        contentHeight = ry + (int) scroll - contentTop + 2;
        ctx.disableScissor();

        // Footer
        String hint = "Click: toggle  |  Right-click: settings";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, x + w / 2, y + h - 12, 0xFF4B6690);
    }

    private int drawModule(DrawContext ctx, Module m, int x, int w, int ry, int mx, int my) {
        int accent = Theme.accent(0f);
        int rowX = x + 8;
        int rowW = w - 16;
        boolean on = m.isEnabled();
        boolean hover = mx >= rowX && mx < rowX + rowW && my >= ry && my < ry + 20
                && my >= contentTop && my < contentBottom;

        if (on) Draw.rrect(ctx, rowX - 1, ry - 1, rowW + 2, 22, 4, Theme.alpha(accent, 0x22));
        Draw.rrect(ctx, rowX, ry, rowW, 20, 3, hover ? 0xFF132344 : 0xFF0D1830);
        if (on) {
            Draw.hGradient(ctx, rowX + 1, ry + 1, rowW - 2, 18,
                    Theme.alpha(Theme.ACCENT1, 0x95), Theme.alpha(Theme.ACCENT2, 0x14));
            ctx.fillGradient(rowX, ry + 3, rowX + 2, ry + 17, Theme.ACCENT2, Theme.ACCENT1);
        }
        ctx.drawTextWithShadow(textRenderer, m.name, rowX + 9, ry + 6, on ? 0xFFFFFFFF : 0xFF9DB0D0);

        // Switch
        int swW = 22, swH = 10;
        int sx = rowX + rowW - swW - 7;
        int sy = ry + 5;
        if (on) Draw.rrect(ctx, sx - 1, sy - 1, swW + 2, swH + 2, 4, Theme.alpha(accent, 0x45));
        Draw.rrect(ctx, sx, sy, swW, swH, 4, on ? accent : 0xFF1E2C4A);
        int kx = on ? sx + swW - swH + 1 : sx + 1;
        Draw.rrect(ctx, kx, sy + 1, swH - 2, swH - 2, 3, 0xFFFFFFFF);

        hits.add(new Hit(rowX, ry, rowW, 20, m::toggle,
                () -> expanded = (expanded == m ? null : m), null, true));

        {
            int dx = sx - 16;
            int dc = expanded == m ? accent : 0xFF4B6690;
            ctx.fill(dx, ry + 9, dx + 2, ry + 11, dc);
            ctx.fill(dx + 4, ry + 9, dx + 6, ry + 11, dc);
            ctx.fill(dx + 8, ry + 9, dx + 10, ry + 11, dc);
            hits.add(new Hit(dx - 4, ry, 18, 20, () -> expanded = (expanded == m ? null : m), null, null, true));
        }
        ry += 22;

        if (expanded == m) {
            int bx = rowX + 4;
            int bw = rowW - 8;
            int total = 6 + 18;
            for (Setting s : m.settings) total += settingHeight(s);
            Draw.rrect(ctx, bx, ry, bw, total, 3, 0xFF091328);
            ctx.fillGradient(bx, ry + 3, bx + 2, ry + total - 3, Theme.alpha(Theme.ACCENT2, 0xC0), Theme.alpha(Theme.ACCENT1, 0x60));

            int sy2 = ry + 4;
            for (Setting s : m.settings) {
                if (s instanceof Setting.Bool b) {
                    ctx.drawTextWithShadow(textRenderer, b.name, bx + 9, sy2 + 4, 0xFFB8CBE8);
                    int bsx = bx + bw - 24;
                    int bsy = sy2 + 3;
                    if (b.value) Draw.rrect(ctx, bsx - 1, bsy - 1, 20, 11, 4, Theme.alpha(accent, 0x40));
                    Draw.rrect(ctx, bsx, bsy, 18, 9, 4, b.value ? accent : 0xFF1E2C4A);
                    Draw.rrect(ctx, b.value ? bsx + 10 : bsx + 1, bsy + 1, 7, 7, 3, 0xFFFFFFFF);
                    hits.add(new Hit(bx, sy2, bw, 16, () -> b.value = !b.value, null, null, true));
                    sy2 += 18;
                } else if (s instanceof Setting.Num n) {
                    ctx.drawTextWithShadow(textRenderer, n.name, bx + 9, sy2 + 2, 0xFFB8CBE8);
                    String v = n.display();
                    ctx.drawTextWithShadow(textRenderer, v, bx + bw - 8 - textRenderer.getWidth(v), sy2 + 2, 0xFFFFFFFF);
                    int barX = bx + 9;
                    int barW = bw - 18;
                    int barY = sy2 + 15;
                    Draw.rrect(ctx, barX, barY, barW, 4, 2, 0xFF16264A);
                    int fillW = (int) (barW * n.fraction());
                    if (fillW > 0) Draw.hGradient(ctx, barX, barY, fillW, 4, Theme.ACCENT1, Theme.ACCENT2);
                    Draw.glow(ctx, barX + fillW, barY + 2, 6, 0x22D3EE, 0x0E);
                    Draw.rrect(ctx, barX + fillW - 3, barY - 2, 6, 8, 2, 0xFFFFFFFF);
                    hits.add(new Hit(barX, sy2 + 11, barW, 14, null, null, n, true));
                    sy2 += 26;
                } else if (s instanceof Setting.Text tx) {
                    ctx.drawTextWithShadow(textRenderer, tx.name, bx + 9, sy2 + 2, 0xFFB8CBE8);
                    int boxX = bx + 9;
                    int boxW = bw - 18;
                    int boxY = sy2 + 13;
                    boolean ed = editing == tx;
                    Draw.rrect(ctx, boxX - 1, boxY - 1, boxW + 2, 14, 3, ed ? Theme.alpha(accent, 0x90) : 0xFF16264A);
                    Draw.rrect(ctx, boxX, boxY, boxW, 12, 3, 0xFF0B1630);
                    String cur = (ed && (System.currentTimeMillis() / 450) % 2 == 0) ? "_" : "";
                    if (tx.value.isEmpty() && !ed) {
                        ctx.drawTextWithShadow(textRenderer, "tap to type", boxX + 4, boxY + 2, 0xFF4B6690);
                    } else {
                        String disp = tx.value;
                        while (disp.length() > 1 && textRenderer.getWidth(disp + cur) > boxW - 8) disp = disp.substring(1);
                        ctx.drawTextWithShadow(textRenderer, disp + cur, boxX + 4, boxY + 2, 0xFFFFFFFF);
                    }
                    hits.add(new Hit(bx, sy2, bw, 28, () -> {
                        listening = null;
                        editing = (editing == tx ? null : tx);
                    }, null, null, true));
                    sy2 += 28;
                }
            }
            // Key bind row
            ctx.drawTextWithShadow(textRenderer, "Key", bx + 9, sy2 + 4, 0xFFB8CBE8);
            boolean lis = listening == m;
            String kt = lis ? "..." : (m.key < 0 ? "None" : keyName(m.key));
            int kw = textRenderer.getWidth(kt) + 12;
            int kbx = bx + bw - kw - 6;
            Draw.rrect(ctx, kbx, sy2 + 1, kw, 14, 3, lis ? Theme.alpha(accent, 0x90) : 0xFF16264A);
            ctx.drawCenteredTextWithShadow(textRenderer, kt, kbx + kw / 2, sy2 + 4, 0xFFFFFFFF);
            hits.add(new Hit(bx, sy2, bw, 16, () -> {
                editing = null;
                listening = (listening == m ? null : m);
            }, null, null, true));
            sy2 += 18;
            ry += total + 3;
        }
        return ry;
    }

    private static int settingHeight(Setting s) {
        if (s instanceof Setting.Num) return 26;
        if (s instanceof Setting.Text) return 28;
        return 18;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (editing != null) {
            if (chr >= 32 && chr != 127 && editing.value.length() < editing.max) editing.value += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private static String keyName(int code) {
        return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString();
    }

    private void applySlider(Hit hit, double mx) {
        hit.slider.setFraction((mx - hit.x) / (double) hit.w);
    }

    // =====================================================================
    //  INPUT
    // =====================================================================
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        pressX = mx;
        pressY = my;
        moved = false;
        pressed = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (!hit.in(mx, my)) continue;
            if (hit.scrolls && (my < contentTop || my >= contentBottom)) continue;
            if (hit.slider != null) {
                if (button == 0) {
                    sliderHit = hit;
                    applySlider(hit, mx);
                }
                return true;
            }
            pressed = hit;
            pressedButton = button;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliderHit != null) {
            applySlider(sliderHit, mx);
            return true;
        }
        if (Math.abs(my - pressY) > 5 || Math.abs(mx - pressX) > 5) moved = true;
        if (moved && (pressed == null || pressed.scrolls)) {
            scroll -= dy;
            clampScroll();
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliderHit != null) {
            sliderHit = null;
            Config.save();
            return true;
        }
        if (pressed != null && !moved) {
            Runnable r = pressedButton == 0 ? pressed.left : (pressedButton == 1 ? pressed.right : null);
            if (r != null) {
                r.run();
                Config.save();
            }
        }
        pressed = null;
        moved = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll -= vAmount * 14;
        clampScroll();
        return true;
    }

    @Override
    public void removed() {
        editing = null;
        Config.save();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (editing != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                editing = null;
                Config.save();
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!editing.value.isEmpty()) editing.value = editing.value.substring(0, editing.value.length() - 1);
            } else if (Screen.isPaste(keyCode)) {
                String clip = this.client.keyboard.getClipboard();
                StringBuilder sb = new StringBuilder(editing.value);
                for (char ch : clip.toCharArray()) {
                    if (ch >= 32 && ch != 127 && sb.length() < editing.max) sb.append(ch);
                }
                editing.value = sb.toString();
            }
            return true;
        }
        if (listening != null) {
            // ESC = reset key, phim khac = gan key
            listening.key = (keyCode == GLFW.GLFW_KEY_ESCAPE) ? -1 : keyCode;
            listening = null;
            Config.save();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
