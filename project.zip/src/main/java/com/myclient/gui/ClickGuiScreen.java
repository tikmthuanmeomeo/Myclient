package com.myclient.gui;

import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** GUI don gian, de bam tren dien thoai: tab category + danh sach module. */
public class ClickGuiScreen extends Screen {
    private record Hit(int x, int y, int w, int h, Runnable action) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private Category tab = Category.COMBAT;
    private Module expanded;

    public ClickGuiScreen() {
        super(Text.literal("MyClient"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        ctx.fill(0, 0, width, height, 0x99000000);

        int w = Math.min(width - 10, 280);
        int h = Math.min(height - 10, 220);
        int x = (width - w) / 2;
        int y = (height - h) / 2;

        ctx.fill(x, y, x + w, y + h, 0xE0141420);
        ctx.fill(x, y, x + w, y + 16, 0xFF6C5CE7);
        ctx.drawTextWithShadow(textRenderer, "MyClient", x + 6, y + 4, 0xFFFFFFFF);

        int tabW = w / Category.values().length;
        int i = 0;
        for (Category c : Category.values()) {
            int tx = x + i * tabW;
            boolean sel = c == tab;
            ctx.fill(tx, y + 16, tx + tabW, y + 32, sel ? 0xFF2D2D44 : 0xFF1B1B2B);
            ctx.drawCenteredTextWithShadow(textRenderer, c.label, tx + tabW / 2, y + 20,
                    sel ? 0xFFFFFFFF : 0xFF9A9AB0);
            hits.add(new Hit(tx, y + 16, tabW, 16, () -> tab = c));
            i++;
        }

        int ry = y + 36;
        List<Module> list = ModuleManager.byCategory(tab);
        if (list.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, "(no modules yet)", x + 8, ry, 0xFF777788);
        }
        for (Module m : list) {
            boolean hover = mx >= x && mx < x + w && my >= ry && my < ry + 16;
            ctx.fill(x + 4, ry, x + w - 4, ry + 16,
                    m.isEnabled() ? 0xFF3B7A57 : (hover ? 0xFF2A2A3E : 0xFF222233));
            ctx.drawTextWithShadow(textRenderer, m.name, x + 10, ry + 4, 0xFFFFFFFF);
            String st = m.isEnabled() ? "ON" : "OFF";
            ctx.drawTextWithShadow(textRenderer, st, x + w - 26 - textRenderer.getWidth(st), ry + 4, 0xFFDDDDDD);
            boolean open = expanded == m;
            if (!m.settings.isEmpty()) {
                ctx.drawTextWithShadow(textRenderer, open ? "-" : "+", x + w - 16, ry + 4, 0xFFFFFFFF);
            }
            hits.add(new Hit(x + 4, ry, w - 8, 16, m::toggle));
            if (!m.settings.isEmpty()) {
                hits.add(new Hit(x + w - 22, ry, 18, 16, () -> expanded = (expanded == m ? null : m)));
            }
            ry += 18;

            if (open) {
                for (Setting s : m.settings) {
                    ctx.fill(x + 12, ry, x + w - 4, ry + 14, 0xFF1C1C2C);
                    if (s instanceof Setting.Bool b) {
                        ctx.drawTextWithShadow(textRenderer, b.name + ": " + (b.value ? "ON" : "OFF"),
                                x + 16, ry + 3, b.value ? 0xFF7CFC9A : 0xFFFF8A8A);
                        hits.add(new Hit(x + 12, ry, w - 16, 14, () -> b.value = !b.value));
                    } else if (s instanceof Setting.Num n) {
                        ctx.drawTextWithShadow(textRenderer, n.name + ": " + n.value, x + 16, ry + 3, 0xFFDDDDDD);
                        int bx = x + w - 44;
                        ctx.fill(bx, ry + 1, bx + 16, ry + 13, 0xFF333350);
                        ctx.drawCenteredTextWithShadow(textRenderer, "-", bx + 8, ry + 3, 0xFFFFFFFF);
                        ctx.fill(bx + 22, ry + 1, bx + 38, ry + 13, 0xFF333350);
                        ctx.drawCenteredTextWithShadow(textRenderer, "+", bx + 30, ry + 3, 0xFFFFFFFF);
                        hits.add(new Hit(bx, ry + 1, 16, 12, n::dec));
                        hits.add(new Hit(bx + 22, ry + 1, 16, 12, n::inc));
                    }
                    ry += 16;
                }
            }
        }

        ctx.drawTextWithShadow(textRenderer, "RShift / ESC: close", x + 6, y + h - 12, 0xFF777788);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit hit = hits.get(i);
                if (hit.in(mx, my)) {
                    hit.action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
