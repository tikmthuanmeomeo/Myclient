package com.myclient.gui;

import com.myclient.MyClient;
import com.myclient.config.Config;
import com.myclient.module.Category;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import com.myclient.module.impl.ClickGui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Formatting;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Click GUI dang bang: moi Category la 1 panel dung canh nhau.
 * Click trai = bat/tat module, click phai (hoac nut ...) = mo setting.
 * Keo tieu de panel = di chuyen, bam tieu de = thu gon. Keo cho trong / lan chuot = cuon.
 */
public class ClickGuiScreen extends Screen {
    private static final int HEAD_H = 16;
    private static final int ROW_H = 14;

    private static class Panel {
        Category cat;
        int x, y;
        boolean open = true;
        boolean placed;
    }

    private interface DragFn {
        void apply(double mx, double my);
    }

    private static class Hit {
        final int x, y, w, h;
        final Runnable left, right;
        final Setting.Num slider;
        final Panel panel; // != null: tieu de panel (keo duoc)
        DragFn drag;       // != null: vung keo (bang chon mau)

        Hit(int x, int y, int w, int h, Runnable left, Runnable right, Setting.Num slider, Panel panel) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
            this.right = right;
            this.slider = slider;
            this.panel = panel;
        }

        boolean in(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    // ---- Hieu ung set danh ----
    private static class Path {
        int[] xs, ys;
    }

    private static class Bolt {
        final List<Path> paths = new ArrayList<>();
        long born;
        int life;
    }

    private final List<Bolt> bolts = new ArrayList<>();
    private final Random rnd = new Random();
    private long nextBolt = 0;
    private long flashUntil = 0;

    private final List<Panel> panels = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private Module expanded;
    private Module listening;     // module dang cho bam phim de gan key
    private Setting.Text editing; // o chu dang nhap
    private Setting.KeyBind listeningBind; // o bind dang cho bam phim
    private Setting.NameList editingList; // danh sach ten dang nhap
    private int editIndex = -1;           // o ten dang nhap trong danh sach

    private double scroll;
    private int contentHeight;

    private Hit pressed;
    private int pressedButton;
    private double pressX, pressY;
    private boolean moved;
    private Hit sliderHit;
    private Hit dragHit;
    private Panel dragging;

    public ClickGuiScreen() {
        super(Text.literal(MyClient.NAME));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    protected void init() {
        if (panels.isEmpty()) {
            for (Category c : Category.values()) {
                if (ModuleManager.byCategory(c).isEmpty()) continue;
                Panel p = new Panel();
                p.cat = c;
                panels.add(p);
            }
        }
        int pw = panelWidth();
        int n = panels.size();
        int startX = Math.max(4, (width - (n * pw + (n - 1) * 4)) / 2);
        int i = 0;
        for (Panel p : panels) {
            if (!p.placed) {
                p.x = startX + i * (pw + 4);
                p.y = 30;
                p.placed = true;
            }
            p.x = Math.max(0, Math.min(width - pw, p.x));
            i++;
        }
    }

    private int panelWidth() {
        int n = Math.max(1, panels.size());
        int pw = (width - 12 - (n - 1) * 4) / n;
        return Math.max(78, Math.min(112, pw));
    }

    private void clampScroll() {
        double max = Math.max(0, contentHeight - height);
        scroll = Math.max(0, Math.min(max, scroll));
    }

    // =====================================================================
    //  RENDER
    // =====================================================================
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        ctx.fillGradient(0, 0, width, height, 0x90040A1C, 0x90010310);

        drawLightning(ctx);

        // Tieu de "Eclipse Client" o tren cung (cuon cung panel)
        int titleY = 7 - (int) scroll;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(width / 2f, titleY, 0f);
        ctx.getMatrices().scale(1.5f, 1.5f, 1f);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Eclipse Client").formatted(Formatting.BOLD), 0, 0, 0xFF000000 | (Theme.accent(0f) & 0xFFFFFF));
        ctx.getMatrices().pop();
        Draw.hGradient(ctx, width / 2 - 45, titleY + 17, 90, 1, Theme.alpha(Theme.ACCENT1, 0xFF), Theme.alpha(Theme.ACCENT2, 0xFF));

        int pw = panelWidth();
        int maxBottom = 0;
        int accent = Theme.accent(0f);

        for (Panel p : panels) {
            List<Module> list = ModuleManager.byCategory(p.cat);
            int px = p.x;
            int py = p.y - (int) scroll;

            int bodyH = 0;
            if (p.open) for (Module m : list) bodyH += moduleHeight(m);
            int totalH = HEAD_H + bodyH;

            Draw.rrect(ctx, px - 1, py - 1, pw + 2, totalH + 2, 3, Theme.alpha(accent, 0x70));
            Draw.rrect(ctx, px, py, pw, totalH, 3, 0xEA060E20);

            // Tieu de
            Draw.hGradient(ctx, px + 1, py + 1, pw - 2, HEAD_H - 2, Theme.alpha(Theme.ACCENT1, 0xD0), Theme.alpha(Theme.ACCENT2, 0x60));
            Text title = Text.literal(p.cat.label).setStyle(Style.EMPTY.withBold(true).withColor(0xFFFFFF));
            ctx.drawTextWithShadow(textRenderer, title, px + 6, py + 4, 0xFFFFFFFF);
            String ind = p.open ? "-" : "+";
            ctx.drawTextWithShadow(textRenderer, ind, px + pw - 10, py + 4, 0xFFDCEBFF);
            hits.add(new Hit(px, py, pw, HEAD_H, () -> p.open = !p.open, null, null, p));

            if (p.open) {
                int ry = py + HEAD_H;
                for (Module m : list) ry = drawModule(ctx, m, px, pw, ry, mx, my);
            }
            maxBottom = Math.max(maxBottom, p.y + totalH);
        }
        contentHeight = maxBottom + 24;
        clampScroll();

        String hint = "Left: toggle  |  Right: settings  |  Drag title: move  |  Eclipse > ClickGui: doi phim";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2, height - 11, 0xFF5B7399);

        Notifications.render(ctx, textRenderer, width, height);
    }

    // =====================================================================
    //  SET DANH (hieu ung nen)
    // =====================================================================
    private Path makePath(int x0, int y0, int step, int jitter, int count, int dirBias) {
        Path p = new Path();
        p.xs = new int[count];
        p.ys = new int[count];
        int x = x0;
        int y = y0;
        for (int i = 0; i < count; i++) {
            p.xs[i] = x;
            p.ys[i] = Math.min(height, y);
            x += rnd.nextInt(jitter * 2 + 1) - jitter + dirBias;
            x = Math.max(2, Math.min(width - 3, x));
            y += step + rnd.nextInt(Math.max(1, step / 2));
        }
        return p;
    }

    private Bolt makeBolt(int x0, long now) {
        Bolt b = new Bolt();
        b.born = now;
        b.life = 420 + rnd.nextInt(200);
        int step = 14;
        int count = height / step + 3;
        Path main = makePath(x0, 0, step, 9, count, 0);
        b.paths.add(main);
        int branches = 1 + rnd.nextInt(2);
        for (int k = 0; k < branches; k++) {
            int at = 3 + rnd.nextInt(Math.max(1, count - 8));
            int dir = rnd.nextBoolean() ? 6 : -6;
            b.paths.add(makePath(main.xs[at], main.ys[at], 11, 5, 5 + rnd.nextInt(5), dir));
        }
        return b;
    }

    private void drawLightning(DrawContext ctx) {
        long now = System.currentTimeMillis();
        if (now >= nextBolt) {
            int n = 1 + rnd.nextInt(2);
            for (int i = 0; i < n; i++) {
                bolts.add(makeBolt(20 + rnd.nextInt(Math.max(1, width - 40)), now));
            }
            nextBolt = now + 500 + rnd.nextInt(1100);
            flashUntil = now + 90;
        }
        bolts.removeIf(b -> now - b.born > b.life);

        if (now < flashUntil) ctx.fill(0, 0, width, height, 0x14BFD8FF);

        int glowRgb = Theme.ACCENT2 & 0xFFFFFF;
        for (Bolt b : bolts) {
            long age = now - b.born;
            float t = age / (float) b.life;
            float a = t < 0.15f ? 1f : Math.max(0f, 1f - (t - 0.15f) / 0.85f);
            if ((age / 50) % 3 == 1) a *= 0.55f; // nhap nhay
            int glowCol = ((int) (0x50 * a) << 24) | glowRgb;
            int coreCol = ((int) (0xFF * a) << 24) | 0xEAF4FF;
            int visY = (int) (height * Math.min(1f, age / 90f)); // set danh tu tren xuong
            for (Path p : b.paths) {
                for (int i = 0; i + 1 < p.xs.length; i++) {
                    int y1 = p.ys[i];
                    int y2 = p.ys[i + 1];
                    if (y1 > visY) break;
                    int x1 = p.xs[i];
                    int x2 = p.xs[i + 1];
                    int yEnd = Math.min(y2, visY);
                    for (int y = y1; y < yEnd; y += 2) {
                        int x = x1 + (x2 - x1) * (y - y1) / Math.max(1, y2 - y1);
                        ctx.fill(x - 2, y, x + 3, y + 2, glowCol);
                        ctx.fill(x, y, x + 1, y + 2, coreCol);
                    }
                }
            }
        }
    }

    private record VisibleSetting(Setting s, int indent) { }

    private static void collectVisible(List<VisibleSetting> out, List<Setting> list, int indent) {
        for (Setting s : list) {
            out.add(new VisibleSetting(s, indent));
            if (s instanceof Setting.Group g && g.open) collectVisible(out, g.children, indent + 1);
        }
    }

    private static List<VisibleSetting> visibleSettings(Module m) {
        List<VisibleSetting> out = new ArrayList<>();
        collectVisible(out, m.settings, 0);
        return out;
    }

    private int settingsHeight(Module m) {
        int total = 4;
        for (VisibleSetting vs : visibleSettings(m)) total += settingHeight(vs.s());
        return total + 14; // + dong Key
    }

    private int moduleHeight(Module m) {
        return ROW_H + (expanded == m ? settingsHeight(m) : 0);
    }

    private int drawModule(DrawContext ctx, Module m, int px, int pw, int ry, int mx, int my) {
        int accent = Theme.accent(0f);
        boolean on = m.isEnabled();
        boolean hover = mx >= px && mx < px + pw && my >= ry && my < ry + ROW_H;

        ctx.fill(px + 1, ry, px + pw - 1, ry + ROW_H, hover ? 0xE0132344 : 0xC80A1430);
        if (on) {
            Draw.hGradient(ctx, px + 1, ry, pw - 2, ROW_H, Theme.alpha(Theme.ACCENT1, 0xC0), Theme.alpha(Theme.ACCENT2, 0x38));
            ctx.fill(px + 1, ry, px + 3, ry + ROW_H, Theme.ACCENT2);
        }
        ctx.drawTextWithShadow(textRenderer, m.name, px + 7, ry + 3, on ? 0xFFFFFFFF : 0xFFA6B8D8);

        // Dau "..." mo setting
        int dx = px + pw - 14;
        int dc = expanded == m ? 0xFFFFFFFF : (on ? 0xFFCFE6FF : 0xFF5F7BA6);
        ctx.fill(dx, ry + 7, dx + 2, ry + 9, dc);
        ctx.fill(dx + 4, ry + 7, dx + 6, ry + 9, dc);
        ctx.fill(dx + 8, ry + 7, dx + 10, ry + 9, dc);

        Runnable toggleExpand = () -> {
            expanded = (expanded == m ? null : m);
            listening = null;
            editing = null;
            editingList = null;
        };
        hits.add(new Hit(px, ry, pw - 18, ROW_H, m::toggle, toggleExpand, null, null));
        hits.add(new Hit(px + pw - 18, ry, 18, ROW_H, toggleExpand, toggleExpand, null, null));
        ry += ROW_H;

        if (expanded != m) return ry;

        int total = settingsHeight(m);
        ctx.fill(px + 1, ry, px + pw - 1, ry + total, 0xE0050B1A);
        ctx.fillGradient(px + 1, ry, px + 3, ry + total, Theme.alpha(Theme.ACCENT2, 0xC0), Theme.alpha(Theme.ACCENT1, 0x60));

        int bx0 = px + 6;
        int bw0 = pw - 11;
        int sy = ry + 3;
        for (VisibleSetting vs : visibleSettings(m)) {
            Setting s = vs.s();
            final int bx = bx0 + vs.indent() * 8;
            final int bw = bw0 - vs.indent() * 8;
            if (s instanceof Setting.Group g) {
                ctx.fill(bx, sy, bx + bw, sy + 12, 0xFF0B1630);
                Draw.outline(ctx, bx, sy, bw, 12, g.open ? Theme.alpha(accent, 0xFF) : 0xFF22345C);
                String arrow = g.open ? "v " : "> ";
                ctx.drawTextWithShadow(textRenderer, arrow + g.name, bx + 3, sy + 2,
                        g.hasToggle && !g.enabled ? 0xFF7F93B8 : 0xFFFFFFFF);
                if (g.hasToggle) {
                    int cx = bx + bw - 12;
                    int cy = sy + 1;
                    ctx.fill(cx, cy, cx + 9, cy + 9, g.enabled ? Theme.alpha(accent, 0xFF) : 0xFF1E2C4A);
                    Draw.outline(ctx, cx, cy, 9, 9, g.enabled ? 0xFFBFE6FF : 0xFF3A5280);
                    if (g.enabled) Draw.check(ctx, cx + 1, cy + 2, 0xFFFFFFFF);
                }
                Runnable toggleOpen = () -> g.open = !g.open;
                hits.add(new Hit(bx, sy, bw, 13, g.hasToggle ? () -> g.enabled = !g.enabled : toggleOpen, toggleOpen, null, null));
                sy += 14;
            } else if (s instanceof Setting.Bool b) {
                ctx.drawTextWithShadow(textRenderer, b.name, bx + 2, sy + 2, 0xFFB8CBE8);
                int cx = bx + bw - 11;
                int cy = sy + 2;
                ctx.fill(cx, cy, cx + 9, cy + 9, b.value ? Theme.alpha(accent, 0xFF) : 0xFF1E2C4A);
                Draw.outline(ctx, cx, cy, 9, 9, b.value ? 0xFFBFE6FF : 0xFF3A5280);
                if (b.value) Draw.check(ctx, cx + 1, cy + 2, 0xFFFFFFFF);
                hits.add(new Hit(bx, sy, bw, 13, () -> b.value = !b.value, null, null, null));
                sy += 13;
            } else if (s instanceof Setting.Num n) {
                ctx.drawTextWithShadow(textRenderer, n.name, bx + 2, sy + 1, 0xFFB8CBE8);
                String v = n.display();
                ctx.drawTextWithShadow(textRenderer, v, bx + bw - 2 - textRenderer.getWidth(v), sy + 1, 0xFFFFFFFF);
                int barX = bx + 2;
                int barW = bw - 4;
                int barY = sy + 12;
                ctx.fill(barX, barY, barX + barW, barY + 3, 0xFF16264A);
                int fillW = (int) (barW * n.fraction());
                if (fillW > 0) Draw.hGradient(ctx, barX, barY, fillW, 3, Theme.ACCENT1, Theme.ACCENT2);
                ctx.fill(barX + fillW - 2, barY - 2, barX + fillW + 2, barY + 5, 0xFFFFFFFF);
                hits.add(new Hit(barX, sy + 9, barW, 11, null, null, n, null));
                sy += 20;
            } else if (s instanceof Setting.Text tx) {
                ctx.drawTextWithShadow(textRenderer, tx.name, bx + 2, sy + 1, 0xFFB8CBE8);
                int boxX = bx + 2;
                int boxW = bw - 4;
                int boxY = sy + 11;
                boolean ed = editing == tx;
                ctx.fill(boxX, boxY, boxX + boxW, boxY + 11, 0xFF0B1630);
                Draw.outline(ctx, boxX, boxY, boxW, 11, ed ? Theme.alpha(accent, 0xFF) : 0xFF22345C);
                String cur = (ed && (System.currentTimeMillis() / 450) % 2 == 0) ? "_" : "";
                if (tx.value.isEmpty() && !ed) {
                    ctx.drawTextWithShadow(textRenderer, "tap to type", boxX + 3, boxY + 2, 0xFF4B6690);
                } else {
                    String disp = tx.value;
                    while (disp.length() > 1 && textRenderer.getWidth(disp + cur) > boxW - 6) disp = disp.substring(1);
                    ctx.drawTextWithShadow(textRenderer, disp + cur, boxX + 3, boxY + 2, 0xFFFFFFFF);
                }
                hits.add(new Hit(bx, sy, bw, 24, () -> {
                    listening = null;
                    editingList = null;
                    editing = (editing == tx ? null : tx);
                }, null, null, null));
                sy += 24;
            } else if (s instanceof Setting.NameList nl) {
                ctx.drawTextWithShadow(textRenderer, nl.name, bx + 2, sy + 1, 0xFFB8CBE8);
                int rowY = sy + 11;
                int boxX = bx + 2;
                int btnW = 12;
                int boxW = bw - 4 - btnW - 3;
                boolean blink = (System.currentTimeMillis() / 450) % 2 == 0;
                for (int i = 0; i < nl.names.size(); i++) {
                    final int idx = i;
                    boolean ed = editingList == nl && editIndex == idx;
                    ctx.fill(boxX, rowY, boxX + boxW, rowY + 12, 0xFF0B1630);
                    Draw.outline(ctx, boxX, rowY, boxW, 12, ed ? Theme.alpha(accent, 0xFF) : 0xFF22345C);
                    String nm = nl.names.get(idx);
                    String cur = (ed && blink) ? "_" : "";
                    if (nm.isEmpty() && !ed) {
                        ctx.drawTextWithShadow(textRenderer, "name", boxX + 3, rowY + 2, 0xFF4B6690);
                    } else {
                        String disp = nm;
                        while (disp.length() > 1 && textRenderer.getWidth(disp + cur) > boxW - 6) disp = disp.substring(1);
                        ctx.drawTextWithShadow(textRenderer, disp + cur, boxX + 3, rowY + 2, 0xFFFFFFFF);
                    }
                    hits.add(new Hit(boxX, rowY, boxW, 12, () -> {
                        listening = null;
                        editing = null;
                        editingList = nl;
                        editIndex = idx;
                    }, null, null, null));

                    // nut "-" xoa o nay
                    int minX = boxX + boxW + 3;
                    ctx.fill(minX, rowY, minX + btnW, rowY + 12, 0xFF5A1F2E);
                    Draw.outline(ctx, minX, rowY, btnW, 12, 0xFFB0405A);
                    ctx.fill(minX + 3, rowY + 5, minX + btnW - 3, rowY + 7, 0xFFFFFFFF);
                    hits.add(new Hit(minX, rowY, btnW, 12, () -> {
                        if (idx < nl.names.size()) nl.names.remove(idx);
                        if (editingList == nl) {
                            if (editIndex == idx) editingList = null;
                            else if (editIndex > idx) editIndex--;
                        }
                    }, null, null, null));
                    rowY += 14;
                }
                // nut "+ Add" duoi cung
                int addW = bw - 4;
                ctx.fill(boxX, rowY, boxX + addW, rowY + 12, 0xFF16264A);
                Draw.outline(ctx, boxX, rowY, addW, 12, Theme.alpha(accent, 0xFF));
                ctx.drawCenteredTextWithShadow(textRenderer, "+ Add", boxX + addW / 2, rowY + 2, 0xFFFFFFFF);
                hits.add(new Hit(boxX, rowY, addW, 12, () -> {
                    if (nl.names.size() >= nl.maxNames) return;
                    nl.names.add("");
                    listening = null;
                    editing = null;
                    editingList = nl;
                    editIndex = nl.names.size() - 1;
                }, null, null, null));
                sy += settingHeight(s);
            } else if (s instanceof Setting.Color c) {
                ctx.drawTextWithShadow(textRenderer, c.name, bx + 2, sy + 3, 0xFFB8CBE8);
                int sw = 24;
                int swx = bx + bw - sw - 1;
                ctx.fill(swx, sy + 1, swx + sw, sy + 12, 0xFF0B1630);
                ctx.fill(swx, sy + 1, swx + sw, sy + 12, c.argb());
                Draw.outline(ctx, swx, sy + 1, sw, 11, c.open ? Theme.alpha(accent, 0xFF) : 0xFF3A5280);
                Runnable toggleColor = () -> c.open = !c.open;
                hits.add(new Hit(bx, sy, bw, 13, toggleColor, toggleColor, null, null));
                sy += 13;
                if (c.open) {
                    final int px0 = bx + 2;
                    final int pw0 = bw - 4;
                    final int svH = 40;
                    final int svY = sy;
                    int hueCol = 0xFF000000 | (MathHelper.hsvToRgb(c.hue, 1f, 1f) & 0xFFFFFF);
                    Draw.hGradient(ctx, px0, svY, pw0, svH, 0xFFFFFFFF, hueCol);
                    ctx.fillGradient(px0, svY, px0 + pw0, svY + svH, 0x00000000, 0xFF000000);
                    int mx0 = px0 + (int) (c.sat * (pw0 - 1));
                    int my0 = svY + (int) ((1f - c.val) * (svH - 1));
                    Draw.outline(ctx, mx0 - 2, my0 - 2, 5, 5, 0xFFFFFFFF);
                    Hit h1 = new Hit(px0, svY, pw0, svH, null, null, null, null);
                    h1.drag = (mxx, myy) -> {
                        c.sat = (float) Math.max(0.0, Math.min(1.0, (mxx - px0) / (double) pw0));
                        c.val = 1f - (float) Math.max(0.0, Math.min(1.0, (myy - svY) / (double) svH));
                    };
                    hits.add(h1);
                    sy += svH + 3;

                    final int hueY = sy;
                    for (int i = 0; i < pw0; i++) {
                        ctx.fill(px0 + i, hueY, px0 + i + 1, hueY + 8,
                                0xFF000000 | (MathHelper.hsvToRgb(i / (float) pw0, 1f, 1f) & 0xFFFFFF));
                    }
                    int hx = px0 + (int) (c.hue * (pw0 - 1));
                    ctx.fill(hx - 1, hueY - 1, hx + 2, hueY + 9, 0xFFFFFFFF);
                    Hit h2 = new Hit(px0, hueY, pw0, 8, null, null, null, null);
                    h2.drag = (mxx, myy) -> c.hue = (float) Math.max(0.0, Math.min(0.999, (mxx - px0) / (double) pw0));
                    hits.add(h2);
                    sy += 11;

                    final int alY = sy;
                    int rgbOnly = MathHelper.hsvToRgb(c.hue, c.sat, c.val) & 0xFFFFFF;
                    for (int i = 0; i < pw0; i += 4) {
                        ctx.fill(px0 + i, alY, Math.min(px0 + i + 4, px0 + pw0), alY + 8, ((i / 4) % 2 == 0) ? 0xFF5A6478 : 0xFF2A3246);
                    }
                    for (int i = 0; i < pw0; i++) {
                        int a = Math.round(255f * i / (pw0 - 1));
                        ctx.fill(px0 + i, alY, px0 + i + 1, alY + 8, (a << 24) | rgbOnly);
                    }
                    int ax = px0 + (int) (c.alpha * (pw0 - 1));
                    ctx.fill(ax - 1, alY - 1, ax + 2, alY + 9, 0xFFFFFFFF);
                    Hit h3 = new Hit(px0, alY, pw0, 8, null, null, null, null);
                    h3.drag = (mxx, myy) -> c.alpha = (float) Math.max(0.0, Math.min(1.0, (mxx - px0) / (double) pw0));
                    hits.add(h3);
                    sy += 11;
                }
            } else if (s instanceof Setting.KeyBind kb) {
                ctx.drawTextWithShadow(textRenderer, kb.name, bx + 2, sy + 3, 0xFFB8CBE8);
                boolean lisB = listeningBind == kb;
                String bt = lisB ? "..." : (kb.key < 0 ? "None" : keyName(kb.key));
                int bww = textRenderer.getWidth(bt) + 10;
                int bbx = bx + bw - bww - 1;
                ctx.fill(bbx, sy + 1, bbx + bww, sy + 12, lisB ? Theme.alpha(accent, 0x90) : 0xFF16264A);
                ctx.drawCenteredTextWithShadow(textRenderer, bt, bbx + bww / 2, sy + 3, 0xFFFFFFFF);
                hits.add(new Hit(bx, sy, bw, 13, () -> {
                    editing = null;
                    editingList = null;
                    listening = null;
                    listeningBind = (listeningBind == kb ? null : kb);
                }, null, null, null));
                sy += settingHeight(s);
            }
        }

        // Dong gan phim
        int bx = bx0;
        int bw = bw0;
        ctx.drawTextWithShadow(textRenderer, "Key", bx + 2, sy + 3, 0xFFB8CBE8);
        boolean lis = listening == m;
        String kt = lis ? "..." : (m.key < 0 ? "None" : keyName(m.key));
        int kw = textRenderer.getWidth(kt) + 10;
        int kbx = bx + bw - kw - 1;
        ctx.fill(kbx, sy + 1, kbx + kw, sy + 12, lis ? Theme.alpha(accent, 0x90) : 0xFF16264A);
        ctx.drawCenteredTextWithShadow(textRenderer, kt, kbx + kw / 2, sy + 3, 0xFFFFFFFF);
        hits.add(new Hit(bx, sy, bw, 13, () -> {
            editing = null;
            listening = (listening == m ? null : m);
        }, null, null, null));

        return ry + total;
    }

    private static int settingHeight(Setting s) {
        if (s instanceof Setting.Num) return 20;
        if (s instanceof Setting.Text) return 24;
        if (s instanceof Setting.Group) return 14;
        if (s instanceof Setting.Color c) return c.open ? 13 + 40 + 3 + 11 + 11 : 13;
        if (s instanceof Setting.NameList nl) return 11 + nl.names.size() * 14 + 14;
        return 13;
    }

    private static String keyName(int code) {
        return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString();
    }

    private void applySlider(Hit hit, double mx) {
        hit.slider.setFraction((mx - hit.x) / (double) hit.w);
    }

    // =====================================================================
    //  INPUT
    // =====================================================================
    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (editing != null) {
            if (chr >= 32 && chr != 127 && editing.value.length() < editing.max) editing.value += chr;
            return true;
        }
        if (editingList != null && editIndex >= 0 && editIndex < editingList.names.size()) {
            String cur = editingList.names.get(editIndex);
            if ((Character.isLetterOrDigit(chr) || chr == '_') && cur.length() < 16) {
                editingList.names.set(editIndex, cur + chr);
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        pressX = mx;
        pressY = my;
        moved = false;
        pressed = null;
        dragging = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (!hit.in(mx, my)) continue;
            if (hit.slider != null) {
                if (button == 0) {
                    sliderHit = hit;
                    applySlider(hit, mx);
                }
                return true;
            }
            if (hit.drag != null) {
                if (button == 0) {
                    dragHit = hit;
                    hit.drag.apply(mx, my);
                }
                return true;
            }
            pressed = hit;
            pressedButton = button;
            if (hit.panel != null && button == 0) dragging = hit.panel;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliderHit != null) {
            applySlider(sliderHit, mx);
            return true;
        }
        if (dragHit != null) {
            dragHit.drag.apply(mx, my);
            return true;
        }
        if (Math.abs(my - pressY) > 4 || Math.abs(mx - pressX) > 4) moved = true;
        if (!moved) return true;
        if (dragging != null) {
            int pw = panelWidth();
            dragging.x = (int) Math.max(0, Math.min(width - pw, dragging.x + dx));
            dragging.y = (int) Math.max(0, dragging.y + dy);
        } else {
            scroll -= dy;
            clampScroll();
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliderHit != null) {
            sliderHit = null;
            Config.save();
            return true;
        }
        if (dragHit != null) {
            dragHit = null;
            Config.save();
            return true;
        }
        if (pressed != null && !moved) {
            Runnable r = pressedButton == 0 ? pressed.left : (pressedButton == 1 ? pressed.right : null);
            if (r != null) {
                r.run();
                Config.save();
            }
        }
        pressed = null;
        dragging = null;
        moved = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll -= vAmount * 14;
        clampScroll();
        return true;
    }

    @Override
    public void removed() {
        editing = null;
        listeningBind = null;
        editingList = null;
        Config.save();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (editingList != null) {
            if (editIndex < 0 || editIndex >= editingList.names.size()) {
                editingList = null;
            } else {
                String cur = editingList.names.get(editIndex);
                if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                    editingList = null;
                    Config.save();
                } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                    if (!cur.isEmpty()) editingList.names.set(editIndex, cur.substring(0, cur.length() - 1));
                } else if (Screen.isPaste(keyCode)) {
                    String clip = this.client.keyboard.getClipboard();
                    StringBuilder sb = new StringBuilder(cur);
                    for (char ch : clip.toCharArray()) {
                        if ((Character.isLetterOrDigit(ch) || ch == '_') && sb.length() < 16) sb.append(ch);
                    }
                    editingList.names.set(editIndex, sb.toString());
                }
                return true;
            }
        }
        if (editing != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                editing = null;
                Config.save();
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!editing.value.isEmpty()) editing.value = editing.value.substring(0, editing.value.length() - 1);
            } else if (Screen.isPaste(keyCode)) {
                String clip = this.client.keyboard.getClipboard();
                StringBuilder sb = new StringBuilder(editing.value);
                for (char ch : clip.toCharArray()) {
                    if (ch >= 32 && ch != 127 && sb.length() < editing.max) sb.append(ch);
                }
                editing.value = sb.toString();
            }
            return true;
        }
        if (listeningBind != null) {
            // ESC = bo bind, phim khac = gan
            listeningBind.key = (keyCode == GLFW.GLFW_KEY_ESCAPE) ? -1 : keyCode;
            listeningBind = null;
            Config.save();
            return true;
        }
        if (listening != null) {
            // ESC = reset key, phim khac = gan key
            listening.key = (keyCode == GLFW.GLFW_KEY_ESCAPE) ? -1 : keyCode;
            listening = null;
            Config.save();
            return true;
        }
        ClickGui cg = ModuleManager.get(ClickGui.class);
        int closeKey = cg != null && cg.key >= 0 ? cg.key : GLFW.GLFW_KEY_RIGHT_SHIFT;
        if (keyCode == closeKey) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
