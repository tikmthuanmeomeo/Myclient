package com.myclient.gui;

import com.myclient.MyClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * Thong bao bat/tat module trong chat: "[Eclipse] [+] Ten" (xanh) / "[Eclipse] [-] Ten" (do).
 * Moi module chi giu 1 dong: bat/tat lai thi dong cu bi go va dong moi hien o cuoi.
 */
public final class ChatNotify {
    private ChatNotify() { }

    public static void toggle(String module, boolean on) {
        if (Notifications.muted) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.inGameHud == null || mc.world == null) return;
        ChatHud chat = mc.inGameHud.getChatHud();

        MessageSignatureData sig = signatureFor(module);
        chat.removeMessage(sig);

        MutableText msg = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal(MyClient.NAME).setStyle(Style.EMPTY.withColor(0x4D8BFF)))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(Text.literal("[").formatted(Formatting.GRAY))
                .append(Text.literal(on ? "+" : "-").formatted(on ? Formatting.GREEN : Formatting.RED))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(Text.literal(module).formatted(Formatting.WHITE));
        chat.addMessage(msg, sig, null);
    }

    /** Chu ky gia (256 byte) co dinh theo ten module, de go dung dong cu. */
    private static MessageSignatureData signatureFor(String module) {
        byte[] bytes = new byte[256];
        byte[] name = ("eclipse-toggle:" + module).getBytes(StandardCharsets.UTF_8);
        Arrays.fill(bytes, (byte) 7);
        System.arraycopy(name, 0, bytes, 0, Math.min(name.length, 256));
        return new MessageSignatureData(bytes);
    }
}
