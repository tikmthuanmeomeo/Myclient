package com.myclient.gui;

import com.myclient.MyClient;
import com.myclient.mixin.ChatHudAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;

/**
 * Thong bao bat/tat module trong chat: "[Flux] [+] Ten" (xanh) / "[Flux] [-] Ten" (do).
 * Moi module chi giu 1 dong: bat/tat lai thi dong cu bi xoa han (khong de lai dong "deleted by the server").
 */
public final class ChatNotify {
    private ChatNotify() { }

    /** Dong thong bao gan nhat cua tung module (de xoa khi co dong moi). */
    private static final Map<String, Text> LAST = new HashMap<>();

    public static void toggle(String module, boolean on) {
        if (Notifications.muted) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.inGameHud == null || mc.world == null) return;
        ChatHud chat = mc.inGameHud.getChatHud();

        MutableText msg = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal(MyClient.NAME).setStyle(Style.EMPTY.withColor(0x4D8BFF)))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(Text.literal("[").formatted(Formatting.GRAY))
                .append(Text.literal(on ? "+" : "-").formatted(on ? Formatting.GREEN : Formatting.RED))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(Text.literal(module).formatted(Formatting.WHITE));

        Text prev = LAST.put(module, msg);
        if (prev != null) {
            ChatHudAccessor acc = (ChatHudAccessor) chat;
            // Xoa han dong cu khoi danh sach chat (khong dung removeMessage vi no de lai "deleted by the server")
            if (acc.flux$getMessages().removeIf(line -> line.content() == prev)) {
                acc.flux$refresh();
            }
        }
        chat.addMessage(msg);
    }
}
