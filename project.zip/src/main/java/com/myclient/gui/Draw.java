package com.myclient.gui;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    /** Hinh chu nhat bo goc (r nho, 2-4 px). */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x + r, y, x + w - r, y + h, col);
        c.fill(x, y + r, x + r, y + h - r, col);
        c.fill(x + w - r, y + r, x + w, y + h - r, col);
        if (r >= 2) {
            c.fill(x + 1, y + 1, x + r, y + r, col);
            c.fill(x + w - r, y + 1, x + w - 1, y + r, col);
            c.fill(x + 1, y + h - r, x + r, y + h - 1, col);
            c.fill(x + w - r, y + h - r, x + w - 1, y + h - 1, col);
        }
    }

    /** Gradient ngang tu c1 sang c2. */
    public static void hGradient(DrawContext c, int x, int y, int w, int h, int c1, int c2) {
        if (w <= 0) return;
        int step = 2;
        for (int i = 0; i < w; i += step) {
            int sw = Math.min(step, w - i);
            c.fill(x + i, y, x + i + sw, y + h, Theme.lerp(c1, c2, i / (float) w));
        }
    }
}
