package com.myclient.gui;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    /** Hinh chu nhat bo goc tron that su (ban kinh r bat ky). */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt((double) r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, col);
        }
    }

    /** Gradient ngang tu c1 sang c2. */
    public static void hGradient(DrawContext c, int x, int y, int w, int h, int c1, int c2) {
        if (w <= 0) return;
        int step = 2;
        for (int i = 0; i < w; i += step) {
            int sw = Math.min(step, w - i);
            c.fill(x + i, y, x + i + sw, y + h, Theme.lerp(c1, c2, i / (float) w));
        }
    }

    /** Duong sang chay (shimmer) mo dan o hai dau. */
    public static void shimmerLine(DrawContext c, int x, int y, int w, int h, long now) {
        if (w <= 0) return;
        for (int i = 0; i < w; i += 2) {
            float wave = (float) (Math.sin(i * 0.045 - now * 0.004) * 0.5 + 0.5);
            int col = Theme.lerp(Theme.ACCENT1, Theme.ACCENT2, wave);
            float edge = Math.min(1f, Math.min(i, w - i) / (w * 0.22f));
            int a = (int) (60 + 195 * edge * (0.55f + 0.45f * wave));
            c.fill(x + i, y, x + Math.min(i + 2, w), y + h, Theme.alpha(col, a));
        }
    }

    /** Hao quang mem quanh mot hinh bo goc. */
    public static void glow(DrawContext c, int x, int y, int w, int h, int r, int rgb, int layers, int alphaPerLayer) {
        for (int k = layers; k >= 1; k--) {
            rrect(c, x - k, y - k, w + 2 * k, h + 2 * k, r + k, Theme.alpha(rgb, alphaPerLayer));
        }
    }

    /** Vien chu nhat 1px. */
    public static void outline(DrawContext c, int x, int y, int w, int h, int col) {
        c.fill(x, y, x + w, y + 1, col);
        c.fill(x, y + h - 1, x + w, y + h, col);
        c.fill(x, y, x + 1, y + h, col);
        c.fill(x + w - 1, y, x + w, y + h, col);
    }

    /** Hinh tron dac (quet theo dong). */
    public static void circle(DrawContext c, int cx, int cy, int r, int col) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            c.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, col);
        }
    }

    /** Vong sang mem: 4 lop tron chong len nhau, layerAlpha nho (0x08-0x18). */
    public static void glow(DrawContext c, int cx, int cy, int r, int rgb, int layerAlpha) {
        for (int k = 0; k < 4; k++) {
            int rr = Math.max(1, r * (4 - k) / 4);
            circle(c, cx, cy, rr, Theme.alpha(rgb, layerAlpha));
        }
    }

    /** Ngoi sao lap lanh 4 canh. */
    public static void sparkle(DrawContext c, int x, int y, int s, int col) {
        c.fill(x - s, y, x + s + 1, y + 1, col);
        c.fill(x, y - s, x + 1, y + s + 1, col);
        c.fill(x, y, x + 1, y + 1, Theme.alpha(0xFFFFFF, col >>> 24));
    }

    /** Dau tich (khoang 10x8). */
    public static void check(DrawContext c, int x, int y, int col) {
        int[][] p = {{0, 4}, {1, 5}, {2, 6}, {3, 5}, {4, 4}, {5, 3}, {6, 2}, {7, 1}, {8, 0}};
        for (int[] q : p) c.fill(x + q[0], y + q[1], x + q[0] + 2, y + q[1] + 2, col);
    }

    /** Dau X (khoang 9x9). */
    public static void cross(DrawContext c, int x, int y, int col) {
        for (int i = 0; i < 8; i++) {
            c.fill(x + i, y + i, x + i + 2, y + i + 2, col);
            c.fill(x + 7 - i, y + i, x + 9 - i, y + i + 2, col);
        }
    }
}
