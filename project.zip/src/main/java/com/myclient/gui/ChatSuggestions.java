package com.myclient.gui;

import com.myclient.module.Friends;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Goi y lenh khi go "#" trong chat (giong goi y /lenh cua Minecraft): bam vao goi y de dien vao o chat.
 *   #           -> friend
 *   #friend     -> add, remove, list
 *   #friend add -> ten nguoi choi dang online
 *   #friend remove -> ten ban be dang co
 */
public final class ChatSuggestions {
    private record Rect(int x, int y, int w, int h, String value) { }

    private static final List<Rect> RECTS = new ArrayList<>();
    private static final int ROW_H = 12;

    private ChatSuggestions() { }

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof ChatScreen)) return;
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> render(s, ctx));
            ScreenMouseEvents.allowMouseClick(screen).register((s, mx, my, button) -> !click(s, mx, my, button));
            ScreenKeyboardEvents.allowKeyPress(screen).register((s, key, scancode, mods) -> !tab(s, key));
            ScreenEvents.remove(screen).register(s -> RECTS.clear());
        });
    }

    private static TextFieldWidget field(Screen s) {
        for (Element e : s.children()) {
            if (e instanceof TextFieldWidget tf) return tf;
        }
        return null;
    }

    /** [0] = phan dang go do dang (partial), con lai = goi y. */
    private static List<String> suggestions(String text, String[] partialOut) {
        List<String> out = new ArrayList<>();
        partialOut[0] = "";
        if (!text.startsWith("#")) return out;
        String body = text.substring(1);
        boolean trailing = body.endsWith(" ");
        String[] toks = body.trim().isEmpty() ? new String[0] : body.trim().split("\\s+");

        int idx;
        String partial;
        if (toks.length == 0) {
            idx = 0;
            partial = "";
        } else if (trailing) {
            idx = toks.length;
            partial = "";
        } else {
            idx = toks.length - 1;
            partial = toks[toks.length - 1];
        }
        partialOut[0] = partial;

        List<String> pool = new ArrayList<>();
        boolean isFriendCmd = toks.length >= 1 && (toks[0].equalsIgnoreCase("friend") || toks[0].equalsIgnoreCase("friends"));
        if (idx == 0) {
            pool.add("friend");
        } else if (idx == 1 && isFriendCmd) {
            pool.add("add");
            pool.add("remove");
            pool.add("list");
        } else if (idx == 2 && isFriendCmd && toks.length >= 2) {
            String sub = toks[1].toLowerCase(Locale.ROOT);
            if (sub.equals("add")) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.getNetworkHandler() != null) {
                    List<String> names = new ArrayList<>();
                    for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                        String n = e.getProfile().getName();
                        if (mc.player != null && n.equalsIgnoreCase(mc.player.getName().getString())) continue;
                        if (Friends.isFriend(n)) continue;
                        names.add(n);
                    }
                    names.sort(Comparator.comparing(String::toLowerCase));
                    pool.addAll(names);
                }
            } else if (sub.equals("remove") || sub.equals("del") || sub.equals("delete")) {
                pool.addAll(Friends.all());
            }
        }

        String lp = partial.toLowerCase(Locale.ROOT);
        for (String c : pool) {
            if (c.toLowerCase(Locale.ROOT).startsWith(lp)) out.add(c);
            if (out.size() >= 10) break;
        }
        return out;
    }

    private static void render(Screen s, DrawContext ctx) {
        RECTS.clear();
        TextFieldWidget f = field(s);
        if (f == null) return;
        String[] partial = new String[1];
        List<String> list = suggestions(f.getText(), partial);
        if (list.isEmpty()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        int w = 0;
        for (String c : list) w = Math.max(w, mc.textRenderer.getWidth(c));
        w += 8;
        // khung nam ngay duoi vi tri chu dang go (di theo con tro) nhu goi y lenh cua Minecraft
        String text = f.getText();
        String prefixText = text.substring(0, Math.max(0, text.length() - partial[0].length()));
        int x = f.getX() + mc.textRenderer.getWidth(prefixText) - 1;
        x = Math.max(2, Math.min(x, s.width - w - 2));
        int y = s.height - 14 - ROW_H * list.size() - 2;
        for (int i = 0; i < list.size(); i++) {
            String c = list.get(i);
            int ry = y + i * ROW_H;
            ctx.fill(x, ry, x + w, ry + ROW_H, 0xE0000000);
            ctx.drawTextWithShadow(mc.textRenderer, c, x + 4, ry + 2, i == 0 ? 0xFFFFFF55 : 0xFFAAAAAA);
            RECTS.add(new Rect(x, ry, w, ROW_H, c));
        }
    }

    private static void apply(Screen s, String value) {
        TextFieldWidget f = field(s);
        if (f == null) return;
        String[] partial = new String[1];
        suggestions(f.getText(), partial);
        String text = f.getText();
        String prefix = text.substring(0, text.length() - partial[0].length());
        boolean more = value.equals("friend") || value.equals("add") || value.equals("remove");
        f.setText(prefix + value + (more ? " " : ""));
    }

    private static boolean click(Screen s, double mx, double my, int button) {
        if (button != 0) return false;
        for (Rect r : RECTS) {
            if (mx >= r.x() && mx < r.x() + r.w() && my >= r.y() && my < r.y() + r.h()) {
                apply(s, r.value());
                return true;
            }
        }
        return false;
    }

    private static boolean tab(Screen s, int key) {
        if (key != GLFW.GLFW_KEY_TAB || RECTS.isEmpty()) return false;
        apply(s, RECTS.get(0).value());
        return true;
    }
}
