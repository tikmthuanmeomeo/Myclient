package com.myclient.gui;

public final class Theme {
    public static final int ACCENT1 = 0xFF3B82F6; // xanh duong
    public static final int ACCENT2 = 0xFF22D3EE; // cyan
    public static final int ACCENT3 = 0xFF8B5CF6; // tim (diem nhan huyen ao)

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    /** Mau accent chuyen dong cham giua xanh duong va cyan. */
    public static int accent(float phase) {
        float t = (float) (Math.sin(System.currentTimeMillis() / 700.0 + phase) * 0.5 + 0.5);
        return lerp(ACCENT1, ACCENT2, t);
    }

    public static int alpha(int color, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (color & 0xFFFFFF);
    }
}
