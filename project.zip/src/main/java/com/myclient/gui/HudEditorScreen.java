package com.myclient.gui;

import com.myclient.config.Config;
import com.myclient.hud.HudElement;
import com.myclient.module.ModuleManager;
import com.myclient.module.impl.HudModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Mo bang phim T: giu chuot trai len phan HUD de keo di chuyen. */
public class HudEditorScreen extends Screen {
    private HudElement dragging;
    private int offX, offY;
    private boolean armed; // chi dong bang T sau khi da tha phim T lan dau

    public HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private List<HudElement> active() {
        List<HudElement> out = new ArrayList<>();
        HudModule hm = ModuleManager.get(HudModule.class);
        if (hm != null && hm.isEnabled()) {
            for (HudElement e : hm.elements()) if (e.toggle.value) out.add(e);
        }
        return out;
    }

    private void clamp(HudElement e) {
        e.x = Math.max(0, Math.min(e.x, width - e.w(true)));
        e.y = Math.max(0, Math.min(e.y, height - e.h(true)));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x70000000);
        int acc = Theme.accent(0f);
        List<HudElement> list = active();
        String hint = list.isEmpty()
                ? "Enable the HUD module and its toggles first"
                : "Hold left click to drag  |  T / ESC to close";
        ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2, 8, 0xFFFFFFFF);

        for (HudElement e : list) {
            clamp(e);
            int w = e.w(true);
            int h = e.h(true);
            e.draw(ctx, e.x, e.y, true);
            boolean hover = mx >= e.x && mx < e.x + w && my >= e.y && my < e.y + h;
            Draw.outline(ctx, e.x - 1, e.y - 1, w + 2, h + 2,
                    e == dragging ? 0xFFFFFFFF : (hover ? acc : Theme.alpha(acc, 0x90)));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            List<HudElement> list = active();
            for (int i = list.size() - 1; i >= 0; i--) {
                HudElement e = list.get(i);
                if (mx >= e.x && mx < e.x + e.w(true) && my >= e.y && my < e.y + e.h(true)) {
                    dragging = e;
                    offX = (int) mx - e.x;
                    offY = (int) my - e.y;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.x = (int) mx - offX;
            dragging.y = (int) my - offY;
            clamp(dragging);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_T) armed = true;
        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_T && armed) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
    }
}
