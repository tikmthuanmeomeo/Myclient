package com.myclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Khung thong bao goc duoi ben phai: ten chuc nang + dau tich (bat) / dau X (tat). */
public final class Notifications {
    private static class Toast {
        String text;
        Boolean on; // true = bat, false = tat, null = thong bao thuong
        long born;
    }

    private static final List<Toast> TOASTS = new ArrayList<>();
    private static final long LIFE = 2300;
    private static final long IN = 260;
    private static final long OUT = 320;

    /** Bat khi dang load config de khong hien thong bao luc khoi dong. */
    public static boolean muted;

    public static void push(String text, Boolean on) {
        if (muted) return;
        TOASTS.removeIf(t -> t.text.equals(text));
        Toast t = new Toast();
        t.text = text;
        t.on = on;
        t.born = System.currentTimeMillis();
        TOASTS.add(t);
        while (TOASTS.size() > 5) TOASTS.remove(0);
    }

    public static void render(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        if (TOASTS.isEmpty()) return;
        long now = System.currentTimeMillis();
        TOASTS.removeIf(t -> now - t.born > LIFE);

        int baseY = sh - 8;
        for (int i = TOASTS.size() - 1; i >= 0; i--) {
            Toast t = TOASTS.get(i);
            long age = now - t.born;
            int w = tr.getWidth(t.text) + 38;
            int h = 20;
            int y = baseY - h;
            baseY = y - 4;

            double slide;
            if (age < IN) {
                double p = age / (double) IN;
                slide = 1.0 - (1.0 - Math.pow(1.0 - p, 3));      // 1 -> 0 (truot vao)
            } else if (age > LIFE - OUT) {
                double p = (age - (LIFE - OUT)) / (double) OUT;
                slide = p * p;                                     // 0 -> 1 (truot ra)
            } else {
                slide = 0.0;
            }
            int x = sw - w - 6 + (int) (slide * (w + 12));

            int col = t.on == null ? 0xFF3B82F6 : (t.on ? 0xFF55FF77 : 0xFFFF5566);
            Draw.rrect(ctx, x - 1, y - 1, w + 2, h + 2, 4, Theme.alpha(col, 0x40));
            Draw.rrect(ctx, x, y, w, h, 3, 0xF00A1226);
            ctx.fill(x, y + 3, x + 2, y + h - 3, col);

            if (t.on != null) {
                if (t.on) Draw.check(ctx, x + 9, y + 6, col);
                else Draw.cross(ctx, x + 9, y + 6, col);
            } else {
                Draw.sparkle(ctx, x + 13, y + 10, 3, Theme.alpha(0x7DE8FF, 0xE0));
            }
            ctx.drawTextWithShadow(tr, t.text, x + 26, y + 6, 0xFFFFFFFF);
        }
    }
}
