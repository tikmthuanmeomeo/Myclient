package com.myclient.gui;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.ClickGui;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Thong bao goc duoi ben phai. Module bat/tat: ten (dam) + dong trang thai "Enabled" / "Disabled"
 * co mau, icon tron, thanh thoi gian chay het o day. Thong bao thuong dang "Ten: noi dung".
 */
public final class Notifications {
    private static class Toast {
        String key;
        String title;
        String sub;
        Boolean on; // true = bat, false = tat, null = thong bao thuong
        long born;
    }

    private static final List<Toast> TOASTS = new ArrayList<>();
    private static final long LIFE = 2300;
    private static final long IN = 260;
    private static final long OUT = 320;
    private static final int H = 24;

    /** Bat khi dang load config de khong hien thong bao luc khoi dong. */
    public static boolean muted;

    public static void push(String text, Boolean on) {
        if (muted) return;
        TOASTS.removeIf(t -> t.key.equals(text));
        Toast t = new Toast();
        t.key = text;
        t.on = on;
        if (on != null) {
            t.title = text;
            t.sub = on ? "Enabled" : "Disabled";
        } else {
            int i = text.indexOf(": ");
            if (i > 0) {
                t.title = text.substring(0, i);
                t.sub = text.substring(i + 2);
            } else {
                t.title = text;
                t.sub = null;
            }
        }
        t.born = System.currentTimeMillis();
        TOASTS.add(t);
        while (TOASTS.size() > 5) TOASTS.remove(0);
    }

    private static float scale() {
        ClickGui cg = ModuleManager.get(ClickGui.class);
        return cg == null ? 1.2f : (float) cg.notifyScale.value;
    }

    public static void render(DrawContext ctx, TextRenderer tr, int sw0, int sh0) {
        if (TOASTS.isEmpty()) return;
        float sc = scale();
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.scale(sc, sc, 1.0f);
        int sw = (int) (sw0 / sc);
        int sh = (int) (sh0 / sc);

        long now = System.currentTimeMillis();
        TOASTS.removeIf(t -> now - t.born > LIFE);

        int baseY = sh - 8;
        for (int i = TOASTS.size() - 1; i >= 0; i--) {
            Toast t = TOASTS.get(i);
            long age = now - t.born;

            Text title = Text.literal(t.title).setStyle(Style.EMPTY.withBold(true));
            int textW = Math.max(tr.getWidth(title), t.sub == null ? 0 : tr.getWidth(t.sub));
            int w = textW + 46;
            int h = t.sub == null ? 20 : H;
            int y = baseY - h;
            baseY = y - 4;

            double slide;
            if (age < IN) {
                double p = age / (double) IN;
                slide = Math.pow(1.0 - p, 3);                  // 1 -> 0 (truot vao)
            } else if (age > LIFE - OUT) {
                double p = (age - (LIFE - OUT)) / (double) OUT;
                slide = p * p;                                 // 0 -> 1 (truot ra)
            } else {
                slide = 0.0;
            }
            int x = sw - w - 6 + (int) (slide * (w + 12));

            int col = t.on == null ? 0xFF3B82F6 : (t.on ? 0xFF4ADE80 : 0xFFF87171);
            Draw.rrect(ctx, x - 2, y - 2, w + 4, h + 4, 5, Theme.alpha(col, 0x22));
            Draw.rrect(ctx, x - 1, y - 1, w + 2, h + 2, 4, Theme.alpha(col, 0x55));
            Draw.rrect(ctx, x, y, w, h, 3, 0xF2080F22);
            Draw.hGradient(ctx, x + 1, y + 1, w - 2, h - 2, Theme.alpha(col, 0x30), Theme.alpha(col, 0x00));

            // Icon tron
            int icx = x + 14;
            int icy = y + h / 2;
            Draw.circle(ctx, icx, icy, 8, Theme.alpha(col, 0x38));
            Draw.circle(ctx, icx, icy, 6, Theme.alpha(col, 0x30));
            if (t.on != null) {
                if (t.on) Draw.check(ctx, icx - 5, icy - 4, col);
                else Draw.cross(ctx, icx - 4, icy - 4, col);
            } else {
                Draw.sparkle(ctx, icx, icy, 4, 0xFFBFE9FF);
            }

            // Chu
            int tx = x + 28;
            if (t.sub == null) {
                ctx.drawTextWithShadow(tr, title, tx, y + (h - 8) / 2, 0xFFFFFFFF);
            } else {
                ctx.drawTextWithShadow(tr, title, tx, y + 4, 0xFFFFFFFF);
                ctx.drawTextWithShadow(tr, t.sub, tx, y + 13, t.on == null ? 0xFF9DB8E0 : col);
            }

            // Thanh thoi gian
            float left = Math.max(0f, 1f - age / (float) LIFE);
            int barW = (int) ((w - 8) * left);
            if (barW > 0) ctx.fill(x + 4, y + h - 2, x + 4 + barW, y + h - 1, Theme.alpha(col, 0xB0));
        }
        ms.pop();
    }

    private Notifications() { }
}
