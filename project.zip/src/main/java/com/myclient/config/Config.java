package com.myclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.myclient.gui.Notifications;
import com.myclient.hud.HudElement;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import com.myclient.module.impl.HudModule;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Luu / doc module bat tat, setting va vi tri HUD vao config/eclipse.json. */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static boolean loading;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("eclipse.json");
    }

    public static void save() {
        if (loading) return;
        try {
            JsonObject root = new JsonObject();
            JsonObject mods = new JsonObject();
            for (Module m : ModuleManager.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.key);
                JsonObject st = new JsonObject();
                for (Setting s : m.settings) {
                    if (s instanceof Setting.Bool b) st.addProperty(s.name, b.value);
                    else if (s instanceof Setting.Num n) st.addProperty(s.name, n.value);
                    else if (s instanceof Setting.Text t) st.addProperty(s.name, t.value);
                    else if (s instanceof Setting.NameList nl) {
                        JsonArray arr = new JsonArray();
                        for (String nm : nl.names) if (nm != null && !nm.isBlank()) arr.add(nm.trim());
                        st.add(s.name, arr);
                    }
                }
                o.add("settings", st);
                mods.add(m.name, o);
            }
            root.add("modules", mods);

            HudModule hm = ModuleManager.get(HudModule.class);
            if (hm != null) {
                JsonObject hud = new JsonObject();
                for (HudElement e : hm.elements()) {
                    JsonObject p = new JsonObject();
                    p.addProperty("x", e.x);
                    p.addProperty("y", e.y);
                    hud.add(e.id, p);
                }
                root.add("hud", hud);
            }
            Files.writeString(path(), GSON.toJson(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void load() {
        Path p = path();
        if (!Files.exists(p)) return;
        loading = true;
        Notifications.muted = true;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
            JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module m : ModuleManager.all()) {
                if (!mods.has(m.name)) continue;
                JsonObject o = mods.getAsJsonObject(m.name);
                if (o.has("settings")) {
                    JsonObject st = o.getAsJsonObject("settings");
                    for (Setting s : m.settings) {
                        if (!st.has(s.name)) continue;
                        JsonElement el = st.get(s.name);
                        if (s instanceof Setting.Bool b) b.value = el.getAsBoolean();
                        else if (s instanceof Setting.Num n) n.value = Math.max(n.min, Math.min(n.max, el.getAsDouble()));
                        else if (s instanceof Setting.Text t) t.value = el.getAsString();
                        else if (s instanceof Setting.NameList nl) {
                            nl.names.clear();
                            if (el.isJsonArray()) {
                                for (JsonElement x : el.getAsJsonArray()) nl.names.add(x.getAsString());
                            } else if (el.isJsonPrimitive()) { // config cu: chuoi cach nhau bang dau phay / khoang trang
                                for (String part : el.getAsString().split("[,;\\s]+")) if (!part.isBlank()) nl.names.add(part);
                            }
                        }
                    }
                }
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }

            HudModule hm = ModuleManager.get(HudModule.class);
            if (hm != null && root.has("hud")) {
                JsonObject hud = root.getAsJsonObject("hud");
                for (HudElement e : hm.elements()) {
                    if (!hud.has(e.id)) continue;
                    JsonObject pos = hud.getAsJsonObject(e.id);
                    if (pos.has("x")) e.x = pos.get("x").getAsInt();
                    if (pos.has("y")) e.y = pos.get("y").getAsInt();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            loading = false;
            Notifications.muted = false;
        }
    }
}
