package com.myclient;

import com.myclient.config.Config;
import com.myclient.gui.ClickGuiScreen;
import com.myclient.gui.Draw;
import com.myclient.gui.HudEditorScreen;
import com.myclient.gui.Notifications;
import com.myclient.gui.RegearAnim;
import com.myclient.gui.Theme;
import com.myclient.module.Module;
import com.myclient.module.ModuleManager;
import com.myclient.module.impl.AutoRegear;
import com.myclient.module.impl.HudModule;
import com.myclient.module.impl.Nametags;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class MyClient implements ClientModInitializer {
    public static final String NAME = "Flux";
    public static KeyBinding openHudEditor;
    public static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();
        com.myclient.gui.ChatSuggestions.init();

        openHudEditor = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Open " + NAME + " HUD editor", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_T, NAME));

        // Phim mo GUI dang ky qua KeyBinding (chay duoc ca tren Zalith/Android, hien trong Controls)
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Open " + NAME + " GUI", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, NAME));
        com.myclient.module.impl.ClickGui cg = ModuleManager.get(com.myclient.module.impl.ClickGui.class);
        if (cg != null && cg.key < 0) cg.key = GLFW.GLFW_KEY_RIGHT_SHIFT;

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) {
                if (mc.player != null && mc.currentScreen == null) {
                    mc.setScreen(new ClickGuiScreen());
                }
            }
            // T cung la phim chat mac dinh: chat vua mo trong tick nay thi thay bang HUD editor.
            while (openHudEditor.wasPressed()) {
                if (mc.player != null && (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen)) {
                    mc.setScreen(new HudEditorScreen());
                }
            }
            ModuleManager.tickKeys(mc);
            ModuleManager.tick();
        });

        // Khi dang mo man hinh shulker (HandledScreen) thi ve animation len tren cung
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof HandledScreen<?>) {
                ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> RegearAnim.render(ctx));
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            Nametags n = ModuleManager.get(Nametags.class);
            if (n != null && n.isEnabled()) n.collect(ctx);
            AutoRegear ar = ModuleManager.get(AutoRegear.class);
            if (ar != null) ar.collect(ctx);
            com.myclient.module.impl.AutoCrystal ac = ModuleManager.get(com.myclient.module.impl.AutoCrystal.class);
            if (ac != null) ac.renderWorld(ctx);
            com.myclient.module.impl.PistonCrystal pc = ModuleManager.get(com.myclient.module.impl.PistonCrystal.class);
            if (pc != null) pc.renderWorld(ctx);
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            for (Module fm : ModuleManager.all()) {
                if (fm.isEnabled()) fm.onFrame();
            }
            if (mc.options.hudHidden) return;
            TextRenderer tr = mc.textRenderer;
            int sw = ctx.getScaledWindowWidth();
            int accent = Theme.accent(0f);

            if (!(mc.currentScreen instanceof HandledScreen<?>)) RegearAnim.render(ctx);

            if (!(mc.currentScreen instanceof ClickGuiScreen)) {
                Notifications.render(ctx, tr, sw, ctx.getScaledWindowHeight());
            }

            Nametags nt = ModuleManager.get(Nametags.class);
            if (nt != null && nt.isEnabled()) nt.drawHud(ctx);

            HudModule hm = ModuleManager.get(HudModule.class);
            boolean hudOn = hm != null && hm.isEnabled();
            if (hudOn) hm.renderElements(ctx);

            if (!hudOn || hm.watermark.value) {
                Text wm = Text.literal(NAME).setStyle(Style.EMPTY.withBold(true).withColor(accent & 0xFFFFFF));
                int ww = tr.getWidth(wm);
                Draw.rrect(ctx, 3, 3, ww + 12, 14, 3, 0xA00E0E18);
                ctx.fill(3, 6, 5, 14, accent);
                ctx.drawTextWithShadow(tr, wm, 9, 6, 0xFFFFFFFF);
            }

            if (!hudOn || hm.moduleList.value) {
                List<Module> on = new ArrayList<>();
                for (Module m : ModuleManager.all()) if (m.isEnabled()) on.add(m);
                on.sort((a, b) -> tr.getWidth(b.name) - tr.getWidth(a.name));
                int y = 3;
                int i = 0;
                for (Module m : on) {
                    int w = tr.getWidth(m.name) + 8;
                    int c = Theme.accent(i * 0.5f);
                    ctx.fill(sw - w - 2, y, sw - 2, y + 11, 0x900E0E18);
                    ctx.fill(sw - 2, y, sw, y + 11, c);
                    ctx.drawTextWithShadow(tr, m.name, sw - w + 1, y + 2, c);
                    y += 11;
                    i++;
                }
            }
        });
    }
}
