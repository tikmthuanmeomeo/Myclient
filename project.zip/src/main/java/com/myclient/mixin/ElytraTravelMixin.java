package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.ElytraFly;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public class ElytraTravelMixin {
    @Inject(method = "travel", at = @At("HEAD"), cancellable = true, require = 0)
    private void flux$travelPre(Vec3d movementInput, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        ElytraFly e = ModuleManager.get(ElytraFly.class);
        if (e != null && e.isEnabled() && e.travelPre()) ci.cancel();
    }

    @Inject(method = "travel", at = @At("RETURN"), require = 0)
    private void flux$travelPost(Vec3d movementInput, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        ElytraFly e = ModuleManager.get(ElytraFly.class);
        if (e != null && e.isEnabled()) e.travelPost();
    }
}
