package com.myclient.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.myclient.module.ModuleManager;
import com.myclient.module.impl.NoRender;
import com.myclient.module.impl.Skybox;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    /** Day fog ra xa vo cuc => khong con suong. */
    @Inject(method = "applyFog", at = @At("TAIL"), require = 0)
    private static void flux$noFog(CallbackInfo ci) {
        NoRender n = ModuleManager.get(NoRender.class);
        if (n != null && n.isEnabled() && n.fog.value) {
            RenderSystem.setShaderFogStart(1.0E7f);
            RenderSystem.setShaderFogEnd(1.0E7f + 1000.0f);
        }
    }

    /** Mau suong / chan troi theo module Sky (tru khi dang o duoi nuoc, dung nham...). */
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private static void flux$skyFogColor(CallbackInfo ci) {
        Skybox s = ModuleManager.get(Skybox.class);
        if (s == null || !s.isActive() || !s.horizonGlow.value) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) return;
        if (mc.gameRenderer.getCamera().getSubmersionType() != CameraSubmersionType.NONE) return;
        Vec3d c = s.horizonColor();
        RenderSystem.setShaderFogColor((float) c.x, (float) c.y, (float) c.z);
        RenderSystem.clearColor((float) c.x, (float) c.y, (float) c.z, 0.0f);
    }
}
