package com.myclient.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.myclient.module.ModuleManager;
import com.myclient.module.impl.NoRender;
import net.minecraft.client.render.BackgroundRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    /** Day fog ra xa vo cuc => khong con suong. */
    @Inject(method = "applyFog", at = @At("TAIL"), require = 0)
    private static void eclipse$noFog(CallbackInfo ci) {
        NoRender n = ModuleManager.get(NoRender.class);
        if (n != null && n.isEnabled() && n.fog.value) {
            RenderSystem.setShaderFogStart(1.0E7f);
            RenderSystem.setShaderFogEnd(1.0E7f + 1000.0f);
        }
    }
}
