package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.Sky;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$skyColor(CallbackInfoReturnable<Vec3d> cir) {
        Sky s = ModuleManager.get(Sky.class);
        if (s != null && s.isActive()) cir.setReturnValue(s.skyColor());
    }

    @Inject(method = "getCloudsColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$cloudsColor(CallbackInfoReturnable<Vec3d> cir) {
        Sky s = ModuleManager.get(Sky.class);
        if (s != null && s.isActive() && s.clouds.value) cir.setReturnValue(s.cloudColor());
    }

    @Inject(method = "getStarBrightness", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$stars(CallbackInfoReturnable<Float> cir) {
        Sky s = ModuleManager.get(Sky.class);
        if (s != null && s.isActive() && s.stars.value) cir.setReturnValue(0.9f);
    }
}
