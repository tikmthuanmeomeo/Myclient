package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.Skybox;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void flux$skyColor(CallbackInfoReturnable<Vec3d> cir) {
        Skybox s = ModuleManager.get(Skybox.class);
        if (s != null && s.isActive()) cir.setReturnValue(s.skyColor());
    }

    @Inject(method = "getCloudsColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void flux$cloudsColor(CallbackInfoReturnable<Vec3d> cir) {
        Skybox s = ModuleManager.get(Skybox.class);
        if (s != null && s.isActive() && s.clouds.value) cir.setReturnValue(s.cloudColor());
    }

    @Inject(method = "getStarBrightness", at = @At("HEAD"), cancellable = true, require = 0)
    private void flux$stars(CallbackInfoReturnable<Float> cir) {
        Skybox s = ModuleManager.get(Skybox.class);
        if (s != null && s.isActive() && s.stars.value) cir.setReturnValue(0.0f);
    }
}
