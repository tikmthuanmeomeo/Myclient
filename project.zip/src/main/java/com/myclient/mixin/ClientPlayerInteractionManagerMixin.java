package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.AntiRekit;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
    /** Ghi nho vi tri shulker minh dat de AntiRekit khong dap nham. */
    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void myclient$trackPlace(ClientPlayerEntity player, Hand hand, BlockHitResult hit,
                                     CallbackInfoReturnable<ActionResult> cir) {
        AntiRekit m = ModuleManager.get(AntiRekit.class);
        if (m != null) m.onPlaceAttempt(player, hand, hit);
    }
}
