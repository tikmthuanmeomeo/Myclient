package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.AntiRekit;
import com.myclient.module.impl.TotemPops;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
    /** Ghi nho vi tri shulker minh dat de AntiRekit khong dap nham. */
    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void myclient$trackPlace(ClientPlayerEntity player, Hand hand, BlockHitResult hit,
                                     CallbackInfoReturnable<ActionResult> cir) {
        AntiRekit m = ModuleManager.get(AntiRekit.class);
        if (m != null) m.onPlaceAttempt(player, hand, hit);
        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.onUseBlock(hit.getBlockPos());
    }

    /** TotemPops: ghi nho nguoi choi ma minh vua danh. */
    @Inject(method = "attackEntity", at = @At("HEAD"), require = 0)
    private void myclient$trackAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (player != MinecraftClient.getInstance().player) return;
        TotemPops m = ModuleManager.get(TotemPops.class);
        if (m != null) m.onAttack(target);
    }
}
