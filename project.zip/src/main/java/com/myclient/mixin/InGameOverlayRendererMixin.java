package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    /** Lop toi khi chui vao block (phase). */
    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flux$wall(CallbackInfo ci) {
        NoRender n = ModuleManager.get(NoRender.class);
        if (n != null && n.isEnabled() && n.wall.value) ci.cancel();
    }

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flux$fire(CallbackInfo ci) {
        NoRender n = ModuleManager.get(NoRender.class);
        if (n != null && n.isEnabled() && n.fire.value) ci.cancel();
    }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void flux$water(CallbackInfo ci) {
        NoRender n = ModuleManager.get(NoRender.class);
        if (n != null && n.isEnabled() && n.water.value) ci.cancel();
    }
}
