package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.NoPush;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Unique
    private Vec3d myclient$savedVelocity;

    /** Hit / velocity packet: bo qua neu la cua minh. */
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void myclient$noVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        NoPush m = ModuleManager.get(NoPush.class);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m != null && m.isEnabled() && m.velocity.value
                && mc.player != null && packet.getEntityId() == mc.player.getId()) {
            ci.cancel();
        }
    }

    /** Crystal / explosion: luu van toc truoc, tra lai sau khi packet xu ly xong. */
    @Inject(method = "onExplosion", at = @At("HEAD"))
    private void myclient$explosionHead(ExplosionS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        myclient$savedVelocity = mc.player != null ? mc.player.getVelocity() : null;
    }

    @Inject(method = "onExplosion", at = @At("TAIL"))
    private void myclient$explosionTail(ExplosionS2CPacket packet, CallbackInfo ci) {
        NoPush m = ModuleManager.get(NoPush.class);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m != null && m.isEnabled() && m.explosion.value
                && mc.player != null && myclient$savedVelocity != null) {
            mc.player.setVelocity(myclient$savedVelocity);
        }
        myclient$savedVelocity = null;
    }
}
