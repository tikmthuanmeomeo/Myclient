package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.NoPush;
import com.myclient.module.impl.TotemPops;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import com.myclient.command.Commands;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Unique
    private Vec3d myclient$savedVelocity;

    /** Hit / velocity packet: bo qua neu la cua minh. */
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void myclient$noVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        NoPush m = ModuleManager.get(NoPush.class);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m != null && m.isEnabled() && m.velocity.value
                && mc.player != null && packet.getEntityId() == mc.player.getId()) {
            ci.cancel();
        }
    }

    /** Crystal / explosion: luu van toc truoc, tra lai sau khi packet xu ly xong. */
    @Inject(method = "onExplosion", at = @At("HEAD"))
    private void myclient$explosionHead(ExplosionS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        myclient$savedVelocity = mc.player != null ? mc.player.getVelocity() : null;
    }

    @Inject(method = "onExplosion", at = @At("TAIL"))
    private void myclient$explosionTail(ExplosionS2CPacket packet, CallbackInfo ci) {
        NoPush m = ModuleManager.get(NoPush.class);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m != null && m.isEnabled() && m.explosion.value
                && mc.player != null && myclient$savedVelocity != null) {
            mc.player.setVelocity(myclient$savedVelocity);
        }
        myclient$savedVelocity = null;
    }

    /** TotemPops: status 35 = totem pop, 3 = chet. Chi xu ly tren main thread (tranh dem 2 lan). */
    @Inject(method = "onEntityStatus", at = @At("HEAD"), require = 0)
    private void myclient$entityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!mc.isOnThread() || mc.world == null) return;
        TotemPops m = ModuleManager.get(TotemPops.class);
        if (m == null) return;
        Entity e = packet.getEntity(mc.world);
        if (e != null) m.onStatus(e, packet.getStatus());
    }

    /** Lenh trong chat bat dau bang # (vd #friend add ten) - khong gui len server. */
    @Inject(method = "sendChatMessage(Ljava/lang/String;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void myclient$chatCommand(String content, CallbackInfo ci) {
        if (Commands.handle(content)) ci.cancel();
    }

    /** TotemPops: packet gui di qua networkHandler (kill aura / auto crystal cua client khac). */
    @Inject(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), require = 0)
    private void myclient$onSendPacket(Packet<?> packet, CallbackInfo ci) {
        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.onPacketSent(packet);
    }
}
