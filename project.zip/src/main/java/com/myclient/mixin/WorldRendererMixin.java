package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.Skybox;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.WorldRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
    /** Ve sao + cuc quang ngay sau khi vanilla ve troi (truoc dia hinh nen bi che dung). */
    @Inject(method = "renderSky", at = @At("RETURN"), require = 0)
    private void flux$skybox(Matrix4f matrix4f, Matrix4f projectionMatrix, float tickDelta, Camera camera,
                                boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        if (thickFog) return;
        Skybox s = ModuleManager.get(Skybox.class);
        if (s != null && s.isActive()) s.render(matrix4f, camera);
    }
}
