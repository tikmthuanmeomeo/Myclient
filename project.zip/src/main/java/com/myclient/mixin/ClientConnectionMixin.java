package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.TotemPops;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** TotemPops: bat packet danh / dat crystal gui di (kill aura, auto crystal cua client khac cung duoc tinh). */
@Mixin(ClientConnection.class)
public class ClientConnectionMixin {
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V",
            at = @At("HEAD"), require = 0)
    private void myclient$onSend(Packet<?> packet, PacketCallbacks callbacks, boolean flush, CallbackInfo ci) {
        TotemPops tp = ModuleManager.get(TotemPops.class);
        if (tp != null) tp.onPacketSent(packet);
    }
}
