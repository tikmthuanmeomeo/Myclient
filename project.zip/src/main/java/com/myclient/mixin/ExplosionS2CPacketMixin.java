package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.NoPush;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lop chan thu 1: packet no (crystal) tra ve van toc = 0 cho nguoi choi. */
@Mixin(ExplosionS2CPacket.class)
public class ExplosionS2CPacketMixin {
    @Inject(method = "getPlayerVelocityX", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$vx(CallbackInfoReturnable<Float> cir) {
        NoPush m = ModuleManager.get(NoPush.class);
        if (m != null && m.isEnabled() && m.explosion.value) cir.setReturnValue(0.0f);
    }

    @Inject(method = "getPlayerVelocityY", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$vy(CallbackInfoReturnable<Float> cir) {
        NoPush m = ModuleManager.get(NoPush.class);
        if (m != null && m.isEnabled() && m.explosion.value) cir.setReturnValue(0.0f);
    }

    @Inject(method = "getPlayerVelocityZ", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$vz(CallbackInfoReturnable<Float> cir) {
        NoPush m = ModuleManager.get(NoPush.class);
        if (m != null && m.isEnabled() && m.explosion.value) cir.setReturnValue(0.0f);
    }
}
