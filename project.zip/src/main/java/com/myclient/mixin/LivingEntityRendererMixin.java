package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.Nametags;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** An nametag vanilla cua nguoi choi khi bat Nametags cua client. */
@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$hideVanillaTag(LivingEntity entity, CallbackInfoReturnable<Boolean> cir) {
        if (!(entity instanceof PlayerEntity)) return;
        Nametags n = ModuleManager.get(Nametags.class);
        if (n != null && n.isEnabled()) cir.setReturnValue(false);
    }
}
