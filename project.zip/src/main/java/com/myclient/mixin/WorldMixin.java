package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.Skybox;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public class WorldMixin {
    /** Skybox "Always night": giu goc troi o ban dem (chi phia client) de khong thay mat troi. */
    @Inject(method = "getSkyAngle", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$night(float tickDelta, CallbackInfoReturnable<Float> cir) {
        World self = (World) (Object) this;
        if (!self.isClient) return;
        Skybox s = ModuleManager.get(Skybox.class);
        if (s != null && s.isActive() && s.alwaysNight.value) cir.setReturnValue(0.58f);
    }
}
