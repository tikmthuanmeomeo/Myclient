package com.myclient.mixin;

import com.myclient.module.ModuleManager;
import com.myclient.module.impl.Sky;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** getStarBrightness co the nam o World hoac ClientWorld tuy ban; require=0 nen mixin nao khop se chay. */
@Mixin(World.class)
public class WorldMixin {
    @Inject(method = "getStarBrightness", at = @At("HEAD"), cancellable = true, require = 0)
    private void eclipse$stars(CallbackInfoReturnable<Float> cir) {
        Sky s = ModuleManager.get(Sky.class);
        if (s != null && s.isActive() && s.stars.value) cir.setReturnValue(0.9f);
    }
}
