package com.myclient.util;

import com.myclient.gui.ClickGuiScreen;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.SequencedPacketCreator;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Ham dung chung cho SelfTrap / Surround / ElytraFly / AutoArmor (port logic tu AlienClient). */
public final class Util {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static long lastCrystalAttack;

    private Util() { }

    // ------------------------------------------------------------ vi tri
    /** Vi tri o dang dung (fix = +0.3 theo Y de dung khi dung tren nua block). */
    public static BlockPos playerPos(boolean fix) {
        Vec3d p = mc.player.getPos();
        return new BlockPos(MathHelper.floor(p.x), MathHelper.floor(p.y + (fix ? 0.3 : 0.0)), MathHelper.floor(p.z));
    }

    public static boolean selfIntersect(BlockPos pos) {
        return mc.player.getBoundingBox().intersects(new Box(pos));
    }

    public static boolean isMoving() {
        return mc.player.input.movementForward != 0.0f || mc.player.input.movementSideways != 0.0f;
    }

    /** Dang o man hinh cho phep doi slot / click inventory. */
    public static boolean inInventory() {
        return mc.currentScreen == null || mc.currentScreen instanceof ChatScreen
                || mc.currentScreen instanceof InventoryScreen || mc.currentScreen instanceof ClickGuiScreen
                || mc.currentScreen instanceof GameMenuScreen;
    }

    public static boolean isKeyDown(int key) {
        if (key <= 0 || mc.getWindow() == null) return false;
        return InputUtil.isKeyPressed(mc.getWindow().getHandle(), key);
    }

    // ------------------------------------------------------------ block
    public static boolean canReplace(BlockPos pos) {
        return pos.getY() < 320 && mc.world.getBlockState(pos).isReplaceable();
    }

    public static boolean isClickable(Block block) {
        return block instanceof CraftingTableBlock || block instanceof AnvilBlock || block instanceof LoomBlock
                || block instanceof CartographyTableBlock || block instanceof GrindstoneBlock
                || block instanceof StonecutterBlock || block instanceof ButtonBlock
                || block instanceof AbstractPressurePlateBlock || block instanceof BlockWithEntity
                || block instanceof BedBlock || block instanceof FenceGateBlock || block instanceof DoorBlock
                || block instanceof NoteBlock || block instanceof TrapdoorBlock;
    }

    public static boolean canClick(BlockPos pos) {
        Block block = mc.world.getBlockState(pos).getBlock();
        return mc.player.isSneaking() || !isClickable(block);
    }

    public static boolean hasEntity(Box box, boolean ignoreCrystal) {
        Vec3d eye = mc.player.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (e == null || !e.isAlive()) continue;
            if (!e.getBoundingBox().intersects(box)) continue;
            if (e instanceof ItemEntity || e instanceof ExperienceOrbEntity || e instanceof ExperienceBottleEntity
                    || e instanceof ArrowEntity) continue;
            if (ignoreCrystal && e instanceof EndCrystalEntity && eye.distanceTo(e.getPos()) <= 6.0) continue;
            return true;
        }
        return false;
    }

    /** Huong tu pos toi 1 block co the tua vao (null neu khong co). */
    public static Direction supportSide(BlockPos pos, double reach) {
        double min = Double.MAX_VALUE;
        Direction side = null;
        Vec3d eye = mc.player.getEyePos();
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (!canClick(n)) continue;
            if (canReplace(n)) continue;
            double dis = eye.squaredDistanceTo(pos.toCenterPos().add(d.getOffsetX() * 0.5, d.getOffsetY() * 0.5, d.getOffsetZ() * 0.5));
            if (Math.sqrt(dis) > reach) continue;
            if (dis > min) continue;
            side = d;
            min = dis;
        }
        return side;
    }

    public static boolean canReach(BlockPos pos, double reach) {
        return mc.player.getEyePos().distanceTo(pos.toCenterPos()) <= reach + 0.5;
    }

    /** Co the dat block o pos: o trong, khong co entity chan, va (co tua hoac cho phep air place va trong tam). */
    public static boolean canPlace(BlockPos pos, double reach, boolean ignoreCrystal, boolean airPlace) {
        if (!canReplace(pos)) return false;
        if (hasEntity(new Box(pos), ignoreCrystal)) return false;
        if (supportSide(pos, reach) != null) return true;
        return airPlace && canReach(pos, reach);
    }

    /** Dat block. support != null: bam vao block ben canh; null: air place (bam thang vao o can dat). */
    public static void place(BlockPos pos, Direction support, boolean packet, boolean rotate) {
        Vec3d look;
        BlockHitResult hit;
        if (support == null) {
            look = Vec3d.ofCenter(pos);
            hit = new BlockHitResult(look, Direction.UP, pos, false);
        } else {
            BlockPos clicked = pos.offset(support);
            Direction face = support.getOpposite();
            look = new Vec3d(clicked.getX() + 0.5 + face.getOffsetX() * 0.5,
                    clicked.getY() + 0.5 + face.getOffsetY() * 0.5,
                    clicked.getZ() + 0.5 + face.getOffsetZ() * 0.5);
            hit = new BlockHitResult(look, face, clicked, false);
        }
        if (rotate) lookAt(look);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (packet) {
            sendSequenced(id -> new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, id));
        } else {
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        }
        if (rotate) snapBack();
    }

    public static void sendSequenced(SequencedPacketCreator creator) {
        if (mc.getNetworkHandler() == null || mc.world == null) return;
        try (PendingUpdateManager m = ((com.myclient.mixin.ClientWorldAccessor) mc.world).myclient$getPendingUpdateManager().incrementSequence()) {
            int id = m.getSequence();
            mc.getNetworkHandler().sendPacket(creator.predict(id));
        }
    }

    // ------------------------------------------------------------ xoay (bang packet, khong doi goc nhin that)
    public static void lookAt(Vec3d to) {
        Vec3d d = to.subtract(mc.player.getEyePos());
        double xz = Math.hypot(d.x, d.z);
        float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) MathHelper.wrapDegrees(Math.toDegrees(-Math.atan2(d.y, xz)));
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround()));
    }

    public static void snapBack() {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                mc.player.getYaw(), mc.player.getPitch(), mc.player.isOnGround()));
    }

    // ------------------------------------------------------------ danh crystal vuong cho
    public static void attackCrystal(BlockPos pos, boolean rotate, boolean eatingPause) {
        Box box = new Box(pos);
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity) || !e.isAlive() || !e.getBoundingBox().intersects(box)) continue;
            long now = System.currentTimeMillis();
            if (now - lastCrystalAttack < 100) return;
            if (eatingPause && mc.player.isUsingItem()) return;
            if (mc.player.getEyePos().distanceTo(e.getPos()) > 6.0) return;
            lastCrystalAttack = now;
            if (rotate) lookAt(e.getBoundingBox().getCenter());
            mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(e, mc.player.isSneaking()));
            mc.player.resetLastAttackedTicks();
            mc.player.swingHand(Hand.MAIN_HAND);
            if (rotate) snapBack();
        }
    }

    // ------------------------------------------------------------ inventory
    /** Slot hotbar (0-8) chua item, -1 neu khong co. */
    public static int findHotbar(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    /** Slot theo so thu tu cua screen handler (hotbar = 36..44, tui do = 9..35), -1 neu khong co. */
    public static int findInvSlot(Item item) {
        for (int i = 35; i >= 0; i--) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.isOf(item)) return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    public static int findBlockInv(Block block) {
        return findInvSlot(block.asItem());
    }

    public static int findBlockHotbar(Block block) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.getItem() instanceof BlockItem bi && bi.getBlock() == block) return i;
        }
        return -1;
    }

    /** Doi slot trong screen handler voi o hotbar dang cam (goi 2 lan de doi lai). */
    public static void inventorySwap(int slot) {
        int selected = mc.player.getInventory().selectedSlot;
        if (slot - 36 == selected) return;
        if (!inInventory()) return;
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, selected, SlotActionType.SWAP, mc.player);
        mc.player.getInventory().updateItems();
    }

    public static void switchToSlot(int slot) {
        mc.player.getInventory().selectedSlot = slot;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }
}
