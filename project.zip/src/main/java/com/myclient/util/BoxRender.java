package com.myclient.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Ve o khoi (tho + vien) trong the gioi, co the nhin xuyen tuong. */
public final class BoxRender {
    private BoxRender() { }

    public static void draw(WorldRenderContext ctx, Box box, int fillArgb, int outlineArgb, float lineWidth, float alphaMul) {
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Vec3d cam = ctx.camera().getPos();
        Matrix4f m = ms.peek().getPositionMatrix();
        float x0 = (float) (box.minX - cam.x), y0 = (float) (box.minY - cam.y), z0 = (float) (box.minZ - cam.z);
        float x1 = (float) (box.maxX - cam.x), y1 = (float) (box.maxY - cam.y), z1 = (float) (box.maxZ - cam.z);
        float t = lineWidth * 0.012f;

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        float fa = ((fillArgb >>> 24) & 255) / 255f * alphaMul;
        if (fa > 0f) cuboid(b, m, x0, y0, z0, x1, y1, z1, fillArgb, fa);
        float oa = ((outlineArgb >>> 24) & 255) / 255f * alphaMul;
        if (oa > 0f) {
            cuboid(b, m, x0 - t, y0 - t, z0 - t, x0 + t, y1 + t, z0 + t, outlineArgb, oa);
            cuboid(b, m, x1 - t, y0 - t, z0 - t, x1 + t, y1 + t, z0 + t, outlineArgb, oa);
            cuboid(b, m, x0 - t, y0 - t, z1 - t, x0 + t, y1 + t, z1 + t, outlineArgb, oa);
            cuboid(b, m, x1 - t, y0 - t, z1 - t, x1 + t, y1 + t, z1 + t, outlineArgb, oa);
            for (float yy : new float[]{y0, y1}) {
                cuboid(b, m, x0 - t, yy - t, z0 - t, x1 + t, yy + t, z0 + t, outlineArgb, oa);
                cuboid(b, m, x0 - t, yy - t, z1 - t, x1 + t, yy + t, z1 + t, outlineArgb, oa);
                cuboid(b, m, x0 - t, yy - t, z0 - t, x0 + t, yy + t, z1 + t, outlineArgb, oa);
                cuboid(b, m, x1 - t, yy - t, z0 - t, x1 + t, yy + t, z1 + t, outlineArgb, oa);
            }
        }
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        BufferRenderer.drawWithGlobalProgram(b.end());
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    private static void cuboid(BufferBuilder b, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, int argb, float a) {
        float r = ((argb >> 16) & 255) / 255f, g = ((argb >> 8) & 255) / 255f, bl = (argb & 255) / 255f;
        quad(b, m, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, r, g, bl, a);
        quad(b, m, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, r, g, bl, a);
        quad(b, m, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, r, g, bl, a);
        quad(b, m, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, r, g, bl, a);
        quad(b, m, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, r, g, bl, a);
        quad(b, m, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, r, g, bl, a);
    }

    private static void quad(BufferBuilder b, Matrix4f m, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, float r, float g, float bl, float a) {
        b.vertex(m, ax, ay, az).color(r, g, bl, a);
        b.vertex(m, bx, by, bz).color(r, g, bl, a);
        b.vertex(m, cx, cy, cz).color(r, g, bl, a);
        b.vertex(m, dx, dy, dz).color(r, g, bl, a);
    }
}
