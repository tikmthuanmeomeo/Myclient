package com.myclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.util.math.BlockPos;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

/** Theo doi nguoi choi khac dang dap block nao (tu packet BlockBreakingProgress). */
public final class BreakTracker {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final ConcurrentHashMap<Integer, Data> MAP = new ConcurrentHashMap<>();
    /** Qua ngan nay (ms) ma block van chua vo thi coi nhu dap that bai. */
    private static final long TIMEOUT_MS = 5000;

    private BreakTracker() { }

    public static class Data {
        public final BlockPos pos;
        public final int entityId;
        private final long start = System.currentTimeMillis();

        Data(BlockPos pos, int entityId) {
            this.pos = pos;
            this.entityId = entityId;
        }

        public PlayerEntity getPlayer() {
            if (mc.world == null) return null;
            Entity e = mc.world.getEntityById(entityId);
            return e instanceof PlayerEntity p ? p : null;
        }

        public long ms() { return System.currentTimeMillis() - start; }

        public boolean failed() {
            return ms() > TIMEOUT_MS || (mc.world != null && mc.world.isAir(pos));
        }
    }

    public static void onPacket(BlockBreakingProgressS2CPacket p) {
        if (mc.world == null || mc.player == null || p.getPos() == null) return;
        Entity e = mc.world.getEntityById(p.getEntityId());
        if (!(e instanceof PlayerEntity) || e == mc.player) return;
        if (e.getEyePos().distanceTo(p.getPos().toCenterPos()) > 8) return;
        Data cur = MAP.get(p.getEntityId());
        if (cur != null && !cur.failed() && cur.pos.equals(p.getPos())) return;
        MAP.put(p.getEntityId(), new Data(p.getPos().toImmutable(), p.getEntityId()));
    }

    public static Collection<Data> all() {
        return MAP.values();
    }

    public static boolean isMining(BlockPos pos) {
        for (Data d : MAP.values()) {
            if (d.getPlayer() == null || d.failed()) continue;
            if (d.getPlayer().getEyePos().distanceTo(pos.toCenterPos()) > 7) continue;
            if (d.pos.equals(pos)) return true;
        }
        return false;
    }

    public static void clear() {
        MAP.clear();
    }
}
