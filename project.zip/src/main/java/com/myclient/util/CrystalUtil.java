package com.myclient.util;

import com.myclient.module.Friends;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.List;

/** Ham dung chung cho AutoCrystal / PistonCrystal (port logic tu AlienClient, tinh sat thuong theo cong thuc vanilla). */
public final class CrystalUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private CrystalUtil() { }

    // ------------------------------------------------------------ muc tieu
    public static boolean isValidTarget(PlayerEntity p, double range) {
        if (p == null || p == mc.player || !p.isAlive() || p.isSpectator()) return false;
        if (Friends.isFriend(p.getName().getString())) return false;
        return mc.player.getPos().distanceTo(p.getPos()) <= range;
    }

    public static List<PlayerEntity> enemies(double range) {
        List<PlayerEntity> out = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (isValidTarget(p, range)) out.add(p);
        }
        return out;
    }

    public static PlayerEntity closestEnemy(double range) {
        PlayerEntity best = null;
        for (PlayerEntity p : enemies(range)) {
            if (best == null || mc.player.squaredDistanceTo(p) < mc.player.squaredDistanceTo(best)) best = p;
        }
        return best;
    }

    public static float health(Entity e) {
        return e instanceof PlayerEntity p ? p.getHealth() + p.getAbsorptionAmount() : 0f;
    }

    public static List<Entity> entitiesIn(Box box) {
        return mc.world.getOtherEntities(null, box);
    }

    public static List<EndCrystalEntity> crystalsIn(Box box) {
        List<EndCrystalEntity> out = new ArrayList<>();
        for (Entity e : entitiesIn(box)) {
            if (e instanceof EndCrystalEntity c && c.isAlive()) out.add(c);
        }
        return out;
    }

    // ------------------------------------------------------------ dat crystal
    /** Mat cua obsidian nhin ve phia mat nguoi choi nhat (crystal dat len tren obsidian du bam mat nao). */
    public static Direction clickSide(BlockPos pos) {
        Direction best = Direction.UP;
        double min = Double.MAX_VALUE;
        Vec3d eye = mc.player.getEyePos();
        for (Direction d : Direction.values()) {
            double dis = eye.squaredDistanceTo(pos.offset(d).toCenterPos());
            if (dis > min) continue;
            best = d;
            min = dis;
        }
        return best;
    }

    private static boolean noEntityBlock(BlockPos pos, boolean ignoreCrystal) {
        for (Entity e : entitiesIn(new Box(pos))) {
            if (!e.isAlive()) continue;
            if (e instanceof net.minecraft.entity.ItemEntity) continue;
            if (ignoreCrystal && e instanceof EndCrystalEntity) continue;
            return false;
        }
        return true;
    }

    /** pos = o dat crystal (tren obsidian/bedrock). */
    public static boolean canPlaceCrystal(BlockPos pos, boolean ignoreCrystal) {
        BlockPos obs = pos.down();
        Block b = mc.world.getBlockState(obs).getBlock();
        if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) return false;
        if (!mc.world.isAir(pos) && !(ignoreCrystal && mc.world.getBlockState(pos).isReplaceable())) return false;
        return noEntityBlock(pos, ignoreCrystal) && noEntityBlock(pos.up(), ignoreCrystal);
    }

    public static void placeCrystal(BlockPos pos, boolean rotate) {
        BlockPos obs = pos.down();
        Direction face = clickSide(obs);
        Vec3d vec = obs.toCenterPos().add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        net.minecraft.util.Hand hand = mc.player.getOffHandStack().isOf(net.minecraft.item.Items.END_CRYSTAL)
                ? net.minecraft.util.Hand.OFF_HAND : net.minecraft.util.Hand.MAIN_HAND;
        if (rotate) Util.lookAt(vec);
        mc.interactionManager.interactBlock(mc.player, hand, new net.minecraft.util.hit.BlockHitResult(vec, face, obs, false));
        mc.player.swingHand(hand);
        if (rotate) Util.snapBack();
    }

    // ------------------------------------------------------------ sat thuong
    private static int level(Registry<Enchantment> reg, RegistryKey<Enchantment> key, ItemStack st) {
        RegistryEntry<Enchantment> en = reg.getEntry(key).orElse(null);
        return en == null ? 0 : EnchantmentHelper.getLevel(en, st);
    }

    /** Sat thuong crystal (no cong suat 6) len nguoi choi tai vi tri noi. */
    public static float damage(Vec3d pos, PlayerEntity p) {
        if (p.isCreative() || p.isSpectator()) return 0f;
        double dist = Math.sqrt(p.squaredDistanceTo(pos)) / 12.0;
        if (dist > 1.0) return 0f;
        double exposure = Explosion.getExposure(pos, p);
        double impact = (1.0 - dist) * exposure;
        float dmg = (float) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0);

        Difficulty diff = mc.world.getDifficulty();
        if (diff == Difficulty.PEACEFUL) return 0f;
        if (diff == Difficulty.EASY) dmg = Math.min(dmg / 2.0f + 1.0f, dmg);
        else if (diff == Difficulty.HARD) dmg = dmg * 3.0f / 2.0f;

        DamageSource src = mc.world.getDamageSources().explosion(null, null);
        dmg = DamageUtil.getDamageLeft(p, dmg, src, (float) p.getArmor(), (float) p.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS));

        // Enchant giap (Protection = 1 EPF, Blast Protection = 2 EPF, toi da 20)
        Registry<Enchantment> reg = mc.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT);
        int epf = 0;
        for (ItemStack st : p.getArmorItems()) {
            if (st.isEmpty()) continue;
            epf += level(reg, Enchantments.PROTECTION, st);
            epf += level(reg, Enchantments.BLAST_PROTECTION, st) * 2;
        }
        dmg *= 1.0f - MathHelper.clamp(epf, 0, 20) / 25.0f;

        StatusEffectInstance res = p.getStatusEffect(StatusEffects.RESISTANCE);
        if (res != null) {
            dmg = Math.max(dmg * (25 - (res.getAmplifier() + 1) * 5) / 25.0f, 0.0f);
        }
        return Math.max(dmg, 0f);
    }

    public static float damage(BlockPos crystalPos, PlayerEntity p) {
        return damage(new Vec3d(crystalPos.getX() + 0.5, crystalPos.getY(), crystalPos.getZ() + 0.5), p);
    }
}
