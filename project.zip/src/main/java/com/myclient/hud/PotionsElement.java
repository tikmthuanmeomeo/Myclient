package com.myclient.hud;

import com.myclient.gui.Draw;
import com.myclient.gui.Theme;
import com.myclient.module.ModuleManager;
import com.myclient.module.Setting;
import com.myclient.module.impl.FullBright;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

import java.util.ArrayList;
import java.util.List;

/** Danh sach potion effect dang co + thoi gian con lai. */
public class PotionsElement extends HudElement {
    public PotionsElement(Setting.Bool toggle, int x, int y) {
        super("Potions", toggle, x, y);
    }

    private List<StatusEffectInstance> list() {
        List<StatusEffectInstance> out = new ArrayList<>();
        if (mc.player == null) return out;
        FullBright fb = ModuleManager.get(FullBright.class);
        boolean hideNv = fb != null && fb.isEnabled();
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (hideNv && e.getEffectType() == StatusEffects.NIGHT_VISION && e.getDuration() < 0) continue;
            out.add(e);
        }
        return out;
    }

    private String line(StatusEffectInstance e) {
        String name = e.getEffectType().value().getName().getString();
        int amp = e.getAmplifier();
        String time;
        if (e.getDuration() < 0) {
            time = "inf";
        } else {
            int s = e.getDuration() / 20;
            time = String.format("%d:%02d", s / 60, s % 60);
        }
        return name + (amp > 0 ? " " + (amp + 1) : "") + "  " + time;
    }

    @Override
    public int w(boolean edit) {
        List<StatusEffectInstance> l = list();
        if (l.isEmpty()) return edit ? mc.textRenderer.getWidth("Potions") + 12 : 0;
        int w = 0;
        for (StatusEffectInstance e : l) w = Math.max(w, mc.textRenderer.getWidth(line(e)));
        return w + 12;
    }

    @Override
    public int h(boolean edit) {
        int n = list().size();
        if (n == 0) return edit ? 15 : 0;
        return n * 11 + 4;
    }

    @Override
    public void draw(DrawContext ctx, int x, int y, boolean edit) {
        List<StatusEffectInstance> l = list();
        Draw.rrect(ctx, x, y, w(edit), h(edit), 3, 0xA00E0E18);
        ctx.fill(x, y + 3, x + 2, y + h(edit) - 3, Theme.accent(0f));
        if (l.isEmpty()) {
            ctx.drawTextWithShadow(mc.textRenderer, "Potions", x + 6, y + 4, 0xFF8A8AA0);
            return;
        }
        int i = 0;
        for (StatusEffectInstance e : l) {
            int col = 0xFF000000 | e.getEffectType().value().getColor();
            ctx.drawTextWithShadow(mc.textRenderer, line(e), x + 6, y + 3 + i * 11, col);
            i++;
        }
    }
}
