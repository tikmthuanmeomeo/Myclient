package com.myclient.hud;

import com.myclient.module.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class HudElement {
    public final String id;
    public final Setting.Bool toggle;
    public int x, y;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected HudElement(String id, Setting.Bool toggle, int x, int y) {
        this.id = id;
        this.toggle = toggle;
        this.x = x;
        this.y = y;
    }

    /** Kich thuoc; edit = true khi dang o man hinh chinh vi tri (luon phai > 0). */
    public abstract int w(boolean edit);

    public abstract int h(boolean edit);

    public abstract void draw(DrawContext ctx, int x, int y, boolean edit);
}
