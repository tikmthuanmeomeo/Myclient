package com.myclient.hud;

import com.myclient.gui.Draw;
import com.myclient.gui.Theme;
import com.myclient.module.Setting;
import net.minecraft.client.gui.DrawContext;

/** Hien phim dang bam: W A S D, chuot trai/phai, space. */
public class KeybindsElement extends HudElement {
    public KeybindsElement(Setting.Bool toggle, int x, int y) {
        super("Keybinds", toggle, x, y);
    }

    @Override
    public int w(boolean edit) { return 58; }

    @Override
    public int h(boolean edit) { return 72; }

    private void key(DrawContext ctx, int x, int y, int w, int h, String label, boolean down) {
        Draw.rrect(ctx, x, y, w, h, 3, down ? Theme.alpha(Theme.accent(0f), 0xC0) : 0xA00E0E18);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, label, x + w / 2, y + (h - 8) / 2,
                down ? 0xFFFFFFFF : 0xFFB0B0C6);
    }

    @Override
    public void draw(DrawContext ctx, int x, int y, boolean edit) {
        if (mc.options == null) return;
        key(ctx, x + 20, y, 18, 18, "W", mc.options.forwardKey.isPressed());
        key(ctx, x, y + 20, 18, 18, "A", mc.options.leftKey.isPressed());
        key(ctx, x + 20, y + 20, 18, 18, "S", mc.options.backKey.isPressed());
        key(ctx, x + 40, y + 20, 18, 18, "D", mc.options.rightKey.isPressed());
        key(ctx, x, y + 40, 28, 18, "LMB", mc.options.attackKey.isPressed());
        key(ctx, x + 30, y + 40, 28, 18, "RMB", mc.options.useKey.isPressed());
        key(ctx, x, y + 60, 58, 12, "SPACE", mc.options.jumpKey.isPressed());
    }
}
