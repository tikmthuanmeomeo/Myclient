package com.myclient.hud;

import com.myclient.gui.Draw;
import com.myclient.gui.Theme;
import com.myclient.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Icon item + so luong trong inventory (ke ca tay phu). */
public class CountElement extends HudElement {
    private final Item item;
    private final ItemStack icon;

    public CountElement(String id, Setting.Bool toggle, Item item, int x, int y) {
        super(id, toggle, x, y);
        this.item = item;
        this.icon = new ItemStack(item);
    }

    private int count() {
        if (mc.player == null) return 0;
        int c = 0;
        PlayerInventory inv = mc.player.getInventory();
        for (ItemStack s : inv.main) if (s.isOf(item)) c += s.getCount();
        for (ItemStack s : inv.offHand) if (s.isOf(item)) c += s.getCount();
        return c;
    }

    @Override
    public int w(boolean edit) {
        return 26 + mc.textRenderer.getWidth(String.valueOf(count())) + 4;
    }

    @Override
    public int h(boolean edit) { return 18; }

    @Override
    public void draw(DrawContext ctx, int x, int y, boolean edit) {
        int c = count();
        Draw.rrect(ctx, x, y, w(edit), 18, 3, 0xA00E0E18);
        ctx.fill(x, y + 3, x + 2, y + 15, Theme.accent(0f));
        ctx.drawItem(icon, x + 5, y + 1);
        ctx.drawTextWithShadow(mc.textRenderer, String.valueOf(c), x + 26, y + 5,
                c > 0 ? 0xFFFFFFFF : 0xFFFF6B6B);
    }
}
