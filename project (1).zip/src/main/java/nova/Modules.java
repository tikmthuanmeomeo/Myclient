package nova;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public final class Modules {
    private Modules() {}

    // ---------- Sprint ----------
    public static class Sprint extends Module {
        public Sprint() { super("Sprint"); }
        @Override public void tick() {
            if (mc.options.forwardKey.isPressed()) mc.options.sprintKey.setPressed(true);
        }
    }

    // ---------- AutoCrystal ----------
    public static class AutoCrystal extends Module {
        final Setting placeDelay = add(Setting.num("Place Delay (ms)", 50, 0, 500, 5));
        final Setting breakDelay = add(Setting.num("Break Delay (ms)", 50, 0, 500, 5));
        long lastPlace, lastBreak;

        public AutoCrystal() { super("AutoCrystal"); }

        @Override public void tick() {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            HitResult h = mc.crosshairTarget;
            if (h == null) return;
            long now = System.currentTimeMillis();

            if (h instanceof EntityHitResult e && e.getEntity() instanceof EndCrystalEntity c) {
                if (now - lastBreak >= breakDelay.get()) {
                    mc.interactionManager.attackEntity(mc.player, c);
                    mc.player.swingHand(Hand.MAIN_HAND);
                    lastBreak = now;
                }
            } else if (h instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK
                    && mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                BlockPos p = b.getBlockPos();
                BlockState s = mc.world.getBlockState(p);
                if ((s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.BEDROCK)) && now - lastPlace >= placeDelay.get()) {
                    BlockPos up = p.up();
                    Box box = new Box(up).stretch(0, 1, 0);
                    if (mc.world.isAir(up) && mc.world.getOtherEntities(null, box).isEmpty()) {
                        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, b);
                        mc.player.swingHand(Hand.MAIN_HAND);
                        lastPlace = now;
                    }
                }
            }
        }
    }

    // ---------- AnchorMacro ----------
    public static class AnchorMacro extends Module {
        final Setting slot = add(Setting.num("Slot after charge", 1, 1, 9, 1));
        final Setting charges = add(Setting.num("Charges", 1, 1, 4, 1));
        final Setting explode = add(Setting.bool("Explode", true));

        public AnchorMacro() { super("AnchorMacro"); }

        @Override public void tick() {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (!(mc.crosshairTarget instanceof BlockHitResult b) || b.getType() != HitResult.Type.BLOCK) return;
            BlockState s = mc.world.getBlockState(b.getBlockPos());
            if (!s.isOf(Blocks.RESPAWN_ANCHOR)) return;

            int cur = s.get(RespawnAnchorBlock.CHARGES);
            PlayerInventory inv = mc.player.getInventory();
            int target = charges.getInt();
            int after = slot.getInt() - 1;

            if (cur < target) {
                int g = findHotbar(Items.GLOWSTONE);
                if (g == -1) return;
                inv.setSelectedSlot(g);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, b);
                mc.player.swingHand(Hand.MAIN_HAND);
                inv.setSelectedSlot(after);
            } else if (explode.getBool()) {
                inv.setSelectedSlot(after);
                if (inv.getStack(after).isOf(Items.GLOWSTONE)) return;
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, b);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }

        int findHotbar(Item item) {
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(item)) return i;
            return -1;
        }
    }

    // ---------- AutoTotem ----------
    public static class AutoTotem extends Module {
        final Setting mainSlot = add(Setting.num("Main hand slot", 1, 1, 9, 1));
        final Setting delay = add(Setting.num("Delay (ms)", 0, 0, 300, 10));
        long last;
        boolean wasOpen;

        public AutoTotem() { super("AutoTotem"); }

        @Override public void tick() {
            int ms = mainSlot.getInt() - 1;
            PlayerInventory inv = mc.player.getInventory();

            boolean open = mc.currentScreen instanceof InventoryScreen;
            if (open && !wasOpen) inv.setSelectedSlot(ms);
            wasOpen = open;

            if (mc.currentScreen != null && !open) return;
            long now = System.currentTimeMillis();
            if (now - last < delay.get()) return;
            ScreenHandler h = mc.player.playerScreenHandler;

            if (!mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                int src = find(h, ms);
                if (src != -1) {
                    mc.interactionManager.clickSlot(h.syncId, src, 40, SlotActionType.SWAP, mc.player);
                    last = now;
                    return;
                }
            }
            if (!inv.getStack(ms).isOf(Items.TOTEM_OF_UNDYING)) {
                for (int i = 9; i <= 35; i++) {
                    if (h.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                        mc.interactionManager.clickSlot(h.syncId, i, ms, SlotActionType.SWAP, mc.player);
                        last = now;
                        return;
                    }
                }
            }
        }

        int find(ScreenHandler h, int ms) {
            for (int i = 9; i <= 44; i++) {
                if (i == 36 + ms) continue;
                if (h.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) return i;
            }
            if (h.getSlot(36 + ms).getStack().isOf(Items.TOTEM_OF_UNDYING)) return 36 + ms;
            return -1;
        }
    }
}
