package nova;

public class Setting {
    public final String name;
    public final boolean bool;
    public double value, min, max, step;

    private Setting(String name, boolean bool, double value, double min, double max, double step) {
        this.name = name; this.bool = bool; this.value = value;
        this.min = min; this.max = max; this.step = step;
    }
    public static Setting bool(String name, boolean def) { return new Setting(name, true, def ? 1 : 0, 0, 1, 1); }
    public static Setting num(String name, double def, double min, double max, double step) { return new Setting(name, false, def, min, max, step); }

    public boolean getBool() { return value > 0.5; }
    public double get() { return value; }
    public int getInt() { return (int) Math.round(value); }
}
