package nova;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public class Nova implements ClientModInitializer {
    public static final List<Module> modules = new ArrayList<>();
    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        modules.add(new Modules.Sprint());
        modules.add(new Modules.AutoCrystal());
        modules.add(new Modules.AnchorMacro());
        modules.add(new Modules.AutoTotem());

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("Open Nova GUI", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.create(Identifier.of("nova", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (guiKey.wasPressed()) mc.setScreen(new ClickGui());
            if (mc.player == null || mc.world == null) return;
            for (Module m : modules) if (m.enabled) m.tick();
        });
    }
}
