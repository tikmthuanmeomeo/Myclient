package nova;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name;
    public boolean enabled, open;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name) { this.name = name; }
    protected Setting add(Setting s) { settings.add(s); return s; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }
    public void onEnable() {}
    public void onDisable() {}
    public abstract void tick();
}
