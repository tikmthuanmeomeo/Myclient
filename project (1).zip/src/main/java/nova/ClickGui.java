package nova;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGui extends Screen {
    static final int X = 20, Y = 20, W = 160, H = 18, SH = 16;
    private Setting dragging;
    private boolean prevL, prevR;

    public ClickGui() { super(Text.literal("Nova")); }

    @Override public boolean shouldPause() { return false; }

    private void handleInput(int mx, int my) {
        long win = GLFW.glfwGetCurrentContext();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !prevL) click(mx, my, 0);
        if (r && !prevR) click(mx, my, 1);
        if (!l) dragging = null;
        if (l && dragging != null) setFromMouse(dragging, mx);
        prevL = l; prevR = r;
    }

    private void click(double mx, double my, int button) {
        int y = Y + H;
        for (Module m : Nova.modules) {
            if (mx >= X && mx <= X + W && my >= y && my < y + H) {
                boolean gear = mx >= X + W - 24 && !m.settings.isEmpty();
                if (button == 1 || gear) m.open = !m.open;
                else if (button == 0) m.toggle();
                return;
            }
            y += H;
            if (m.open) {
                for (Setting s : m.settings) {
                    if (mx >= X && mx <= X + W && my >= y && my < y + SH) {
                        if (s.bool) s.value = s.getBool() ? 0 : 1;
                        else { dragging = s; setFromMouse(s, mx); }
                        return;
                    }
                    y += SH;
                }
            }
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        handleInput(mx, my);
        c.fill(0, 0, width, height, 0xA0000014);
        c.fill(X, Y, X + W, Y + H, 0xFF3050FF);
        c.drawText(textRenderer, "Nova", X + 5, Y + 5, 0xFFFFFFFF, true);
        int y = Y + H;
        for (Module m : Nova.modules) {
            c.fill(X, y, X + W, y + H, m.enabled ? 0xFF2040C0 : 0xFF151525);
            c.drawText(textRenderer, m.name, X + 5, y + 5, 0xFFFFFFFF, true);
            if (!m.settings.isEmpty()) c.drawText(textRenderer, m.open ? "-" : "+", X + W - 12, y + 5, 0xFFFFFFFF, true);
            y += H;
            if (m.open) {
                for (Setting s : m.settings) {
                    c.fill(X, y, X + W, y + SH, 0xFF0C0C18);
                    String label;
                    if (s.bool) {
                        if (s.getBool()) c.fill(X, y, X + 3, y + SH, 0xFF40FF70);
                        label = s.name + ": " + (s.getBool() ? "ON" : "OFF");
                    } else {
                        double p = (s.value - s.min) / (s.max - s.min);
                        c.fill(X, y, X + (int) (W * p), y + SH, 0xFF3050C0);
                        label = s.name + ": " + (s.step >= 1 ? String.valueOf(s.getInt()) : String.format("%.1f", s.value));
                    }
                    c.drawText(textRenderer, label, X + 6, y + 4, 0xFFFFFFFF, true);
                    y += SH;
                }
            }
        }
    }

    private void setFromMouse(Setting s, double mx) {
        double p = Math.max(0, Math.min(1, (mx - X) / W));
        double v = s.min + p * (s.max - s.min);
        v = Math.round((v - s.min) / s.step) * s.step + s.min;
        s.value = Math.max(s.min, Math.min(s.max, v));
    }
}
